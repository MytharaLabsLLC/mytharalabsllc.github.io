SERE Bot (BOT-SERE-001)
=======================
Mythara Labs LLC

What this is
------------
Sandboxed specimen analysis for training and triage. SERE takes a file you give it, and without ever executing it, detects what it is, contains it, builds a forensic profile, quarantines it, and writes a sealed, tamper-evident event log of everything it did.

How to run it
-------------
SERE is a command line tool. From this folder, run:

    python3 sere_bot.py <path-to-a-file-to-analyze>

You can also give it a second argument, a working directory for its case files:

    python3 sere_bot.py <path-to-a-file> <workdir>

With no arguments it prints its usage. Exit code 0 means the pipeline completed and the event log verified intact.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library.

Notes
-----
The specimen is never executed. Analysis is static only. SERE is a training and triage tool; it is not a replacement for a full incident response process.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

