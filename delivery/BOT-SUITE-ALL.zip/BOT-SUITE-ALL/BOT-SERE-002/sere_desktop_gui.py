"""
Copyright © 2025 Herbert Velez Jr. All rights reserved.
Proprietary and Confidential.
"""

import os
import random
import threading
import time
import sys
import subprocess
import math
import hashlib
import json
import re
import ipaddress
from collections import Counter
from urllib import request as urllib_request
from urllib.error import URLError
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List, Set, Tuple, Callable
from types import SimpleNamespace

from sere_persona_catalog import persona_line

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from enum import Enum

try:
	import pyttsx3
	TTS_AVAILABLE = True
except ImportError:
	pyttsx3 = None
	TTS_AVAILABLE = False

from sere_enterprise import (
	SEREProtectionEngine,
	SystemHealth,
	DetectedThreat,
	ThreatSeverity,
)

try:
	from sere_ai_engine import OllamaClient, SEREAIAgent
	_AI_ENGINE_AVAILABLE = True
except ImportError:
	_AI_ENGINE_AVAILABLE = False


class SEREPhase(Enum):
	SURVIVE = 0
	EVADE = 1
	RESIST = 2
	ESCAPE = 3


PHASE_NAMES = {
	SEREPhase.SURVIVE: "SURVIVE",
	SEREPhase.EVADE: "EVADE",
	SEREPhase.RESIST: "RESIST",
	SEREPhase.ESCAPE: "ESCAPE"
}


PHASE_DESCRIPTIONS = {
	SEREPhase.SURVIVE: "Immediate threat response. Lockdown, block, and alert.",
	SEREPhase.EVADE: "Detect and avoid advanced threats, monitor for evasion.",
	SEREPhase.RESIST: "Resist persistent attacks, reinforce defenses.",
	SEREPhase.ESCAPE: "Restore integrity, recover, and exit hostile state."
}


THEME = {
		'bg': '#0a1a2f',  # Deep blue background
		'panel': '#14294d',  # Slightly lighter blue for panels
		'button': '#1e3a5c',  # Blue button
		'button_active': '#235a8b',  # Lighter blue for active button
		'button_text': '#eaf6ff',  # White text
		'button_engaged': '#2b6cb0',  # Bright blue for engaged
		'button_engaged_active': '#3182ce',  # Even brighter blue
		'text': '#eaf6ff',  # White text
		'accent': '#4fd1ff',  # Cyan accent
		'danger': '#ff5e5e',  # Red for danger
		'success': '#4fd1ff',  # Cyan for success
		'warning': '#ffe066',  # Yellow for warning
		'crt_case': '#14294d',
		'crt_case_outline': '#235a8b',
		'crt_glass_outer': '#1e3a5c',
		'crt_glass_inner': '#235a8b',
		'crt_glow': '#4fd1ff',
		'crt_scanline_light': '#235a8b',
		'crt_scanline_dark': '#14294d',
		'sonar_grid': '#235a8b',
		'sonar_grid_dim': '#14294d',
		'sonar_sweep': '#4fd1ff',
		'sonar_ping': '#eaf6ff',
		'hud_grid': '#235a8b',
		'hud_grid_dim': '#14294d',
		'hud_glow': '#4fd1ff',
		'hud_muted': '#4fd1ff',
		'hud_warning': '#ffe066'
}

ESCALATION_TONES = {
	'IDLE': {'bg': '#041b16', 'fg': THEME['success'], 'detail_fg': THEME['text'], 'border': THEME['success']},
	'CONTACT': {'bg': '#1c210c', 'fg': THEME['warning'], 'detail_fg': THEME['text'], 'border': THEME['warning']},
	'ENGAGED': {'bg': '#261505', 'fg': '#ffb347', 'detail_fg': THEME['warning'], 'border': '#ffb347'},
	'BREACH': {'bg': '#2b0707', 'fg': THEME['danger'], 'detail_fg': THEME['danger'], 'border': THEME['danger']},
}

OPERATOR_ALERT_TONES = {
	'HIGH': {'base': '#211600', 'flash': '#ffb347', 'text': THEME['warning']},
	'CRITICAL': {'base': '#2b0404', 'flash': THEME['danger'], 'text': THEME['danger']},
}

IPV4_PATTERN = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')

# AI engine constants (used in _build_ai_assistant_panel)
DEFAULT_MODEL_HINT  = "llama3.2"
DEFAULT_TOOL_COUNT  = list(range(11))  # 11 tools available

WORLD_OUTLINES = [
	{
		"name": "north_america",
		"points": [
			(-168, 72), (-150, 70), (-135, 65), (-120, 60), (-110, 55), (-100, 50),
			(-90, 45), (-85, 30), (-95, 20), (-110, 15), (-125, 25), (-140, 35),
			(-150, 45), (-160, 60)
		]
	},
	{
		"name": "south_america",
		"points": [
			(-82, 12), (-70, 15), (-65, 5), (-60, -5), (-58, -15), (-62, -25),
			(-70, -35), (-75, -50), (-66, -54), (-60, -40), (-55, -25), (-60, -10)
		]
	},
	{
		"name": "europe",
		"points": [
			(-10, 72), (5, 68), (20, 65), (30, 60), (35, 55), (40, 50), (30, 45),
			(15, 43), (5, 50), (-5, 55)
		]
	},
	{
		"name": "africa",
		"points": [
			(10, 37), (20, 32), (30, 25), (40, 15), (45, 5), (35, -5), (25, -15),
			(20, -25), (15, -35), (5, -35), (-5, -20), (-10, 0), (0, 15), (5, 25)
		]
	},
	{
		"name": "asia",
		"points": [
			(30, 70), (60, 70), (90, 60), (110, 50), (120, 40), (130, 30), (140, 20),
			(135, 5), (120, -5), (100, -10), (80, 0), (60, 10), (50, 30), (40, 45)
		]
	},
	{
		"name": "australia",
		"points": [
			(110, -10), (120, -20), (135, -25), (150, -30), (155, -35), (145, -40),
			(130, -40), (120, -30)
		]
	},
	{
		"name": "greenland",
		"points": [
			(-52, 80), (-30, 78), (-20, 74), (-30, 70), (-40, 68), (-50, 70)
		]
	}
]


class GunnyVoiceDesktop:
	"""Lightweight persona wrapper for Gunny responses."""

	def __init__(self, message_sink: Optional[Callable[[str], None]] = None):
		self._lock = threading.Lock()
		self.tts_engine = self._configure_voice() if TTS_AVAILABLE else None

		self._windows_voice_enabled = sys.platform.startswith('win')
		self._message_sink = message_sink
		self._bucket_map = {
			"startup": "consigliere",
			"threat": "gunny",
			"scan": "disapproval",
			"scan_complete": "consigliere",
			"status": "disdain",
			"alert": "cease",
		}

	def speak_async(self, text: str) -> None:
		threading.Thread(target=self._speak, args=(text,), daemon=True).start()

	def bark(self, category: str) -> None:
		bucket = self._bucket_map.get(category, 'disdain')
		text = persona_line(bucket)
		self.speak_async(text)

	def _speak(self, text: str) -> None:
		with self._lock:
			print(f"[GUNNY] {text}")
			if self._message_sink:
				self._message_sink(f"Gunny: {text}")
			if self.tts_engine:
				try:
					self.tts_engine.say(text)
					self.tts_engine.runAndWait()
				except Exception as exc:
					print(f"[WARNING] Gunny voice offline: {exc}")
					self.tts_engine = None
			elif self._windows_voice_enabled:
				self._speak_via_windows(text)

	def _configure_voice(self):
		try:
			engine = pyttsx3.init()
			voices = engine.getProperty('voices')
			for voice in voices:
				name = getattr(voice, 'name', '').lower()
				if 'male' in name and 'female' not in name:
					engine.setProperty('voice', voice.id)
					break
			engine.setProperty('rate', 190)
			engine.setProperty('volume', 1.0)
			try:
				engine.setProperty('pitch', 70)
			except Exception:
				pass
			return engine
		except Exception as exc:
			print(f"[WARNING] Unable to initialize Gunny voice: {exc}")
			return None

	def _speak_via_windows(self, text: str) -> None:
		if not sys.platform.startswith('win'):
			return
		escaped = json.dumps(text)
		script = (
			"Add-Type -AssemblyName System.Speech;"
			"$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
			"try { $speak.SelectVoiceByHints([System.Speech.Synthesis.VoiceGender]::Male, [System.Speech.Synthesis.VoiceAge]::Senior) } catch { }"
			"$speak.Rate = 0; $speak.Volume = 100;"
			f"$speak.Speak({escaped});"
		)
		creationflags = 0
		if hasattr(subprocess, 'CREATE_NO_WINDOW'):
			creationflags = subprocess.CREATE_NO_WINDOW
		subprocess.Popen(
			['powershell.exe', '-NoProfile', '-Command', script],
			stdout=subprocess.DEVNULL,
			stderr=subprocess.DEVNULL,
			creationflags=creationflags
		)


class Tooltip:
	"""Minimal tooltip helper for Tk widgets."""

	def __init__(self, widget: tk.Widget, text: str, delay_ms: int = 450):
		self.widget = widget
		self.text = text
		self.delay_ms = delay_ms
		self._after_id: Optional[str] = None
		self._tip_window: Optional[tk.Toplevel] = None
		widget.bind('<Enter>', self._schedule, add='+')
		widget.bind('<Leave>', self._hide, add='+')
		widget.bind('<ButtonPress>', self._hide, add='+')

	def _schedule(self, _event=None) -> None:
		self._cancel_pending()
		self._after_id = self.widget.after(self.delay_ms, self._show)

	def _show(self) -> None:
		self._after_id = None
		if self._tip_window or not self.text:
			return
		x = self.widget.winfo_rootx() + self.widget.winfo_width() // 2
		y = self.widget.winfo_rooty() + self.widget.winfo_height() + 12
		self._tip_window = tw = tk.Toplevel(self.widget)
		tw.wm_overrideredirect(True)
		tw.wm_geometry(f"+{x}+{y}")
		tw.attributes('-topmost', True)
		label = tk.Label(
			tw,
			text=self.text,
			justify=tk.LEFT,
			background='#051013',
			foreground=THEME['text'],
			relief=tk.SOLID,
			borderwidth=1,
			font=('Consolas', 10),
			wraplength=240,
			padx=8,
			pady=4,
		)
		label.pack()

	def _hide(self, _event=None) -> None:
		self._cancel_pending()
		if self._tip_window:
			self._tip_window.destroy()
			self._tip_window = None

	def _cancel_pending(self) -> None:
		if self._after_id:
			try:
				self.widget.after_cancel(self._after_id)
			except Exception:
				pass
			self._after_id = None


class SEREDesktopGUI:
	RELENTLESS_ALERT_THRESHOLD = 4
	MISSION_BUTTON_WIDTH = 18
	RADAR_COMMAND_MIN_WIDTH = 260
	RADAR_STACK_THRESHOLD = 760
	"""Desktop command interface that mirrors the CLI's security engine."""

	def __init__(self):
		# Trusted IP whitelist (add your own IPs here)
		self.trusted_ips = set([
			'20.42.65.90', '20.59.87.226', '140.82.113.22', '13.66.138.105', '20.42.72.131', '140.82.114.22'
		])
		self.engine = SEREProtectionEngine()
		self.engine_lock = threading.Lock()
		self.monitor_stop = threading.Event()
		self.monitor_thread: Optional[threading.Thread] = None
		self.monitor_paused = False
		self.manual_scan_thread: Optional[threading.Thread] = None
		self._big_meanie_thread: Optional[threading.Thread] = None
		self._scan_progress_job: Optional[str] = None
		self._seen_threat_ids: Set[str] = set()
		self.sere_phase = SEREPhase.SURVIVE
		self.threat_log_path = Path(os.getcwd()) / "threat_log.txt"
		self.threat_log_path.touch(exist_ok=True)
		self.monitor_interval = 3.0
		self.scan_buttons = []
		self._radar_angle = 0
		self._radar_targets: List[tuple] = []
		self._radar_job: Optional[str] = None
		self._crt_scanline_offset = 0
		self.geolocation_cache: Dict[str, Dict[str, str]] = {}
		self._geo_pending: Set[str] = set()
		self._latest_threats: List[DetectedThreat] = []
		self.threat_assessment_win: Optional[tk.Toplevel] = None
		self.report_window: Optional[tk.Toplevel] = None
		self._report_quarantine_tree: Optional[ttk.Treeview] = None
		self._report_threat_tree: Optional[ttk.Treeview] = None
		self.globe_canvas: Optional[tk.Canvas] = None
		self._globe_job: Optional[str] = None
		self._globe_rotation = 0.0
		self._globe_points: List[Dict[str, Any]] = []
		self._globe_listbox: Optional[tk.Listbox] = None
		self.satellite_canvas: Optional[tk.Canvas] = None
		self.wave_canvas: Optional[tk.Canvas] = None
		self.cpu_bar = None
		self.mem_bar = None
		self.disk_bar = None
		self.metrics_canvas: Optional[tk.Canvas] = None
		self.tactical_canvas: Optional[tk.Canvas] = None
		self.map_canvas: Optional[tk.Canvas] = None
		self.countermeasure_board: Optional[scrolledtext.ScrolledText] = None
		self._radar_inner_frame: Optional[tk.Frame] = None
		self._radar_command_frame: Optional[tk.Frame] = None
		self._radar_command_vertical = False
		self._wave_phase = 0.0
		self._satellite_phase = 0.0
		self._tactical_phase = 0.0
		self._map_pulse = 0.0
		self._satellite_job: Optional[str] = None
		self._wave_job: Optional[str] = None
		self._tactical_job: Optional[str] = None
		self._map_job: Optional[str] = None
		self._last_log_voice = 0.0
		self._log_voice_cooldown = 6.0
		self._threat_signature_counts: Dict[str, int] = {}
		self._relentless_announced: Set[str] = set()
		self._obtuse_defense_latched = False
		self.gunny_muted = False
		self._gunny_button: Optional[ttk.Button] = None
		self._mode_button: Optional[ttk.Button] = None
		self._hyper_watch_button: Optional[ttk.Button] = None
		self._realtime_button: Optional[ttk.Button] = None
		self._escalate_buttons: List[Tuple[tk.Widget, str]] = []
		self.escalation_banner: Optional[tk.Frame] = None
		self._escalation_state_label: Optional[tk.Label] = None
		self._escalation_detail_label: Optional[tk.Label] = None
		self._current_escalation_state: Optional[str] = None
		self.operator_alert_frame: Optional[tk.Frame] = None
		self._operator_alert_label: Optional[tk.Label] = None
		self._operator_ack_button: Optional[ttk.Button] = None
		self._operator_alert_visible = False
		self._operator_alert_active = False
		self._operator_alert_job: Optional[str] = None
		self._operator_alert_tone = 'HIGH'
		self._operator_alert_strobe_state = False
		self._process_sentinel_text: Optional[scrolledtext.ScrolledText] = None
		self._process_cycle_counter = 0
		self._panel_windows: dict = {}
		self._tooltips: List[Tooltip] = []
		self.report_export_dir = Path(os.getcwd()) / "sere_reports"
		self.report_export_dir.mkdir(exist_ok=True)

		self.root = tk.Tk()
		self.root.title("S.E.R.E. Security Suite — Tactical Operations Console")
		self.root.configure(bg=THEME['bg'])
		self.root.geometry("1200x780")
		self.root.minsize(1024, 680)
		self._show_splash_screen()

		self.gunny = GunnyVoiceDesktop(self._queue_gunny_message)
		self.engine.suppress_console_output = True
		self.engine.register_log_listener(self._handle_engine_log_event)

		self._init_state_vars()
		self._build_ui()
		self._bootstrap_engine_logs()
		self._start_monitoring()
		self.root.protocol("WM_DELETE_WINDOW", self.shutdown)
		self._log_console("SERE Desktop ready. Real-time protection engaged.")
		self._maybe_show_onboarding()
		self._init_ai_agent()
		self.root.after(800, lambda: self._toggle_panel('ai', 'AI Support', self._build_ai_assistant_panel, 900, 680))

	def run(self) -> None:
		self.root.mainloop()

	def _init_ai_agent(self) -> None:
		"""Initialise the Ollama-backed SERE AI agent (non-blocking probe)."""
		self.ai_agent: Optional[Any] = None
		if not _AI_ENGINE_AVAILABLE:
			return
		try:
			ollama = OllamaClient()
			self.ai_agent = SEREAIAgent(self.engine, ollama)
			# Background probe — don't block startup
			threading.Thread(
				target=self.ai_agent.ollama.probe,
				daemon=True,
				name="sere-ai-probe"
			).start()
		except Exception as exc:
			self._log_console(f"[AI] Failed to init agent: {exc}")

	def _maybe_show_onboarding(self) -> None:
		"""Show a first-run orientation modal if the sentinel file is absent."""
		sentinel = Path(os.getcwd()) / 'sere_firstrun.flag'
		if sentinel.exists():
			return

		win = tk.Toplevel(self.root)
		win.title("S.E.R.E. — Welcome")
		win.configure(bg=THEME['bg'])
		win.resizable(False, False)
		win.grab_set()

		tk.Label(
			win, text="Welcome to S.E.R.E. Desktop",
			font=('Consolas', 16, 'bold'), fg=THEME['accent'], bg=THEME['bg']
		).pack(padx=28, pady=(22, 4), anchor='w')
		tk.Label(
			win, text="A calm quick-start guide for your first session",
			font=('Consolas', 11), fg=THEME['text'], bg=THEME['bg']
		).pack(padx=28, anchor='w', pady=(0, 14))

		sections = [
			("Quick Start",
			 "Gunny Voice: turn voice guidance on or off at any time.\n"
			 "Detection Mode: REAL mode stays enabled for host safety.\n"
			 "Scans: use Start Scan or Full Sweep in Mission Commands.\n"
			 "Exit: close the main window for a clean shutdown."),
			("Layout Overview",
			 "Left: satellite, geo, process sentinel, and topo scan.\n"
			 "Center: tactical radar and phase commands.\n"
			 "Right: status, threat feed, incidents, and countermeasures."),
			("Primary Controls",
			 "Start Scan / Full Sweep: run a security sweep.\n"
			 "Hyper Watch: enable continuous drift-suppression monitoring.\n"
			 "Toggle Real-Time: pause or resume live protection.\n"
			 "Escalate: manually step from RESIST to ESCAPE when needed."),
			("Panel Notes",
			 "Quick Scan and Full Scan are anchored in Mission Commands.\n"
			 "Gunny Voice ACTIVE/MUTED toggles guided voice responses.\n"
			 "REAL mode is intentionally enforced by design."),
			("Process Sentinel",
			 "Refreshes every 5 monitor cycles with live host processes.\n"
			 "Yellow rows indicate high CPU/memory. Red rows flag suspicious names."),
		]
		for title, body in sections:
			frame = tk.Frame(win, bg=THEME['panel'], padx=16, pady=10)
			frame.pack(fill=tk.X, padx=28, pady=(0, 8))
			tk.Label(frame, text=title, font=('Consolas', 11, 'bold'),
					 fg=THEME['accent'], bg=THEME['panel']).pack(anchor='w')
			tk.Label(frame, text=body, font=('Consolas', 10),
					 fg=THEME['text'], bg=THEME['panel'],
					 justify=tk.LEFT, wraplength=520).pack(anchor='w', pady=(4, 0))

		def _dismiss():
			try:
				sentinel.touch()
			except Exception:
				pass
			win.destroy()

		ttk.Button(
			win, text="Open Console",
			command=_dismiss, style='SERE.TButton'
		).pack(pady=(10, 22))

		win.update_idletasks()
		w = win.winfo_reqwidth(); h = win.winfo_reqheight()
		sw = win.winfo_screenwidth(); sh = win.winfo_screenheight()
		win.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")
		win.focus_force()

	# ------------------------------------------------------------------
	# Initialization helpers
	# ------------------------------------------------------------------
	def _init_state_vars(self) -> None:
		self.phase_var = tk.StringVar(value=PHASE_NAMES[self.sere_phase])
		self.phase_desc_var = tk.StringVar(value=PHASE_DESCRIPTIONS[self.sere_phase])
		self.status_var = tk.StringVar(value="Active Protection")
		self.hyper_watch_var = tk.StringVar(value="Hyper Watch: ENGAGED")
		self.hyper_watch_detail_var = tk.StringVar(value="Last Hyper Defense: Awaiting telemetry.")
		self.mode_var = tk.StringVar(value="Detection Mode: REAL")
		self.gunny_last_var = tk.StringVar(value="Gunny online. Awaiting telemetry.")
		self.score_var = tk.StringVar(value="100")
		self.active_threats_var = tk.StringVar(value="0")
		self.quarantine_var = tk.StringVar(value="0")
		self.blocked_var = tk.StringVar(value="0")
		self.last_event_var = tk.StringVar(value="Awaiting telemetry...")
		self.scan_status_var = tk.StringVar(value="Standing by")
		self.scan_progress_var = tk.DoubleVar(value=0.0)
		self.cpu_value_var = tk.StringVar(value="0%")
		self.mem_value_var = tk.StringVar(value="0%")
		self.disk_value_var = tk.StringVar(value="0%")
		self.log_path_var = tk.StringVar(value=f"Location: {self.threat_log_path.resolve()}")
		self.threat_detail_var = tk.StringVar(value="Select a threat to view details.")
		self.escalation_state_var = tk.StringVar(value="STATE: IDLE")
		self.escalation_detail_var = tk.StringVar(value="Perimeter secure. No active hostiles.")
		self.operator_alert_var = tk.StringVar(value="No priority alerts.")
		self.incident_root_var = tk.StringVar(value="No active incidents. Perimeter calm.")
		self.incident_assets_var = tk.StringVar(value="Assets secure. No telemetry anomalies.")
		self.incident_response_var = tk.StringVar(value="Recommended response: Standby.")
		self.countermeasure_status_var = tk.StringVar(value="Countermeasures nominal.")
		self.report_summary_var = tk.StringVar(value="Report telemetry not yet available.")

	def _attach_tooltip(self, widget: tk.Widget, text: Optional[str]) -> None:
		if not widget or not text:
			return
		tooltip = Tooltip(widget, text)
		self._tooltips.append(tooltip)

	def _apply_toggle_palette(self, button: Optional[tk.Widget], engaged: bool) -> None:
		"""Switch button cosmetics between idle (white) and engaged (red)."""
		if not button:
			return
		try:
			widget_class = button.winfo_class().lower()
		except Exception:
			widget_class = ''
		if widget_class == 'tbutton':
			style_name = 'SERE.Engaged.TButton' if engaged else 'SERE.TButton'
			button.configure(style=style_name)
			return
		bg = THEME['button_engaged'] if engaged else THEME['button']
		fg = THEME['text'] if engaged else THEME['button_text']
		active_bg = THEME['button_engaged_active'] if engaged else THEME['button_active']
		button.configure(bg=bg, fg=fg, activebackground=active_bg, activeforeground=fg)

	def _refresh_toggle_buttons(self) -> None:
		"""Refresh mission toggles so they reflect their live state."""
		hyper_enabled = getattr(self.engine, 'hyper_watch_enabled', True)
		self._apply_toggle_palette(self._hyper_watch_button, hyper_enabled)
		self._apply_toggle_palette(self._realtime_button, not self.monitor_paused)

	def _build_ui(self) -> None:
		style = ttk.Style()
		style.theme_use('clam')
		style.configure('SERE.TFrame', background=THEME['bg'])
		style.configure(
			'SERE.TButton',
			font=('Consolas', 12, 'bold'),
			background=THEME['button'],
			foreground=THEME['button_text'],
			borderwidth=1,
			focuscolor=THEME['accent'],
			padding=(12, 8)
		)
		style.map(
			'SERE.TButton',
			background=[('disabled', '#d7d2c7'), ('pressed', '#ecd4c0'), ('active', THEME['button_active'])],
			foreground=[('disabled', '#7c776d'), ('active', THEME['button_text'])],
			bordercolor=[('focus', THEME['accent']), ('!focus', THEME['button'])]
		)
		style.configure(
			'SERE.Engaged.TButton',
			font=('Consolas', 12, 'bold'),
			background=THEME['button_engaged'],
			foreground=THEME['text'],
			borderwidth=1,
			focuscolor=THEME['button_engaged'],
			padding=(12, 8)
		)
		style.map(
			'SERE.Engaged.TButton',
			background=[('disabled', '#6d1512'), ('pressed', THEME['button_engaged_active']), ('active', THEME['button_engaged_active'])],
			foreground=[('disabled', '#f7d7d2'), ('active', THEME['text'])],
			bordercolor=[('focus', '#ff9a8b'), ('!focus', THEME['button_engaged'])]
		)
		style.configure('SERE.Horizontal.TProgressbar', troughcolor=THEME['panel'], bordercolor=THEME['panel'], background=THEME['accent'], lightcolor=THEME['accent'], darkcolor=THEME['accent'])
		style.configure('SERE.Treeview', background=THEME['panel'], fieldbackground=THEME['panel'], foreground=THEME['text'], rowheight=24, borderwidth=0)
		style.configure('SERE.Treeview.Heading', background=THEME['panel'], foreground=THEME['accent'], font=('Consolas', 11, 'bold'))

		container = tk.Frame(self.root, bg=THEME['bg'])
		container.pack(fill=tk.BOTH, expand=True, padx=26, pady=20)
		self._build_header(container)
		self._build_panel_launcher(container)
		self._build_command_bar(container)
		self._build_console_panel(container)
		self._start_visualizers()
        
	def _build_header(self, parent: tk.Frame) -> None:
		header = tk.Frame(parent, bg=THEME['bg'])
		header.pack(fill=tk.X)
		tk.Label(header, text="TACTICAL OPS // S.E.R.E. SECURITY SUITE", font=('Consolas', 26, 'bold'), fg=THEME['accent'], bg=THEME['bg']).pack(anchor='w')
		tk.Label(header, text="Survive • Evade • Resist • Escape", font=('Consolas', 12), fg=THEME['text'], bg=THEME['bg']).pack(anchor='w')
		tk.Label(header, textvariable=self.hyper_watch_var, font=('Consolas', 11), fg=THEME['warning'], bg=THEME['bg']).pack(anchor='w')
		tk.Label(header, textvariable=self.hyper_watch_detail_var, font=('Consolas', 10), fg=THEME['hud_muted'], bg=THEME['bg']).pack(anchor='w')
		tk.Label(header, textvariable=self.mode_var, font=('Consolas', 11), fg=THEME['success'], bg=THEME['bg']).pack(anchor='w')
		banner = tk.Frame(header, bg=THEME['panel'], padx=14, pady=10, highlightbackground=THEME['accent'], highlightthickness=1)
		banner.pack(fill=tk.X, pady=(12, 0))
		self.escalation_banner = banner
		self._escalation_state_label = tk.Label(banner, textvariable=self.escalation_state_var, font=('Consolas', 18, 'bold'), bg=THEME['panel'], fg=THEME['success'])
		self._escalation_state_label.pack(anchor='w')
		self._escalation_detail_label = tk.Label(banner, textvariable=self.escalation_detail_var, font=('Consolas', 11), bg=THEME['panel'], fg=THEME['text'])
		self._escalation_detail_label.pack(anchor='w', pady=(2, 0))
		self._apply_escalation_banner('IDLE', self.escalation_detail_var.get())
		alert_panel = tk.Frame(header, bg=THEME['panel'], padx=14, pady=10, highlightbackground=THEME['warning'], highlightthickness=1)
		self.operator_alert_frame = alert_panel
		self._operator_alert_label = tk.Label(alert_panel, textvariable=self.operator_alert_var, font=('Consolas', 12, 'bold'), bg=THEME['panel'], fg=THEME['warning'])
		self._operator_alert_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
		self._operator_ack_button = ttk.Button(alert_panel, text="Acknowledge", command=self._acknowledge_operator_alert, style='SERE.TButton')
		self._operator_ack_button.pack(side=tk.RIGHT, padx=(12, 0))
		self._operator_alert_visible = False
        
	def _spawn_panel_window(self, key: str, title: str, width: int, height: int) -> tk.Toplevel:
		win = tk.Toplevel(self.root)
		win.configure(bg=THEME['bg'])
		win.geometry(f"{width}x{height}")
		win.title(title)
		win.protocol("WM_DELETE_WINDOW", lambda: self._close_panel(key))
		return win

	def _close_panel(self, key: str) -> None:
		win = self._panel_windows.get(key)
		self._panel_windows[key] = None
		if win is not None:
			try:
				win.destroy()
			except tk.TclError:
				pass

	def _toggle_panel(self, key: str, title: str, build_fn, width: int = 520, height: int = 420) -> None:
		win = self._panel_windows.get(key)
		if win is not None:
			try:
				win.lift()
				win.focus_force()
				return
			except tk.TclError:
				pass
		win = self._spawn_panel_window(key, title, width, height)
		canvas = tk.Canvas(win, bg=THEME['bg'], highlightthickness=0)
		scrollbar = ttk.Scrollbar(win, orient=tk.VERTICAL, command=canvas.yview)
		inner = tk.Frame(canvas, bg=THEME['bg'])
		inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
		canvas.create_window((0, 0), window=inner, anchor='nw')
		canvas.configure(yscrollcommand=scrollbar.set)
		scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
		canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
		build_fn(inner)
		self._panel_windows[key] = win

	def _build_panel_launcher(self, parent: tk.Frame) -> None:
		frame = tk.Frame(parent, bg=THEME['panel'], padx=20, pady=14)
		frame.pack(fill=tk.X, pady=(18, 12))
		tk.Label(
			frame, text="Mission Panels", font=('Consolas', 14, 'bold'),
			fg=THEME['accent'], bg=THEME['panel']
		).grid(row=0, column=0, columnspan=4, sticky='w', pady=(0, 10))

		panels = [
			('satellite',       'Satellite Feed',    self._build_satellite_panel,        480, 360),
			('location',        'Location Intel',    self._build_location_panel,         480, 320),
			('process',         'Process Sentinel',  self._build_process_sentinel_panel, 620, 480),
			('wave',            'Topographic Scan',  self._build_wave_panel,             580, 400),
			('tactical',        'Tactical Status',   self._build_tactical_panel,         560, 380),
			('threatfeed',      'Threat Feed',       self._build_threat_feed_panel,      580, 420),
			('map',             'Sector Map',        self._build_map_panel,              560, 380),
			('incident',        'Incident Log',      self._build_incident_panel,         600, 460),
			('countermeasures', 'Countermeasures',   self._build_countermeasures_panel,  640, 500),
			('integrity',       'Integrity Sweep',   self._build_integrity_sweep_panel,  760, 600),
			('ai',              'AI Support',        self._build_ai_assistant_panel,     900, 680),
		]

		for idx, (key, title, build_fn, w, h) in enumerate(panels):
			row = 1 + idx // 4
			col = idx % 4
			btn = ttk.Button(
				frame,
				text=f"▣ {title}",
				style='SERE.TButton',
				command=lambda k=key, t=title, fn=build_fn, bw=w, bh=h: self._toggle_panel(k, t, fn, bw, bh)
			)
			btn.grid(row=row, column=col, padx=6, pady=4, sticky='ew')
			Tooltip(btn, f"Open the {title} popup window.")
		for c in range(4):
			frame.columnconfigure(c, weight=1)

	def _build_left_column(self, parent: tk.Frame) -> None:
		# Vertical sash — drag to resize panels within the left column
		v_pane = tk.PanedWindow(
			parent, orient=tk.VERTICAL,
			bg=THEME['bg'], sashwidth=6, sashrelief=tk.FLAT,
			handlesize=10, showhandle=False
		)
		v_pane.pack(fill=tk.BOTH, expand=True)

		top_frame = tk.Frame(v_pane, bg=THEME['bg'])
		bottom_frame = tk.Frame(v_pane, bg=THEME['bg'])
		v_pane.add(top_frame,    minsize=80,  stretch='always')
		v_pane.add(bottom_frame, minsize=80,  stretch='always')

		self._build_satellite_panel(top_frame)
		self._build_location_panel(top_frame)
		self._build_process_sentinel_panel(top_frame)
		self._build_wave_panel(bottom_frame)
        
	def _build_right_column(self, parent: tk.Frame) -> None:
		# Vertical sash — drag to resize panels within the right column
		v_pane = tk.PanedWindow(
			parent, orient=tk.VERTICAL,
			bg=THEME['bg'], sashwidth=6, sashrelief=tk.FLAT,
			handlesize=10, showhandle=False
		)
		v_pane.pack(fill=tk.BOTH, expand=True)

		top_frame    = tk.Frame(v_pane, bg=THEME['bg'])
		bottom_frame = tk.Frame(v_pane, bg=THEME['bg'])
		v_pane.add(top_frame,    minsize=80, stretch='always')
		v_pane.add(bottom_frame, minsize=80, stretch='always')

		self._build_tactical_panel(top_frame)
		self._build_threat_feed_panel(top_frame)
		self._build_map_panel(bottom_frame)
		self._build_incident_panel(bottom_frame)
		self._build_countermeasures_panel(bottom_frame)
        
	def _build_command_bar(self, parent: tk.Frame) -> None:
		controls = tk.Frame(parent, bg=THEME['panel'], padx=20, pady=14)
		controls.pack(fill=tk.X, pady=(18, 0))
		buttons_per_row = 6
		tk.Label(controls, text="Mission Commands", font=('Consolas', 14, 'bold'), fg=THEME['accent'], bg=THEME['panel']).grid(row=0, column=0, columnspan=buttons_per_row, sticky='w')
		btn_specs = [
			{
				"label": "Start Scan",
				"cmd": lambda: self.start_scan(ScanProfile.QUICK),
				"scan_control": True,
				"tooltip": "Run a QUICK Survive-phase sweep for fast anomaly triage."
			},
			{
				"label": "Full Sweep",
				"cmd": lambda: self.start_scan(ScanProfile.FULL),
				"scan_control": True,
				"tooltip": "Execute a FULL Resist-phase sweep across every sensor chain."
			},
			{
				"label": "Evade",
				"cmd": self.activate_evade,
				"scan_control": True,
				"tooltip": "Shift S.E.R.E. into EVADE posture to shrink the target surface."
			},
			{
				"label": "Escalate",
				"cmd": self._attempt_escalate,
				"scan_control": True,
				"ref": "escalate",
				"tooltip": "Force RESIST→ESCALATE transition and ready countermeasures."
			},
			{
				"label": "Threat Assessment",
				"cmd": self.open_threat_assessment,
				"tooltip": "Open the intel board with the latest detections, scores, and narratives."
			},
			{
				"label": "Security Report",
				"cmd": self.open_security_report,
				"tooltip": "View quarantine + threat report with export controls."
			},
			{
				"label": "Toggle Real-Time",
				"cmd": self.toggle_realtime,
				"tooltip": "Pause or resume the live telemetry monitor thread.",
				"toggle_ref": "monitor"
			},
			{
				"label": "Hyper Watch",
				"cmd": self.toggle_hyper_watch,
				"tooltip": "Arm Hyper Watch tripwires for relentless drift suppression.",
				"toggle_ref": "hyper_watch"
			},
			{
				"label": "Repair Host",
				"cmd": self.run_system_repair,
				"tooltip": "Trigger host repair + quarantine routines pulled from S.E.R.E. logic."
			},
			{
				"label": "PING FLOOD DEFENSE",
				"cmd": self._launch_ping_flood_dialog,
				"scan_control": True,
				"tooltip": "Deploy ping flood defense against confirmed threat IPs (Mythara Safety Hierarchy enforced)."
			},
			{
				"label": "BIG MEANIE ASSAULT",
				"cmd": self.run_big_meanie_assessment,
				"scan_control": True,
				"tooltip": "Launch Big Meanie adversarial assault and ingest its threat intel."
			},
		]
		self.scan_buttons.clear()
		self._hyper_watch_button = None
		self._realtime_button = None
		for idx, spec in enumerate(btn_specs):
			row = 1 + idx // buttons_per_row
			col = idx % buttons_per_row
			btn = ttk.Button(controls, text=spec["label"], command=spec["cmd"], style=spec.get('style', 'SERE.TButton'))
			btn.config(width=self.MISSION_BUTTON_WIDTH)
			btn.grid(row=row, column=col, padx=4, pady=8, sticky='ew')
			controls.columnconfigure(col, weight=1)
			if spec.get("scan_control"):
				self.scan_buttons.append(btn)
			ref = spec.get("ref")
			if ref == "escalate":
				self._register_escalate_button(btn, spec["label"])
			toggle_ref = spec.get("toggle_ref")
			if toggle_ref == "hyper_watch":
				self._hyper_watch_button = btn
			elif toggle_ref == "monitor":
				self._realtime_button = btn
			self._attach_tooltip(btn, spec.get("tooltip"))
		self._refresh_toggle_buttons()
        
		scan_frame = tk.Frame(parent, bg=THEME['bg'])
		scan_frame.pack(fill=tk.X, pady=(10, 0))
		tk.Label(scan_frame, textvariable=self.scan_status_var, font=('Consolas', 12), fg=THEME['text'], bg=THEME['bg']).pack(anchor='w')
		ttk.Progressbar(scan_frame, style='SERE.Horizontal.TProgressbar', maximum=100, variable=self.scan_progress_var).pack(fill=tk.X, pady=(6, 0))
		tk.Label(scan_frame, textvariable=self.last_event_var, font=('Consolas', 11), fg=THEME['warning'], bg=THEME['bg']).pack(anchor='w', pady=(6, 0))

	def _build_console_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=20, pady=14)
		panel.pack(fill=tk.BOTH, expand=True, pady=(18, 0))
		tk.Label(panel, text="Operations Log", font=('Consolas', 14, 'bold'), fg=THEME['accent'], bg=THEME['panel']).pack(anchor='w')
		tk.Label(panel, text="Gunny telemetry + engine events", font=('Consolas', 10), fg=THEME['hud_muted'], bg=THEME['panel']).pack(anchor='w')
		self.log_text = scrolledtext.ScrolledText(
			panel,
			height=8,
			bg=THEME['bg'],
			fg=THEME['text'],
			insertbackground=THEME['text'],
			relief=tk.FLAT,
			font=('Consolas', 11)
		)
		self.log_text.pack(fill=tk.BOTH, expand=True, pady=(10, 6))
		self.log_text.config(state='disabled')
		self.log_text.tag_config('status', foreground=THEME['text'])
		self.log_text.tag_config('warning', foreground=THEME['warning'])
		self.log_text.tag_config('alert', foreground=THEME['danger'])

		footer = tk.Frame(panel, bg=THEME['panel'])
		footer.pack(fill=tk.X)
		tk.Label(footer, textvariable=self.log_path_var, font=('Consolas', 10), fg=THEME['hud_muted'], bg=THEME['panel']).pack(side=tk.LEFT, anchor='w')
		ttk.Button(footer, text="Open Threat Log", command=self.open_threat_log, style='SERE.TButton').pack(side=tk.RIGHT)

	# ── AI SUPPORT ENGINE ─────────────────────────────────────────────────────
	_AI_GREETINGS = [
		"SERE Intelligence online. What do you need, recruit?",
		"AI Support ready. Ask me about threats, health, or countermeasures.",
		"System nominal. Standing by for your query.",
	]
	_AI_UNKNOWN = [
		"Query not recognized. Try: 'threats', 'health', 'processes', 'recommend', 'hierarchy', 'help'.",
		"I didn't catch that. Say 'help' for a list of commands.",
		"Clarify your request. I'm precise, not psychic.",
	]
	_AI_CMD_MAP = {
		# keyword → handler method name
		'threat':      '_ai_threats',
		'active':      '_ai_threats',
		'detected':    '_ai_threats',
		'health':      '_ai_health',
		'status':      '_ai_health',
		'process':     '_ai_processes',
		'proc':        '_ai_processes',
		'pid':         '_ai_processes',
		'network':     '_ai_network',
		'connection':  '_ai_network',
		'recommend':   '_ai_recommend',
		'suggest':     '_ai_recommend',
		'advise':      '_ai_recommend',
		'hierarchy':   '_ai_hierarchy',
		'safety':      '_ai_hierarchy',
		'mythara':     '_ai_hierarchy',
		'scan':        '_ai_scan',
		'sweep':       '_ai_scan',
		'quarantine':  '_ai_quarantine',
		'block':       '_ai_quarantine',
		'ping':        '_ai_ping',
		'flood':       '_ai_ping',
		'metric':      '_ai_metrics',
		'stat':        '_ai_metrics',
		'count':       '_ai_metrics',
		'help':        '_ai_help',
		'command':     '_ai_help',
		'hyper':       '_ai_hyper',
		'watch':       '_ai_hyper',
		'mode':        '_ai_mode',
		'real':        '_ai_mode',
		'sim':         '_ai_mode',
		'phase':       '_ai_phase',
		'evade':       '_ai_phase',
		'escape':      '_ai_phase',
		'resist':      '_ai_phase',
		'survive':     '_ai_phase',
		'report':      '_ai_report',
		'export':      '_ai_report',
		'integrity':   '_ai_integrity',
		'sweep':       '_ai_integrity',
		'file':        '_ai_integrity',
		'hash':        '_ai_integrity',
	}

	def _ai_respond(self, query: str) -> str:
		"""Route a user query through the rule-based AI engine and return a response."""
		import random
		q = query.strip().lower()
		if not q:
			return random.choice(self._AI_GREETINGS)
		for keyword, handler_name in self._AI_CMD_MAP.items():
			if keyword in q:
				handler = getattr(self, handler_name, None)
				if handler:
					return handler(q)
		return random.choice(self._AI_UNKNOWN)

	def _ai_threats(self, _q: str) -> str:
		threats = list(getattr(self.engine, 'detected_threats', []))
		if not threats:
			return "✅ No active threats detected. All sensors nominal."
		lines = [f"⚠ {len(threats)} threat(s) on record:"]
		for t in threats[:6]:
			sev  = getattr(t, 'severity', '?')
			src  = getattr(t, 'source_ip', None) or getattr(t, 'process_name', '?')
			kind = getattr(t, 'threat_type', '?')
			lines.append(f"  • [{sev}] {kind} — {src}")
		if len(threats) > 6:
			lines.append(f"  … and {len(threats)-6} more. Open Threat Feed for full list.")
		lines.append("Recommended: run Escalate if severity is CRITICAL.")
		return "\n".join(lines)

	def _ai_health(self, _q: str) -> str:
		try:
			h = self.engine.get_system_health()
			score = h.protection_score
			cpu   = h.cpu_percent
			mem   = h.memory_percent
			disk  = h.disk_percent
			fw    = h.firewall_status
			procs = h.running_processes
			susp  = h.suspicious_processes
			lines = [
				f"🛡 Protection Score: {score}/100",
				f"   CPU {cpu:.1f}%  |  Memory {mem:.1f}%  |  Disk {disk:.1f}%",
				f"   Firewall: {fw}  |  Processes: {procs}  |  Suspicious: {susp}",
			]
			if cpu > 80:
				lines.append("⚠ CPU pressure is HIGH. Consider running Evade.")
			if susp > 0:
				lines.append(f"⚠ {susp} suspicious process(es) flagged. Review Process Sentinel.")
			if score < 60:
				lines.append("🔴 Protection score is LOW. Run Full Sweep immediately.")
			elif score < 85:
				lines.append("🟡 Protection score is moderate. Consider a Quick Scan.")
			else:
				lines.append("✅ System in healthy operational state.")
			return "\n".join(lines)
		except Exception as e:
			return f"Health telemetry unavailable: {e}"

	def _ai_processes(self, _q: str) -> str:
		try:
			import psutil
			procs = []
			for p in psutil.process_iter(['pid','name','cpu_percent','memory_percent']):
				try:
					procs.append(p.info)
				except Exception:
					continue
			procs.sort(key=lambda x: (x.get('cpu_percent') or 0)+(x.get('memory_percent') or 0), reverse=True)
			susp_names = getattr(self.engine, 'SUSPICIOUS_PROCESSES', [])
			lines = [f"🔍 Top processes by load ({len(procs)} total):"]
			for p in procs[:8]:
				name = (p.get('name') or '?')[:24]
				cpu  = p.get('cpu_percent') or 0.0
				mem  = p.get('memory_percent') or 0.0
				flag = " 🔴 SUSPICIOUS" if any(s in (p.get('name') or '').lower() for s in susp_names) else ""
				lines.append(f"  PID {p.get('pid'):>6}  {name:<24}  CPU {cpu:>5.1f}%  MEM {mem:>4.1f}%{flag}")
			return "\n".join(lines)
		except Exception as e:
			return f"Process telemetry unavailable: {e}"

	def _ai_network(self, _q: str) -> str:
		try:
			conns = self.engine.get_network_connections() if hasattr(self.engine, 'get_network_connections') else []
			if not conns:
				return "📡 No active network connections in log, or method unavailable."
			lines = [f"📡 {len(conns)} network connection(s):"]
			for c in conns[:8]:
				lines.append(f"  {c}")
			return "\n".join(lines)
		except Exception as e:
			return f"Network data unavailable: {e}"

	def _ai_recommend(self, _q: str) -> str:
		try:
			h = self.engine.get_system_health()
			threats = list(getattr(self.engine, 'detected_threats', []))
			recs = []
			if len(threats) > 0:
				recs.append("1. 🔴 Active threats present → Run 'Escalate' immediately.")
			if h.suspicious_processes > 0:
				recs.append(f"2. ⚠ {h.suspicious_processes} suspicious process(es) → Open Process Sentinel, identify and terminate.")
			if h.cpu_percent > 80:
				recs.append("3. 🟡 High CPU → Activate Evade mode to reduce attack surface.")
			if h.protection_score < 75:
				recs.append("4. 🟡 Low protection score → Run Full Sweep.")
			if not recs:
				recs.append("✅ No immediate action required. System is in good standing.")
				recs.append("Suggested: Keep Hyper Watch armed and run weekly Full Sweeps.")
			return "🤖 SERE Recommendations:\n" + "\n".join(recs)
		except Exception as e:
			return f"Recommendation engine error: {e}"

	def _ai_hierarchy(self, _q: str) -> str:
		return (
			"🛡 Mythara Safety Hierarchy (5 Levels):\n"
			"  1. Preservation of Life           ← highest priority\n"
			"  2. Preservation of Safety\n"
			"  3. Preservation of Autonomy & Dignity\n"
			"  4. Preservation of Lawful Presence\n"
			"  5. Preservation of Continuity     ← baseline\n\n"
			"Every aggressive action (quarantine, block, ping flood)\n"
			"passes all 5 levels before executing. Violations are rejected\n"
			"and logged with level detail."
		)

	def _ai_scan(self, _q: str) -> str:
		return (
			"🔍 Scan Options:\n"
			"  • Quick Scan  — fast triage sweep (Survive phase)\n"
			"  • Full Sweep  — deep Resist-phase pass across all sensors\n"
			"  • Full System Run — full multi-phase operation (via Escalate)\n\n"
			"Use Mission Commands in the main window to trigger scans.\n"
			"Results appear in the Operations Log and Threat Feed."
		)

	def _ai_quarantine(self, _q: str) -> str:
		try:
			q = self.engine.get_quarantine_snapshot() if hasattr(self.engine, 'get_quarantine_snapshot') else []
			if not q:
				return "🔒 Quarantine zone is empty. No IPs or processes currently isolated."
			lines = [f"🔒 Quarantine — {len(q)} item(s):"]
			for z in q[:6]:
				ip     = z.get('ip', '?')
				kind   = z.get('type', '?')
				status = z.get('status', '?')
				lines.append(f"  {ip}  [{kind}]  {status}")
			return "\n".join(lines)
		except Exception as e:
			return f"Quarantine data unavailable: {e}"

	def _ai_ping(self, _q: str) -> str:
		try:
			ps = self.engine.get_ping_snapshot() if hasattr(self.engine, 'get_ping_snapshot') else []
			if not ps:
				return "📶 No IPs currently under ping defense monitoring."
			lines = [f"📶 Ping Defense — {len(ps)} target(s) monitored:"]
			for m in ps[:6]:
				ip    = m.get('ip', '?')
				alive = "STABLE" if m.get('alive') else f"FAIL ×{m.get('failures',0)}"
				lines.append(f"  {ip}  {alive}")
			return "\n".join(lines)
		except Exception as e:
			return f"Ping defense data unavailable: {e}"

	def _ai_metrics(self, _q: str) -> str:
		try:
			m = getattr(self.engine, 'metrics', {})
			if not m:
				return "No metrics available."
			lines = ["📊 Engine Metrics:"]
			for k, v in m.items():
				lines.append(f"  {k.replace('_',' ').title():<32} {v}")
			return "\n".join(lines)
		except Exception as e:
			return f"Metrics unavailable: {e}"

	def _ai_hyper(self, _q: str) -> str:
		try:
			hs = self.engine.get_hyper_status() if hasattr(self.engine, 'get_hyper_status') else {}
			enabled = hs.get('enabled', False)
			events  = hs.get('events', 0)
			last    = hs.get('last_event') or {}
			state   = "✅ ENGAGED" if enabled else "⛔ STANDBY"
			lines   = [
				f"🔭 Hyper Watch: {state}",
				f"   Events logged: {events}",
			]
			if last:
				lines.append(f"   Last event: {last.get('attack','?')} from {last.get('source','?')}")
			lines.append("Use 'Hyper Watch' button in Mission Commands to toggle.")
			return "\n".join(lines)
		except Exception as e:
			return f"Hyper Watch data unavailable: {e}"

	def _ai_mode(self, _q: str) -> str:
		return (
			"🟢 Detection Mode: REAL\n"
			"Simulation is permanently disabled per Mythara spec.\n"
			"S.E.R.E. operates exclusively on live threat telemetry."
		)

	def _ai_phase(self, _q: str) -> str:
		phase = getattr(self, 'sere_phase', 0)
		phase_index = phase.value if isinstance(phase, SEREPhase) else phase
		phase_names = ['SURVIVE', 'EVADE', 'RESIST', 'ESCAPE']
		phase_desc  = [
			'Active monitoring — baseline defense posture.',
			'Attack surface minimized — low-profile operation.',
			'Countermeasures deployed — active threat suppression.',
			'Full escalation — maximum force authorized.',
		]
		name = phase_names[phase_index] if isinstance(phase_index, int) and phase_index < len(phase_names) else f'Phase {phase}'
		desc = phase_desc[phase_index] if isinstance(phase_index, int) and phase_index < len(phase_desc) else ''
		return f"🎯 Current Phase: {name}\n   {desc}\n\nPhases: SURVIVE → EVADE → RESIST → ESCAPE"

	def _ai_integrity(self, _q: str) -> str:
		return (
			"🔬 Integrity Sweep — 6-Phase Auto-Response Pipeline:\n"
			"  Phase 1: File hash scan (SHA-256 vs known-malicious DB)\n"
			"           + suspicious filename pattern matching\n"
			"  Phase 2: Process anomaly scan (running processes)\n"
			"  Phase 3: Network anomaly scan (connections + ports)\n"
			"  Phase 4: HyperWatch deep event scan\n"
			"  Phase 5: Auto-quarantine / block (Mythara Safety Hierarchy)\n"
			"  Phase 6: Incident investigation via playbook (per IP)\n\n"
			"Open ▣ Integrity Sweep from the panel launcher to run it.\n"
			"You can choose target directories and toggle auto-quarantine."
		)

	def _ai_report(self, _q: str) -> str:
		return (
			"📋 Reports:\n"
			"  • Security Report — full quarantine + threat summary with export\n"
			"  • Threat Assessment — live intel board, scores, narratives\n\n"
			"Access both via Mission Commands in the main window.\n"
			"Reports are saved to the 'sere_reports' folder."
		)

	def _ai_help(self, _q: str) -> str:
		return (
			"🤖 SERE AI — Available Commands:\n"
			"  threats / active     — show detected threats\n"
			"  health / status      — system health snapshot\n"
			"  processes / pid      — top running processes\n"
			"  network              — active connections\n"
			"  recommend / advise   — action recommendations\n"
			"  integrity / sweep    — integrity sweep info\n"
			"  scan / sweep         — scan information\n"
			"  quarantine / block   — quarantine zone status\n"
			"  ping / flood         — ping defense monitor\n"
			"  hyper / watch        — Hyper Watch status\n"
			"  hierarchy / safety   — Mythara Safety Hierarchy\n"
			"  phase / evade        — current operational phase\n"
			"  metrics / stats      — engine telemetry counters\n"
			"  mode / real          — detection mode info\n"
			"  report / export      — reporting options\n"
			"  help                 — this message"
		)

	def _build_integrity_sweep_panel(self, parent: tk.Frame) -> None:
		"""Integrity Sweep & Auto-Response panel — scan, detect, quarantine, investigate."""
		outer = tk.Frame(parent, bg=THEME['bg'])
		outer.pack(fill=tk.BOTH, expand=True)

		# ── Header ────────────────────────────────────────────────────────────
		hdr = tk.Frame(outer, bg=THEME['panel'], padx=16, pady=12)
		hdr.pack(fill=tk.X)
		tk.Label(hdr, text="🔬  INTEGRITY SWEEP & AUTO-RESPONSE",
				 font=('Consolas', 14, 'bold'), fg=THEME['accent'], bg=THEME['panel']).pack(anchor='w')
		tk.Label(hdr, text="Hash scan · anomaly detection · auto-quarantine · incident investigation",
				 font=('Consolas', 10), fg=THEME['hud_muted'], bg=THEME['panel']).pack(anchor='w')

		# ── Config row ────────────────────────────────────────────────────────
		cfg = tk.Frame(outer, bg=THEME['panel'], padx=16, pady=10)
		cfg.pack(fill=tk.X, pady=(8, 0))

		tk.Label(cfg, text="Target Dirs (comma-separated, blank = defaults):",
				 font=('Consolas', 10), fg=THEME['text'], bg=THEME['panel']).grid(
				 row=0, column=0, sticky='w', columnspan=3)
		dir_var = tk.StringVar()
		dir_entry = tk.Entry(cfg, textvariable=dir_var, font=('Consolas', 10),
							 bg=THEME['bg'], fg=THEME['text'],
							 insertbackground=THEME['text'], relief=tk.FLAT, width=60)
		dir_entry.grid(row=1, column=0, sticky='ew', pady=4, padx=(0, 8))
		cfg.columnconfigure(0, weight=1)

		def _browse_dir() -> None:
			from tkinter import filedialog
			d = filedialog.askdirectory(title="Add target directory")
			if d:
				current = dir_var.get().strip()
				dir_var.set(f"{current}, {d}" if current else d)
		tk.Button(cfg, text="Browse…", command=_browse_dir,
				  font=('Consolas', 10), bg=THEME['button'], fg=THEME['button_text'],
				  relief=tk.FLAT).grid(row=1, column=1, padx=(0, 8))

		auto_q_var = tk.BooleanVar(value=True)
		tk.Checkbutton(cfg, text="Auto-Quarantine threats",
					   variable=auto_q_var, font=('Consolas', 10),
					   bg=THEME['panel'], fg=THEME['text'], selectcolor=THEME['bg'],
					   activebackground=THEME['panel']).grid(row=1, column=2, sticky='w')

		# ── Progress ──────────────────────────────────────────────────────────
		prog_frame = tk.Frame(outer, bg=THEME['bg'], padx=16, pady=6)
		prog_frame.pack(fill=tk.X)
		sweep_status_var = tk.StringVar(value="Idle — configure target directories and press Launch.")
		tk.Label(prog_frame, textvariable=sweep_status_var, font=('Consolas', 10),
				 fg=THEME['hud_muted'], bg=THEME['bg']).pack(anchor='w')
		sweep_prog_var = tk.DoubleVar(value=0)
		sweep_bar = ttk.Progressbar(prog_frame, variable=sweep_prog_var,
									style='SERE.Horizontal.TProgressbar', maximum=100)
		sweep_bar.pack(fill=tk.X, pady=(4, 0))

		# ── Log output ────────────────────────────────────────────────────────
		log_text = scrolledtext.ScrolledText(
			outer, bg=THEME['bg'], fg=THEME['text'],
			insertbackground=THEME['text'], relief=tk.FLAT,
			font=('Consolas', 10), state='disabled', wrap=tk.WORD
		)
		log_text.pack(fill=tk.BOTH, expand=True, padx=14, pady=(10, 0))
		log_text.tag_config('ok',      foreground=THEME['success'])
		log_text.tag_config('warn',    foreground=THEME['warning'])
		log_text.tag_config('danger',  foreground=THEME['danger'])
		log_text.tag_config('muted',   foreground=THEME['hud_muted'])
		log_text.tag_config('header',  foreground=THEME['accent'], font=('Consolas', 10, 'bold'))

		def _log(msg: str, tag: str = 'ok') -> None:
			log_text.config(state='normal')
			log_text.insert(tk.END, msg + '\n', tag)
			log_text.see(tk.END)
			log_text.config(state='disabled')

		# ── Launch button ─────────────────────────────────────────────────────
		bar = tk.Frame(outer, bg=THEME['panel'], padx=14, pady=10)
		bar.pack(fill=tk.X, pady=(8, 0))
		launch_btn = tk.Button(
			bar, text="🔬  LAUNCH INTEGRITY SWEEP",
			font=('Consolas', 12, 'bold'),
			bg=THEME['accent'], fg=THEME['bg'],
			activebackground=THEME['button_active'],
			relief=tk.FLAT, padx=18, pady=6
		)
		launch_btn.pack(side=tk.LEFT, padx=(0, 12))
		tk.Button(
			bar, text="Clear Log", command=lambda: (
				log_text.config(state='normal'),
				log_text.delete('1.0', tk.END),
				log_text.config(state='disabled'),
				sweep_status_var.set("Log cleared."),
				sweep_prog_var.set(0)
			),
			font=('Consolas', 10), bg=THEME['button'], fg=THEME['button_text'],
			relief=tk.FLAT
		).pack(side=tk.LEFT)

		def _run_sweep() -> None:
			launch_btn.config(state=tk.DISABLED)
			raw = dir_var.get().strip()
			dirs = [d.strip() for d in raw.split(',') if d.strip()] or None
			auto_q = auto_q_var.get()

			log_text.config(state='normal')
			log_text.delete('1.0', tk.END)
			log_text.config(state='disabled')

			_log("═" * 54, 'header')
			_log("  S.E.R.E. INTEGRITY SWEEP INITIATED", 'header')
			_log("═" * 54, 'header')
			if dirs:
				_log(f"Targets: {', '.join(dirs)}", 'muted')
			else:
				_log("Targets: default (Downloads + Temp)", 'muted')
			_log(f"Auto-Quarantine: {'YES' if auto_q else 'NO'}", 'muted')
			_log("", 'muted')

			sweep_status_var.set("Running — please wait…")
			sweep_prog_var.set(5)

			def _progress(msg: str, done: int, total: int) -> None:
				pct = int((done / total * 80) + 5) if total > 0 else 10
				self.root.after(0, lambda: sweep_prog_var.set(pct))
				self.root.after(0, lambda: sweep_status_var.set(msg))

			def _worker() -> None:
				try:
					result = self.engine.integrity_sweep_and_respond(
						target_dirs=dirs,
						auto_quarantine=auto_q,
						progress_callback=_progress,
					)
					self.root.after(0, _display_results, result)
				except Exception as exc:
					self.root.after(0, lambda: (
						_log(f"Sweep error: {exc}", 'danger'),
						sweep_status_var.set("Sweep failed — see log."),
						sweep_prog_var.set(0),
						launch_btn.config(state=tk.NORMAL),
					))

			def _display_results(r: dict) -> None:
				sweep_prog_var.set(100)
				sweep_status_var.set("Sweep complete.")
				launch_btn.config(state=tk.NORMAL)

				total_t = r.get('total_new_threats', 0)
				tag = 'danger' if total_t > 0 else 'ok'

				_log("", 'muted')
				_log("── SWEEP RESULTS ─────────────────────────────────────", 'header')
				_log(f"  Scan ID         : {r.get('scan_id')}", 'muted')
				_log(f"  Duration        : {r.get('duration_s')}s", 'muted')
				_log(f"  Dirs scanned    : {r.get('dirs_scanned')}", 'muted')
				_log(f"  Files scanned   : {r.get('files_scanned')} / {r.get('total_files')}", 'muted')
				_log("", 'muted')
				_log(f"  Hash matches    : {r.get('hash_matches')}", 'warn' if r.get('hash_matches') else 'ok')
				_log(f"  Name matches    : {r.get('name_matches')}", 'warn' if r.get('name_matches') else 'ok')
				_log(f"  Process threats : {r.get('process_threats')}", 'warn' if r.get('process_threats') else 'ok')
				_log(f"  Network threats : {r.get('network_threats')}", 'warn' if r.get('network_threats') else 'ok')
				_log(f"  HyperWatch hits : {r.get('hyper_threats')}", 'warn' if r.get('hyper_threats') else 'ok')
				_log("", 'muted')
				_log(f"  TOTAL THREATS   : {total_t}", tag)
				_log(f"  Auto-quarantined: {r.get('quarantined')}", 'ok')
				_log(f"  IPs blocked     : {r.get('blocked_ips')}", 'ok')

				irep = r.get('incident_report') or {}
				if irep and not irep.get('error'):
					_log("", 'muted')
					_log("── INCIDENT INVESTIGATION ────────────────────────────", 'header')
					processed = irep.get('processed') or []
					for entry in processed[:8]:
						ip    = entry.get('ip', '?')
						cls   = (entry.get('verdict') or {}).get('classification', '?')
						hits  = len(entry.get('firewall_hits') or [])
						sess  = len(entry.get('session_traces') or [])
						_log(f"  IP {ip:<18} [{cls}]  FW hits:{hits}  Sessions:{sess}", 'warn')
					geo = irep.get('geofence_plan') or []
					if geo:
						_log("  Geofence actions:", 'warn')
						for g in geo:
							_log(f"    {g.get('ip')} → {g.get('action')}", 'danger')
				elif irep.get('error'):
					_log(f"  Incident playbook: {irep['error']}", 'warn')
				else:
					_log("  No network IPs to investigate.", 'muted')

				_log("", 'muted')
				if total_t == 0:
					_log("✅  System integrity CLEAN. No threats detected.", 'ok')
				else:
					_log(f"🔴  {total_t} threat(s) found and actioned. Review Quarantine + Incident Log.", 'danger')
				_log("═" * 54, 'header')

				# Mirror to main operations log
				self._log_console(
					f"[INTEGRITY] Sweep complete — {total_t} threat(s) | "
					f"Q:{r.get('quarantined')} Blk:{r.get('blocked_ips')}",
					tag='warning' if total_t > 0 else 'status')

			threading.Thread(target=_worker, daemon=True).start()

		launch_btn.config(command=_run_sweep)

	def _build_ai_assistant_panel(self, parent: tk.Frame) -> None:
		"""Build the upgraded SERE AI Support panel — Ollama LLM + autonomous tools."""
		outer = tk.Frame(parent, bg=THEME['bg'])
		outer.pack(fill=tk.BOTH, expand=True)

		agent        = getattr(self, 'ai_agent', None)
		ollama_live  = (agent is not None) and agent.ollama.is_online
		model_name   = agent.ollama.model if agent else DEFAULT_MODEL_HINT

		# ── Status bar ────────────────────────────────────────────────────────
		status_bar = tk.Frame(outer, bg=THEME['panel'], padx=12, pady=6)
		status_bar.pack(fill=tk.X)

		dot_color  = THEME['success'] if ollama_live else THEME['danger']
		status_dot = tk.Label(status_bar, text="●", font=('Consolas', 12),
							  fg=dot_color, bg=THEME['panel'])
		status_dot.pack(side=tk.LEFT)

		status_label_text = f" Ollama: {model_name}" if ollama_live else " Ollama: OFFLINE — rule-based fallback"
		status_lbl = tk.Label(status_bar, text=status_label_text,
							  font=('Consolas', 10), fg=THEME['text'], bg=THEME['panel'])
		status_lbl.pack(side=tk.LEFT)

		# Model selector — only useful when Ollama is online
		if agent:
			model_var = tk.StringVar(value=agent.ollama.model)
			available = agent.ollama.get_models() or [agent.ollama.model]
			model_combo = ttk.Combobox(
				status_bar, textvariable=model_var,
				values=available, width=20, font=('Consolas', 9), state='readonly'
			)
			model_combo.pack(side=tk.RIGHT, padx=(0, 6))
			tk.Label(status_bar, text="Model:", font=('Consolas', 9),
					 fg=THEME['hud_muted'], bg=THEME['panel']).pack(side=tk.RIGHT)

			def _on_model_change(event=None):
				agent.ollama.model = model_var.get()
			model_combo.bind('<<ComboboxSelected>>', _on_model_change)

		def _reconnect():
			nonlocal ollama_live
			if agent is None:
				return
			def _probe():
				ok = agent.ollama.probe()
				color = THEME['success'] if ok else THEME['danger']
				label = f" Ollama: {agent.ollama.model}" if ok else " Ollama: OFFLINE — rule-based fallback"
				outer.after(0, lambda: (
					status_dot.config(fg=color),
					status_lbl.config(text=label)
				))
			threading.Thread(target=_probe, daemon=True).start()

		tk.Button(
			status_bar, text="↺ Reconnect", command=_reconnect,
			font=('Consolas', 9), bg=THEME['button'], fg=THEME['button_text'],
			relief=tk.FLAT, padx=8, pady=2
		).pack(side=tk.RIGHT, padx=(0, 12))

		# ── Header ────────────────────────────────────────────────────────────
		hdr = tk.Frame(outer, bg=THEME['panel'], padx=16, pady=10)
		hdr.pack(fill=tk.X)
		tk.Label(hdr, text="🤖  SERE AI SUPPORT", font=('Consolas', 14, 'bold'),
				 fg=THEME['accent'], bg=THEME['panel']).pack(anchor='w')
		sub = "Ollama LLM engine — autonomous tools + execution" if ollama_live \
			  else "Rule-based intelligence — start Ollama to enable LLM mode"
		tk.Label(hdr, text=sub, font=('Consolas', 10),
				 fg=THEME['hud_muted'], bg=THEME['panel']).pack(anchor='w')

		# ── Chat history ──────────────────────────────────────────────────────
		history = scrolledtext.ScrolledText(
			outer, bg=THEME['bg'], fg=THEME['text'],
			insertbackground=THEME['text'], relief=tk.FLAT,
			font=('Consolas', 10), state='disabled', wrap=tk.WORD
		)
		history.pack(fill=tk.BOTH, expand=True, padx=14, pady=(10, 0))

		history.tag_config('user',        foreground=THEME['accent'],     font=('Consolas', 10, 'bold'))
		history.tag_config('ai',          foreground=THEME['text'],        font=('Consolas', 10))
		history.tag_config('ai_hdr',      foreground=THEME['success'],     font=('Consolas', 10, 'bold'))
		history.tag_config('tool_call',   foreground='#4fc3f7',            font=('Consolas', 9, 'italic'))
		history.tag_config('tool_result', foreground='#80cbc4',            font=('Consolas', 9))
		history.tag_config('code_hdr',    foreground='#ffcc80',            font=('Consolas', 9, 'bold'))
		history.tag_config('code',        foreground='#e6db74',            font=('Courier New', 9), background='#1a1a1a')
		history.tag_config('thinking',    foreground=THEME['hud_muted'],   font=('Consolas', 9, 'italic'))
		history.tag_config('warning',     foreground=THEME['warning'])
		history.tag_config('error',       foreground=THEME['danger'])
		history.tag_config('muted',       foreground=THEME['hud_muted'],   font=('Consolas', 9))

		def _append(text: str, tag: str = 'ai') -> None:
			history.config(state='normal')
			history.insert(tk.END, text, tag)
			history.see(tk.END)
			history.config(state='disabled')

		# ── Code execution frame (hidden until code appears) ──────────────────
		code_frame   = tk.Frame(outer, bg='#1a1a1a', padx=12, pady=6)
		code_lbl     = tk.Label(code_frame, text="", font=('Courier New', 9),
								bg='#1a1a1a', fg='#e6db74', wraplength=840, justify='left')
		code_lbl.pack(anchor='w', fill=tk.X)
		code_btn_row = tk.Frame(code_frame, bg='#1a1a1a')
		code_btn_row.pack(anchor='e', pady=(4, 0))
		_current_code: Dict = {"code": ""}

		def _run_code():
			code = _current_code.get("code", "")
			if not code:
				return
			_append("\n[▶ Executing script...]\n", 'thinking')
			def _exec():
				reg = None
				if agent:
					reg = agent.registry
				else:
					try:
						from sere_ai_engine import SEREToolRegistry
						reg = SEREToolRegistry(self.engine)
					except Exception:
						pass
				if reg:
					result = reg.tool_execute_script(code)
				else:
					import subprocess as sp
					r = sp.run(['python', '-c', code], capture_output=True, text=True, timeout=30)
					result = (r.stdout or "") + (r.stderr or "")
				outer.after(0, lambda: _append(f"\n{result}\n\n", 'tool_result'))
			threading.Thread(target=_exec, daemon=True).start()

		tk.Button(
			code_btn_row, text="▶ Execute", command=_run_code,
			font=('Consolas', 9, 'bold'), bg=THEME['success'], fg=THEME['bg'],
			relief=tk.FLAT, padx=10, pady=3
		).pack(side=tk.LEFT, padx=4)
		tk.Button(
			code_btn_row, text="✕ Dismiss", command=lambda: code_frame.pack_forget(),
			font=('Consolas', 9), bg=THEME['button'], fg=THEME['button_text'],
			relief=tk.FLAT, padx=8, pady=3
		).pack(side=tk.LEFT)

		def _show_code_frame(code: str) -> None:
			_current_code["code"] = code
			preview = code[:600] + ("\n…" if len(code) > 600 else "")
			code_lbl.config(text=preview)
			if not code_frame.winfo_ismapped():
				code_frame.pack(fill=tk.X, padx=14, pady=(4, 0))

		# ── Welcome message ───────────────────────────────────────────────────
		if ollama_live:
			_append("╔═════════════════════════════════════════════╗\n", 'muted')
			_append("  SERE AI — OLLAMA LLM ENGINE ACTIVE           \n", 'ai_hdr')
			_append("╚═════════════════════════════════════════════╝\n", 'muted')
			_append(f"Model: {model_name}  |  Tools: {len(DEFAULT_TOOL_COUNT)} available  |  Autonomous mode: ON\n", 'tool_call')
			_append("Ask me anything. I can run integrity sweeps, block IPs, execute scripts, analyze logs, and more.\n\n", 'ai')
		else:
			_append("╔══════════════════════════════════════════════╗\n", 'muted')
			_append("  SERE AI — RULE-BASED MODE (Ollama offline)   \n", 'ai_hdr')
			_append("╚══════════════════════════════════════════════╝\n", 'muted')
			_append("Install Ollama (https://ollama.com) and run: ollama pull llama3.2\n", 'warning')
			_append("Then click ↺ Reconnect above to enable LLM mode.\n", 'muted')
			_append("Rule-based commands still work — type 'help' for list.\n\n", 'ai')

		# ── Input area ────────────────────────────────────────────────────────
		bar = tk.Frame(outer, bg=THEME['panel'], padx=14, pady=10)
		bar.pack(fill=tk.X, pady=(6, 0))

		input_text = tk.Text(
			bar, height=3,
			bg=THEME['bg'], fg=THEME['text'],
			insertbackground=THEME['text'],
			font=('Consolas', 11), relief=tk.FLAT, wrap=tk.WORD
		)
		input_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

		def _send(event=None) -> str:
			q = input_text.get("1.0", tk.END).strip()
			if not q:
				return "break"
			input_text.delete("1.0", tk.END)
			_append(f"\n▶ {q}\n", 'user')
			_thinking_job: Dict = {}

			def _animate_dots(step=0):
				dots = "⋯" + "." * (step % 3)
				history.config(state='normal')
				if "mark" in _thinking_job:
					try:
						history.delete(_thinking_job["mark"], tk.END)
					except tk.TclError:
						pass
				mark = history.index(tk.END)
				_thinking_job["mark"] = mark
				history.insert(tk.END, f"{dots}\n", 'thinking')
				history.see(tk.END)
				history.config(state='disabled')
				_thinking_job["id"] = outer.after(500, lambda: _animate_dots(step + 1))

			def _stop_thinking():
				if "id" in _thinking_job:
					outer.after_cancel(_thinking_job["id"])
				history.config(state='normal')
				if "mark" in _thinking_job:
					try:
						history.delete(_thinking_job["mark"], tk.END)
					except tk.TclError:
						pass
				history.config(state='disabled')

			def _on_tool_call(name: str, args: dict, result: str) -> None:
				arg_str = ", ".join(f"{k}={repr(v)}" for k, v in args.items()) if args else ""
				outer.after(0, lambda: (
					_stop_thinking(),
					_append(f"[🔧 TOOL] {name}({arg_str})\n", 'tool_call'),
					_append(f"→ {result[:200]}{'…' if len(result) > 200 else ''}\n", 'tool_result'),
					_animate_dots(0)
				))

			def _worker():
				use_agent = agent is not None and agent.ollama.is_online
				if use_agent:
					outer.after(0, lambda: _animate_dots(0))
					result = agent.query(q, on_tool_call=_on_tool_call)
					def _render():
						_stop_thinking()
						if not result.ollama_online:
							# LLM went offline mid-session — graceful fallback
							fallback = self._ai_respond(q)
							_append(f"[Ollama went offline — rule-based fallback]\n{fallback}\n\n", 'warning')
							return
						# Render tool calls not yet shown (batch mode tools)
						if result.text:
							# Split out code blocks for rendering
							remaining = result.text
							code_pat = re.compile(r"```(?:python)?\s*\n?(.*?)```", re.DOTALL)
							parts = code_pat.split(remaining)
							for i, part in enumerate(parts):
								if i % 2 == 0:
									if part.strip():
										_append(part if part.endswith('\n') else part + '\n', 'ai')
								else:
									_append("━━━ Generated Script ━━━\n", 'code_hdr')
									_append(part + "\n", 'code')
									_show_code_frame(part.strip())
						_append("\n", 'ai')
					outer.after(0, _render)
				else:
					# Offline — use rule-based engine
					resp = self._ai_respond(q)
					outer.after(0, lambda: _append(resp + "\n\n", 'ai'))

			threading.Thread(target=_worker, daemon=True).start()
			return "break"

		input_text.bind('<Return>', lambda e: _send() or "break")
		input_text.bind('<Shift-Return>', lambda e: None)  # allow newline with Shift+Enter

		tk.Button(
			bar, text="Send", command=_send,
			font=('Consolas', 11, 'bold'),
			bg=THEME['accent'], fg=THEME['bg'],
			activebackground=THEME['button_active'],
			relief=tk.FLAT, padx=14, pady=6
		).pack(side=tk.LEFT, anchor='s')

		tk.Button(
			bar, text="Clear History", command=lambda: (
				history.config(state='normal'),
				history.delete("1.0", tk.END),
				history.config(state='disabled'),
				agent.clear_history() if agent else None
			),
			font=('Consolas', 9), bg=THEME['button'], fg=THEME['button_text'],
			relief=tk.FLAT, padx=8, pady=4
		).pack(side=tk.LEFT, anchor='s', padx=(6, 0))

		input_text.focus_set()

	def _build_satellite_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=16, pady=16)
		panel.pack(fill=tk.X, pady=(0, 16))
		tk.Label(panel, text="SATELLITE .05468", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		tk.Label(panel, text="Orbital recon telemetry", font=('Consolas', 10), foreground=THEME['hud_muted'], background=THEME['panel']).pack(anchor='w')
		self.satellite_canvas = tk.Canvas(panel, height=160, bg=THEME['bg'], highlightthickness=0)
		self.satellite_canvas.pack(fill=tk.X, pady=(12, 0))

	def _build_location_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=16, pady=16)
		panel.pack(fill=tk.X, pady=(0, 16))
		tk.Label(panel, text="LOCATION .05468", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		tk.Label(panel, textvariable=self.phase_var, font=('Consolas', 18, 'bold'), foreground=THEME['success'], background=THEME['panel']).pack(anchor='w', pady=(4, 0))
		tk.Label(panel, textvariable=self.phase_desc_var, font=('Consolas', 10), foreground=THEME['text'], background=THEME['panel']).pack(anchor='w')
		tk.Label(panel, text="Geo acquisition", font=('Consolas', 11, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w', pady=(10, 4))
		self.geo_board = scrolledtext.ScrolledText(panel, height=5, bg=THEME['bg'], fg=THEME['text'], insertbackground=THEME['text'], relief=tk.FLAT, font=('Consolas', 11))
		self.geo_board.pack(fill=tk.X)
		self.geo_board.config(state='disabled')
		self.geo_board.tag_config('status', foreground=THEME['text'])
		self.geo_board.tag_config('alert', foreground=THEME['danger'])
		self.geo_board.tag_config('warning', foreground=THEME['warning'])
		self.geo_board.tag_config('intel', foreground=THEME['accent'])
		self._update_geolocation_panel([])

		# Trusted IP input controls
		ip_input_frame = tk.Frame(panel, bg=THEME['panel'])
		ip_input_frame.pack(fill=tk.X, pady=(10, 0))
		tk.Label(ip_input_frame, text="Add Trusted IP:", font=('Consolas', 10), fg=THEME['accent'], bg=THEME['panel']).pack(side=tk.LEFT)
		self.trusted_ip_entry = tk.Entry(ip_input_frame, font=('Consolas', 10), bg=THEME['bg'], fg=THEME['text'], width=18)
		self.trusted_ip_entry.pack(side=tk.LEFT, padx=(8, 0))
		add_ip_btn = tk.Button(ip_input_frame, text="Add", font=('Consolas', 10, 'bold'), bg=THEME['button'], fg=THEME['button_text'], command=self._add_trusted_ip)
		add_ip_btn.pack(side=tk.LEFT, padx=(8, 0))
		self._attach_tooltip(add_ip_btn, "Add IP to trusted whitelist.")
	def _add_trusted_ip(self):
		ip = self.trusted_ip_entry.get().strip()
		if ip:
			self.trusted_ips.add(ip)
			self.trusted_ip_entry.delete(0, tk.END)
			self._log_console(f"Added trusted IP: {ip}", tag='status')

	def _build_process_sentinel_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=16, pady=16)
		panel.pack(fill=tk.BOTH, expand=True, pady=(0, 16))
		tk.Label(panel, text="PROCESS SENTINEL", font=('Consolas', 14, 'bold'),
				 foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		tk.Label(panel, text="Top host processes — live telemetry",
				 font=('Consolas', 10), foreground=THEME['hud_muted'],
				 background=THEME['panel']).pack(anchor='w')
		self._process_sentinel_text = scrolledtext.ScrolledText(
			panel, height=6,
			bg=THEME['bg'], fg=THEME['text'],
			insertbackground=THEME['text'],
			relief=tk.FLAT,
			font=('Consolas', 10)
		)
		self._process_sentinel_text.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
		self._process_sentinel_text.config(state='disabled')
		self._process_sentinel_text.tag_config('header',  foreground=THEME['hud_muted'])
		self._process_sentinel_text.tag_config('normal',  foreground=THEME['text'])
		self._process_sentinel_text.tag_config('warning', foreground=THEME['warning'])
		self._process_sentinel_text.tag_config('danger',  foreground=THEME['danger'])
		self._update_process_sentinel()

	def _update_process_sentinel(self) -> None:
		"""Refresh the Process Sentinel panel with live host data."""
		if not self._process_sentinel_text:
			return
		try:
			import psutil
			procs = []
			for p in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
				try:
					info = p.info
					procs.append(info)
				except Exception:
					continue
			procs.sort(key=lambda x: (x.get('cpu_percent') or 0) + (x.get('memory_percent') or 0), reverse=True)
			top = procs[:8]
			lines: list = []
			header = f"{'PID':>7}  {'NAME':<22}  {'CPU%':>5}  {'MEM%':>5}"
			lines.append(('header', header + '\n'))
			lines.append(('header', '─' * len(header) + '\n'))
			engine_suspicious = getattr(self.engine, 'SUSPICIOUS_PROCESSES', [])
			for p in top:
				name = (p.get('name') or '?')[:22]
				pid  = p.get('pid') or 0
				cpu  = p.get('cpu_percent') or 0.0
				mem  = p.get('memory_percent') or 0.0
				row  = f"{pid:>7}  {name:<22}  {cpu:>5.1f}  {mem:>5.1f}\n"
				is_suspicious = any(s in (p.get('name') or '').lower() for s in engine_suspicious)
				if is_suspicious:
					lines.append(('danger', row))
				elif cpu > 25 or mem > 10:
					lines.append(('warning', row))
				else:
					lines.append(('normal', row))
		except Exception as e:
			lines = [('warning', f"Telemetry unavailable: {e}\n")]

		self._process_sentinel_text.config(state='normal')
		self._process_sentinel_text.delete('1.0', tk.END)
		for tag, text in lines:
			self._process_sentinel_text.insert(tk.END, text, tag)
		self._process_sentinel_text.config(state='disabled')

	def _build_wave_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=16, pady=16)
		panel.pack(fill=tk.BOTH, expand=True)
		tk.Label(panel, text="TOPOGRAPHIC SCAN", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		self.wave_canvas = tk.Canvas(panel, height=160, bg=THEME['bg'], highlightthickness=0)
		self.wave_canvas.pack(fill=tk.X, pady=(10, 12))
		bars = tk.Frame(panel, bg=THEME['panel'])
		bars.pack(fill=tk.X)
		self.cpu_bar = self._build_resource_row(bars, "CPU Cadence", self.cpu_value_var)
		self.mem_bar = self._build_resource_row(bars, "Memory Load", self.mem_value_var)
		self.disk_bar = self._build_resource_row(bars, "Disk Pressure", self.disk_value_var)

	def _build_tactical_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=16, pady=16)
		panel.pack(fill=tk.X, pady=(0, 16))
		tk.Label(panel, text="TACTICAL STATUS", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		tk.Label(panel, text="Defense lattice telemetry feed", font=('Consolas', 10), foreground=THEME['hud_muted'], background=THEME['panel']).pack(anchor='w')
		self.tactical_canvas = tk.Canvas(panel, height=140, bg=THEME['bg'], highlightthickness=0)
		self.tactical_canvas.pack(fill=tk.X, pady=(10, 0))

	def _build_threat_feed_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=16, pady=16)
		panel.pack(fill=tk.BOTH, expand=True, pady=(0, 16))
		tk.Label(panel, text="THREAT FEED", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		columns = ("severity", "intel", "category", "location", "time")
		self.threat_tree = ttk.Treeview(panel, columns=columns, show='headings', style='SERE.Treeview', height=8)
		for col, width in zip(columns, (90, 150, 150, 210, 110)):
			self.threat_tree.heading(col, text=col.upper())
			self.threat_tree.column(col, width=width, anchor='w')
		threat_scroll = ttk.Scrollbar(panel, orient='vertical', command=self.threat_tree.yview)
		self.threat_tree.configure(yscrollcommand=threat_scroll.set)
		self.threat_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT, pady=(10, 0))
		threat_scroll.pack(fill=tk.Y, side=tk.RIGHT, pady=(10, 0))

	def _build_map_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=16, pady=16)
		panel.pack(fill=tk.X)
		tk.Label(panel, text="MAP LOCAL", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		tk.Label(panel, text="Ping dispersion", font=('Consolas', 10), foreground=THEME['hud_muted'], background=THEME['panel']).pack(anchor='w')
		self.map_canvas = tk.Canvas(panel, height=180, bg=THEME['bg'], highlightthickness=0)
		self.map_canvas.pack(fill=tk.X, pady=(10, 0))

	def _build_incident_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=16, pady=16)
		panel.pack(fill=tk.X, pady=(16, 0))
		tk.Label(panel, text="INCIDENT OVERRIDE", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		tk.Label(panel, textvariable=self.incident_root_var, font=('Consolas', 11, 'bold'), foreground=THEME['text'], background=THEME['panel'], wraplength=320, justify=tk.LEFT).pack(anchor='w', pady=(8, 4))
		tk.Label(panel, textvariable=self.incident_assets_var, font=('Consolas', 10), foreground=THEME['hud_muted'], background=THEME['panel'], wraplength=320, justify=tk.LEFT).pack(anchor='w', pady=(0, 4))
		tk.Label(panel, textvariable=self.incident_response_var, font=('Consolas', 10), foreground=THEME['warning'], background=THEME['panel'], wraplength=320, justify=tk.LEFT).pack(anchor='w')

	def _build_countermeasures_panel(self, parent: tk.Frame) -> None:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=16, pady=16)
		panel.pack(fill=tk.BOTH, expand=True, pady=(16, 0))
		tk.Label(panel, text="LIVE COUNTERMEASURES", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		tk.Label(panel, textvariable=self.countermeasure_status_var, font=('Consolas', 10), foreground=THEME['text'], background=THEME['panel'], wraplength=320, justify=tk.LEFT).pack(anchor='w', pady=(6, 8))
		self.countermeasure_board = scrolledtext.ScrolledText(panel, height=5, bg=THEME['bg'], fg=THEME['text'], insertbackground=THEME['text'], relief=tk.FLAT, font=('Consolas', 10))
		self.countermeasure_board.pack(fill=tk.BOTH, expand=True)
		self.countermeasure_board.config(state='disabled')
		self.countermeasure_board.tag_config('tag', foreground=THEME['accent'])
		self._update_countermeasure_panel()

	def _build_tactical_radar(self, parent) -> tk.Frame:
		panel = tk.Frame(parent, bg=THEME['panel'], padx=20, pady=16)
		panel.pack(fill=tk.BOTH, expand=True, pady=(0, 16))
		tk.Label(panel, text="TACTICAL RADAR", font=('Consolas', 16, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		inner = tk.Frame(panel, bg=THEME['panel'])
		inner.pack(fill=tk.BOTH, expand=True, pady=(12, 0))
		self._radar_inner_frame = inner
		self.radar_canvas = tk.Canvas(inner, width=420, height=420, bg=THEME['crt_case'], highlightthickness=0)
		self._render_crt_frame()
		self._draw_radar_static()
		self._render_radar()
		self._start_radar_animation()

		command_frame = tk.Frame(inner, bg=THEME['panel'])
		command_frame.configure(width=self.RADAR_COMMAND_MIN_WIDTH)
		command_frame.pack_propagate(False)
		self._radar_command_frame = command_frame
		tk.Label(command_frame, text="Phase Commands", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		tk.Label(command_frame, text="Survive • Evade • Resist • Escalate", font=('Consolas', 11), foreground=THEME['text'], background=THEME['panel']).pack(anchor='w', pady=(0, 16))
		self._mode_button = None
		self._gunny_button = None

		# Only keep scan buttons, remove phase controls
		scan_btn_specs = [
			{"label": "QUICK SCAN", "cmd": lambda: self.start_scan(ScanProfile.QUICK), "lockable": True, "tooltip": "Same as Mission QUICK scan but anchored near radar controls."},
			{"label": "FULL SCAN", "cmd": lambda: self.start_scan(ScanProfile.FULL), "lockable": True, "tooltip": "Full-depth lattice sweep from the radar panel."},
		]
		for spec in scan_btn_specs:
			label, cmd = spec["label"], spec["cmd"]
			lockable = spec.get("lockable", False)
			btn = tk.Button(
				command_frame,
				text=label,
				command=cmd,
				font=('Consolas', 14, 'bold'),
				bg=THEME['button'],
				fg=THEME['button_text'],
				activebackground=THEME['button_active'],
				activeforeground=THEME['button_text'],
				relief=tk.FLAT,
				padx=12,
				pady=10,
			)
			btn.pack(fill=tk.X, pady=6)
			if lockable:
				self.scan_buttons.append(btn)
			self._attach_tooltip(btn, spec.get("tooltip"))

		control_frame = tk.Frame(command_frame, bg=THEME['panel'], pady=4)
		control_frame.pack(fill=tk.X, pady=(18, 0))
		tk.Label(control_frame, text="Control Overrides", font=('Consolas', 12, 'bold'), foreground=THEME['hud_warning'], background=THEME['panel']).pack(anchor='w')
		# Permanent REAL OPS badge — simulation is disabled per Mythara spec
		self._mode_button = tk.Label(
			control_frame,
			text="⬛ REAL OPS",
			font=('Consolas', 12, 'bold'),
			bg=THEME['button_active'],
			fg='#00FF00',
			relief=tk.FLAT,
			pady=8,
		)
		self._mode_button.pack(fill=tk.X, pady=(10, 6))
		self._attach_tooltip(self._mode_button, "S.E.R.E. runs on REAL threats only. Simulation is permanently disabled.")
		gunny_label = "Gunny Voice: MUTED" if self.gunny_muted else "Gunny Voice: ACTIVE"
		self._gunny_button = tk.Button(
			control_frame,
			text=gunny_label,
			command=self.toggle_gunny_voice,
			font=('Consolas', 12, 'bold'),
			bg=THEME['button'],
			fg=THEME['button_text'],
			activebackground=THEME['button_active'],
			activeforeground=THEME['button_text'],
			relief=tk.FLAT,
			pady=8
		)
		self._gunny_button.pack(fill=tk.X, pady=(0, 6))
		self._attach_tooltip(self._gunny_button, "Mute or unmute Gunny's voice feedback stream.")
		self._apply_toggle_palette(self._gunny_button, not self.gunny_muted)
		self._refresh_escalate_button()
		inner.bind('<Configure>', self._on_tactical_radar_resize, add='+')
		self.root.after_idle(self._sync_tactical_radar_layout)

		return panel

	def _on_tactical_radar_resize(self, _event=None) -> None:
		self._sync_tactical_radar_layout()

	def _sync_tactical_radar_layout(self) -> None:
		if not self._radar_inner_frame or not self._radar_command_frame or not self.radar_canvas:
			return
		inner = self._radar_inner_frame
		command_frame = self._radar_command_frame
		available_width = inner.winfo_width() or inner.winfo_reqwidth()
		use_vertical = available_width < self.RADAR_STACK_THRESHOLD
		if use_vertical == self._radar_command_vertical and self.radar_canvas.winfo_manager() == 'pack':
			return
		self._radar_command_vertical = use_vertical
		self.radar_canvas.pack_forget()
		command_frame.pack_forget()
		if use_vertical:
			command_frame.pack_propagate(True)
			self.radar_canvas.pack(side=tk.TOP, anchor='w', pady=(0, 18))
			command_frame.pack(side=tk.TOP, fill=tk.X, expand=True)
		else:
			command_frame.configure(width=self.RADAR_COMMAND_MIN_WIDTH)
			command_frame.pack_propagate(False)
			self.radar_canvas.pack(side=tk.LEFT, anchor='n', padx=(0, 20))
			command_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, anchor='n')

	# ------------------------------------------------------------------
	# Panel visualizers
	# ------------------------------------------------------------------
	def _start_visualizers(self) -> None:
		self._stop_visualizers()
		if self.satellite_canvas:
			self._render_satellite_feed()
		if self.wave_canvas:
			self._render_wave_scope()
		if self.tactical_canvas:
			self._render_tactical_grid()
		if self.map_canvas:
			self._render_map_scope()

	def _stop_visualizers(self) -> None:
		jobs = (
			(self._satellite_job, self.satellite_canvas),
			(self._wave_job, self.wave_canvas),
			(self._tactical_job, self.tactical_canvas),
			(self._map_job, self.map_canvas),
		)
		for job, canvas in jobs:
			if job and canvas and canvas.winfo_exists():
				try:
					canvas.after_cancel(job)
				except Exception:
					pass
		self._satellite_job = None
		self._wave_job = None
		self._tactical_job = None
		self._map_job = None

	def _render_satellite_feed(self) -> None:
		canvas = self.satellite_canvas
		if not canvas or not canvas.winfo_exists():
			return
		width, height = self._canvas_dimensions(canvas, 280, 150)
		canvas.delete('all')
		canvas.create_rectangle(0, 0, width, height, fill='#01090f', outline='')
		for x in range(0, width, 28):
			canvas.create_line(x, 0, x, height, fill='#06262f', width=1)
		for y in range(0, height, 20):
			canvas.create_line(0, y, width, y, fill='#04181c', width=1)
		cx = width / 2
		cy = height / 2
		orbit = min(width, height) / 2 - 18
		for idx, color in enumerate(('#052028', '#083644', '#0c4a58')):
			fraction = 0.45 + idx * 0.18
			canvas.create_oval(
				cx - orbit * fraction,
				cy - orbit * fraction * 0.6,
				cx + orbit * fraction,
				cy + orbit * fraction * 0.6,
				outline=color,
				width=2,
			)
		for idx in range(4):
			angle = self._satellite_phase + idx * 0.8
			px = cx + math.cos(angle) * orbit * 0.75
			py = cy + math.sin(angle) * orbit * 0.25
			canvas.create_line(cx, cy, px, py, fill='#0ff0c4', width=1)
			size = 8 - idx
			canvas.create_oval(px - size, py - size, px + size, py + size, fill=THEME['accent'], outline='')
		canvas.create_text(10, height - 14, anchor='w', text="Telemetry uplink stable", fill=THEME['hud_muted'], font=('Consolas', 10))
		self._satellite_phase = (self._satellite_phase + 0.08) % (math.pi * 2)
		self._satellite_job = canvas.after(80, self._render_satellite_feed)

	def _render_wave_scope(self) -> None:
		canvas = self.wave_canvas
		if not canvas or not canvas.winfo_exists():
			return
		width, height = self._canvas_dimensions(canvas, 320, 140)
		canvas.delete('all')
		canvas.create_rectangle(0, 0, width, height, fill='#030f12', outline='')
		mid = height / 2
		amplitude = height * 0.3
		points: List[float] = []
		for x in range(0, width + 6, 6):
			phase = self._wave_phase + (x * 0.05)
			y = mid + math.sin(phase) * amplitude
			points.extend([x, y])
		if len(points) >= 4:
			canvas.create_line(points, fill=THEME['accent'], width=2, smooth=True)
		for idx, offset in enumerate(range(0, width, 18)):
			height_mod = math.sin(self._wave_phase + idx * 0.3) * 12 + 28
			canvas.create_rectangle(offset, mid - height_mod, offset + 8, mid + height_mod, fill='#0a3033', outline='')
		self._wave_phase = (self._wave_phase + 0.15) % (math.pi * 2)
		self._wave_job = canvas.after(90, self._render_wave_scope)

	def _render_tactical_grid(self) -> None:
		canvas = self.tactical_canvas
		if not canvas or not canvas.winfo_exists():
			return
		width, height = self._canvas_dimensions(canvas, 320, 140)
		canvas.delete('all')
		canvas.create_rectangle(0, 0, width, height, fill='#020b0f', outline='')
		for x in range(0, width, 20):
			canvas.create_line(x, 0, x, height, fill=THEME['hud_grid_dim'])
		for y in range(0, height, 20):
			canvas.create_line(0, y, width, y, fill=THEME['hud_grid_dim'])
		canvas.create_oval(10, 10, width - 10, height - 10, outline=THEME['hud_grid'], width=1)
		threats = self._latest_threats[:8]
		if not threats:
			canvas.create_text(width / 2, height / 2, text="Perimeter steady", fill=THEME['hud_muted'], font=('Consolas', 12))
		else:
			severity_colors = {
				ThreatSeverity.CRITICAL: '#ff5f5f',
				ThreatSeverity.HIGH: '#ffb347',
				ThreatSeverity.MEDIUM: '#ffe066',
				ThreatSeverity.LOW: '#7cf9c7',
				ThreatSeverity.INFO: '#4fd1c5',
			}
			for idx, threat in enumerate(threats):
				sev = getattr(threat, 'severity', ThreatSeverity.MEDIUM)
				angle = self._tactical_phase + idx * 0.7
				orbit = 22 + idx * 24
				x = (width / 2) + math.cos(angle) * orbit
				y = (height / 2) + math.sin(angle) * (orbit * 0.4)
				color = severity_colors.get(sev, THEME['accent'])
				canvas.create_oval(x - 6, y - 6, x + 6, y + 6, fill=color, outline='')
				canvas.create_text(x + 10, y, anchor='w', text=threat.category.value[:14], fill=THEME['text'], font=('Consolas', 9))
		self._tactical_phase = (self._tactical_phase + 0.05) % (math.pi * 2)
		self._tactical_job = canvas.after(120, self._render_tactical_grid)

	def _render_map_scope(self) -> None:
		canvas = self.map_canvas
		if not canvas or not canvas.winfo_exists():
			return
		width, height = self._canvas_dimensions(canvas, 320, 160)
		canvas.delete('all')
		canvas.create_rectangle(0, 0, width, height, fill='#010a0e', outline='')
		for x in range(0, width, 24):
			canvas.create_line(x, 0, x, height, fill='#062026')
		for y in range(0, height, 24):
			canvas.create_line(0, y, width, y, fill='#04161a')
		self._draw_world_map(canvas, width, height)
		nodes = self._build_map_nodes(width, height)
		if not nodes:
			canvas.create_text(
				width / 2,
				height / 2,
				text="Awaiting telemetry",
				fill=THEME['hud_muted'],
				font=('Consolas', 12)
			)
		else:
			for idx, node in enumerate(nodes):
				self._draw_map_target(canvas, node, idx)
		self._map_pulse = (self._map_pulse + 0.12) % (math.pi * 2)
		self._map_job = canvas.after(140, self._render_map_scope)

	def _draw_world_map(self, canvas: tk.Canvas, width: int, height: int) -> None:
		for outline in WORLD_OUTLINES:
			coords: List[float] = []
			for lon, lat in outline['points']:
				x, y = self._project_map_point(lat, lon, width, height)
				coords.extend([x, y])
			if coords:
				canvas.create_polygon(
					coords,
					fill='#05252f',
					outline='#0c4554',
					width=1,
					smooth=True
				)

	def _draw_map_target(self, canvas: tk.Canvas, node: Dict[str, Any], idx: int) -> None:
		severity_colors = {
			ThreatSeverity.CRITICAL: '#ff3b3b',
			ThreatSeverity.HIGH: '#ffb347',
			ThreatSeverity.MEDIUM: '#ffe066',
			ThreatSeverity.LOW: '#7cf9c7',
			ThreatSeverity.INFO: '#4fd1c5',
		}
		color = severity_colors.get(node['severity'], THEME['accent'])
		x, y = node['x'], node['y']
		pulse = max(3.0, (math.sin(self._map_pulse + idx * 0.8) + 1.6) * 4)
		for ring in range(3):
			radius = 6 + ring * 7 + pulse
			canvas.create_oval(
				x - radius,
				y - radius,
				x + radius,
				y + radius,
				outline=color if ring == 0 else THEME['hud_glow'],
				width=2 if ring == 0 else 1
			)
		canvas.create_line(x - 14, y, x + 14, y, fill=color, width=1)
		canvas.create_line(x, y - 14, x, y + 14, fill=color, width=1)
		canvas.create_oval(x - 4, y - 4, x + 4, y + 4, fill=color, outline='')
		city = node.get('city') or node.get('country')
		label_line = city or node['ip']
		canvas.create_text(
			x + 16,
			y - 10,
			anchor='w',
			fill=THEME['text'],
			font=('Consolas', 9),
			text=label_line[:22]
		)
		canvas.create_text(
			x + 16,
			y + 6,
			anchor='w',
			fill=THEME['hud_muted'],
			font=('Consolas', 9),
			text=node['label'][:22]
		)

	def _build_map_nodes(self, width: int, height: int) -> List[Dict[str, Any]]:
		nodes: List[Dict[str, Any]] = []
		seen: Set[str] = set()
		for idx, threat in enumerate(self._latest_threats[:20]):
			ip = self._extract_ip_from_threat(threat) or f"vector-{idx}"
			if ip in seen:
				continue
			seen.add(ip)
			geo = self.geolocation_cache.get(ip)
			lat = lon = None
			city = country = None
			if geo:
				lat = self._safe_float(geo.get('lat'))
				lon = self._safe_float(geo.get('lon'))
				city = geo.get('city')
				country = geo.get('country')
			if lat is None or lon is None:
				lat, lon = self._pseudo_lat_lon(f"{ip}-{idx}")
			x, y = self._project_map_point(lat, lon, width, height)
			nodes.append({
				'x': x,
				'y': y,
				'lat': lat,
				'lon': lon,
				'ip': ip,
				'city': city,
				'country': country,
				'label': threat.category.value,
				'severity': getattr(threat, 'severity', ThreatSeverity.MEDIUM)
			})
		return nodes

	def _canvas_dimensions(self, canvas: tk.Canvas, min_width: int, min_height: int) -> Tuple[int, int]:
		width = max(canvas.winfo_width() or 0, canvas.winfo_reqwidth() or 0, min_width)
		height = max(canvas.winfo_height() or 0, canvas.winfo_reqheight() or 0, min_height)
		return width, height

	def _safe_float(self, value: Any) -> Optional[float]:
		try:
			if value is None:
				return None
			return float(value)
		except (TypeError, ValueError):
			return None

	def _project_map_point(self, lat: float, lon: float, width: int, height: int) -> Tuple[float, float]:
		x = (lon + 180.0) / 360.0 * width
		y = height - ((lat + 90.0) / 180.0 * height)
		return x, y

	def _pseudo_lat_lon(self, seed_value: str) -> Tuple[float, float]:
		digest = hashlib.sha1(seed_value.encode('utf-8')).digest()
		lon = (int.from_bytes(digest[:2], 'big') / 65535.0) * 360.0 - 180.0
		lat = (int.from_bytes(digest[2:4], 'big') / 65535.0) * 140.0 - 70.0
		return lat, lon

	def _show_splash_screen(self) -> None:
		self.root.withdraw()
		splash = tk.Toplevel(self.root)
		splash.overrideredirect(True)
		splash.configure(bg=THEME['panel'])
		width, height = 520, 280
		screen_w = self.root.winfo_screenwidth()
		screen_h = self.root.winfo_screenheight()
		x = (screen_w - width) // 2
		y = (screen_h - height) // 2
		splash.geometry(f"{width}x{height}+{x}+{y}")
		tk.Label(splash, text="S.E.R.E. SECURITY SUITE", font=('Consolas', 18, 'bold'), fg=THEME['accent'], background=THEME['panel']).pack(pady=(30, 10))
		tk.Label(splash, text="Survive • Evade • Resist • Escape", font=('Consolas', 12), fg=THEME['text'], background=THEME['panel']).pack()
		tk.Label(splash, text="Gunny warming up sensors...", font=('Consolas', 11), fg=THEME['warning'], background=THEME['panel']).pack(pady=(20, 12))
		progress = ttk.Progressbar(splash, length=360, mode='determinate')
		progress.pack(pady=(0, 20))
		self._splash_animating = True

		def animate(value: int = 0):
			if not self._splash_animating:
				return
			progress['value'] = value % 100
			splash.after(50, animate, value + 3)

		animate()

		def close_splash():
			self._splash_animating = False
			splash.destroy()
			self.root.deiconify()

		splash.after(2400, close_splash)

	# ------------------------------------------------------------------
	# Threat Assessment (Globe Panel)
	# ------------------------------------------------------------------
	def open_threat_assessment(self) -> None:
		if self.threat_assessment_win and self.threat_assessment_win.winfo_exists():
			self.threat_assessment_win.deiconify()
			self.threat_assessment_win.lift()
			self._render_globe_scope()
			return
		self._build_threat_assessment_window()

	def _build_threat_assessment_window(self) -> None:
		win = tk.Toplevel(self.root)
		win.title("Threat Assessment — Geospatial Triangulation")
		win.configure(bg=THEME['bg'])
		win.geometry("900x560")
		win.minsize(720, 520)
		self.threat_assessment_win = win
		win.protocol("WM_DELETE_WINDOW", self._close_threat_assessment)

		container = tk.Frame(win, bg=THEME['bg'], padx=20, pady=20)
		container.pack(fill=tk.BOTH, expand=True)

		canvas_frame = tk.Frame(container, bg=THEME['panel'], padx=14, pady=14)
		canvas_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
		self.globe_canvas = tk.Canvas(canvas_frame, width=520, height=520, bg=THEME['bg'], highlightthickness=0)
		self.globe_canvas.pack(fill=tk.BOTH, expand=True)

		right_panel = tk.Frame(container, bg=THEME['panel'], padx=14, pady=14)
		right_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(16, 0))
		tk.Label(right_panel, text="Telemetry Hits", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		self._globe_listbox = tk.Listbox(right_panel, height=14, bg=THEME['bg'], fg=THEME['text'], activestyle='none', selectbackground=THEME['accent'], font=('Consolas', 11))
		self._globe_listbox.pack(fill=tk.BOTH, expand=True, pady=(10, 10))
		self._globe_listbox.bind('<<ListboxSelect>>', self._on_globe_selection)
		tk.Label(right_panel, textvariable=self.threat_detail_var, wraplength=260, justify=tk.LEFT, background=THEME['panel'], foreground=THEME['text'], font=('Consolas', 10)).pack(fill=tk.X, pady=(6, 0))

		self._collect_globe_points()
		self._populate_globe_listbox()
		self._render_globe_scope()
		self._start_globe_animation()

	def _close_threat_assessment(self) -> None:
		self._stop_globe_animation()
		if self.threat_assessment_win and self.threat_assessment_win.winfo_exists():
			self.threat_assessment_win.destroy()
		self.threat_assessment_win = None
		self.globe_canvas = None
		self._globe_listbox = None

	def _on_globe_selection(self, _event: Optional[tk.Event] = None) -> None:
		if not self._globe_listbox:
			return
		selection = self._globe_listbox.curselection()
		if not selection:
			return
		idx = selection[0]
		if idx >= len(self._globe_points):
			return
		point = self._globe_points[idx]
		self.threat_detail_var.set(
			f"{point['label']} • {point['city']}, {point['region'] or point['country']}\n"
			f"IP: {point['ip']} | Severity: {point['severity'].name}"
		)

	def _start_globe_animation(self) -> None:
		if not self.globe_canvas:
			return
		self._stop_globe_animation()
		self._globe_job = self.globe_canvas.after(80, self._animate_globe)

	def _stop_globe_animation(self) -> None:
		if self._globe_job and self.globe_canvas:
			self.globe_canvas.after_cancel(self._globe_job)
		self._globe_job = None

	def _animate_globe(self) -> None:
		self._globe_rotation = (self._globe_rotation + 1.2) % 360
		self._render_globe_scope()
		if self.globe_canvas and self.globe_canvas.winfo_exists():
			self._globe_job = self.globe_canvas.after(80, self._animate_globe)

	def _collect_globe_points(self) -> None:
		points: List[Dict[str, Any]] = []
		for threat in self._latest_threats:
			ip = self._extract_ip_from_threat(threat)
			if not ip:
				continue
			geo = self.geolocation_cache.get(ip)
			if not geo:
				continue
			lat = geo.get('lat')
			lon = geo.get('lon')
			if lat is None or lon is None:
				continue
			points.append({
				'lat': lat,
				'lon': lon,
				'city': geo.get('city', ''),
				'region': geo.get('region', ''),
				'country': geo.get('country', ''),
				'ip': ip,
				'label': threat.category.value,
				'severity': threat.severity,
			})
		self._globe_points = points

	def _populate_globe_listbox(self) -> None:
		if not self._globe_listbox:
			return
		self._globe_listbox.delete(0, tk.END)
		if not self._globe_points:
			self._globe_listbox.insert(tk.END, "No geolocated threats on scope.")
			self.threat_detail_var.set("Awaiting hostile telemetry...")
			return
		for point in self._globe_points:
			city = point['city'] or point['country'] or 'Unknown'
			self._globe_listbox.insert(tk.END, f"{point['label']} • {city} [{point['severity'].name}]")

	def _refresh_threat_assessment_panel(self) -> None:
		if not (self.threat_assessment_win and self.threat_assessment_win.winfo_exists()):
			return
		self._populate_globe_listbox()
		self._render_globe_scope()

	def _render_globe_scope(self) -> None:
		if not self.globe_canvas or not self.globe_canvas.winfo_exists():
			return
		canvas = self.globe_canvas
		canvas.delete('all')
		width = int(canvas['width'])
		height = int(canvas['height'])
		cx, cy = width / 2, height / 2
		radius = min(width, height) / 2 - 20
		for idx, color in enumerate(['#021b24', '#032634', '#043545', '#054555']):
			inset = idx * 6
			canvas.create_oval(cx - radius + inset, cy - radius + inset, cx + radius - inset, cy + radius - inset, fill=color, outline=color)
		canvas.create_oval(cx - radius, cy - radius, cx + radius, cy + radius, outline=THEME['sonar_grid'], width=2)
		self._draw_globe_grid(canvas, cx, cy, radius)
		for point in self._globe_points:
			x, y, depth = self._project_lat_lon(point['lat'], point['lon'], cx, cy, radius)
			if depth <= -0.05:
				continue
			size = 6 + (point['severity'].value * 1.5)
			glow = max(0.2, depth)
			r = 255
			g = max(0, min(255, int(80 + 120 * glow)))
			b = max(0, min(255, int(60 + 60 * (1 - depth))))
			color = f"#{r:02x}{g:02x}{b:02x}"
			canvas.create_oval(x - size, y - size, x + size, y + size, fill=color, outline='')
			canvas.create_oval(x - size*1.6, y - size*1.6, x + size*1.6, y + size*1.6, outline=color, width=1)
			canvas.create_text(x + 14, y, text=point['city'] or point['country'] or point['ip'], anchor='w', fill=THEME['text'], font=('Consolas', 9))

	def _draw_globe_grid(self, canvas: tk.Canvas, cx: float, cy: float, radius: float) -> None:
		for lat in range(-60, 61, 30):
			coords: List[float] = []
			for lon in range(-180, 181, 10):
				x, y, depth = self._project_lat_lon(lat, lon, cx, cy, radius)
				if depth < -0.2:
					continue
				coords.extend([x, y])
			if len(coords) >= 4:
				canvas.create_line(coords, fill=THEME['sonar_grid_dim'], smooth=True)
		for lon in range(-150, 181, 30):
			coords = []
			for lat in range(-90, 91, 6):
				x, y, depth = self._project_lat_lon(lat, lon, cx, cy, radius)
				if depth < -0.1:
					continue
				coords.extend([x, y])
			if len(coords) >= 4:
				canvas.create_line(coords, fill=THEME['sonar_grid_dim'])

	def _project_lat_lon(self, lat: float, lon: float, cx: float, cy: float, radius: float) -> Tuple[float, float, float]:
		lat_rad = math.radians(lat)
		lon_rad = math.radians(lon + self._globe_rotation)
		x = cx + radius * math.cos(lat_rad) * math.sin(lon_rad)
		y = cy - radius * math.sin(lat_rad)
		depth = math.cos(lat_rad) * math.cos(lon_rad)
		return x, y, depth

	# ------------------------------------------------------------------
	# Security Report (Quarantine + Threat Snapshot)
	# ------------------------------------------------------------------
	def open_security_report(self) -> None:
		if self.report_window and self.report_window.winfo_exists():
			self.report_window.deiconify()
			self.report_window.lift()
			self._refresh_report_window()
			return
		self._build_security_report_window()

	def _build_security_report_window(self) -> None:
		win = tk.Toplevel(self.root)
		win.title("Security Report — Quarantine & Threats")
		win.configure(bg=THEME['bg'])
		win.geometry("960x580")
		win.minsize(820, 520)
		self.report_window = win
		win.protocol("WM_DELETE_WINDOW", self._close_security_report)

		container = tk.Frame(win, bg=THEME['bg'], padx=20, pady=20)
		container.pack(fill=tk.BOTH, expand=True)

		summary = tk.Frame(container, bg=THEME['panel'], padx=16, pady=12, highlightbackground=THEME['accent'], highlightthickness=1)
		summary.pack(fill=tk.X, pady=(0, 12))
		tk.Label(summary, text="Security Snapshot", font=('Consolas', 14, 'bold'), foreground=THEME['accent'], background=THEME['panel']).pack(anchor='w')
		tk.Label(summary, textvariable=self.report_summary_var, font=('Consolas', 11), foreground=THEME['text'], background=THEME['panel']).pack(anchor='w', pady=(6, 0))

		body = tk.Frame(container, bg=THEME['bg'])
		body.pack(fill=tk.BOTH, expand=True)

		left = tk.Frame(body, bg=THEME['panel'], padx=14, pady=14)
		left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
		k.Label(left, text="Quarantine Zones", font=('Consolas', 13, 'bold'), fg=THEME['accent'], bg=THEME['panel']).pack(anchor='w')
		columns = ("ip", "threat", "status", "isolation", "since")
		self._report_quarantine_tree = ttk.Treeview(left, columns=columns, show='headings', style='SERE.Treeview')
		for col, width in zip(columns, (140, 150, 120, 120, 140)):
			self._report_quarantine_tree.heading(col, text=col.upper())
			self._report_quarantine_tree.column(col, width=width, anchor='w')
		q_scroll = ttk.Scrollbar(left, orient='vertical', command=self._report_quarantine_tree.yview)
		self._report_quarantine_tree.configure(yscrollcommand=q_scroll.set)
		self._report_quarantine_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT, pady=(10, 0))
		q_scroll.pack(fill=tk.Y, side=tk.LEFT, pady=(10, 0), padx=(6, 0))

		right = tk.Frame(body, bg=THEME['panel'], padx=14, pady=14)
		right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
		k.Label(right, text="Active Threat Board", font=('Consolas', 13, 'bold'), fg=THEME['accent'], bg=THEME['panel']).pack(anchor='w')
		cols = ("id", "severity", "category", "vector", "intel", "time")
		self._report_threat_tree = ttk.Treeview(right, columns=cols, show='headings', style='SERE.Treeview')
		for col, width in zip(cols, (140, 90, 150, 150, 140, 90)):
			self._report_threat_tree.heading(col, text=col.upper())
			self._report_threat_tree.column(col, width=width, anchor='w')
		t_scroll = ttk.Scrollbar(right, orient='vertical', command=self._report_threat_tree.yview)
		self._report_threat_tree.configure(yscrollcommand=t_scroll.set)
		self._report_threat_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT, pady=(10, 0))
		t_scroll.pack(fill=tk.Y, side=tk.LEFT, pady=(10, 0), padx=(6, 0))

		actions = tk.Frame(container, bg=THEME['bg'])
		actions.pack(fill=tk.X, pady=(12, 0))
		refresh_btn = ttk.Button(actions, text="Refresh", command=self._refresh_report_window, style='SERE.TButton')
		export_btn = ttk.Button(actions, text="Export Report", command=self._export_security_report, style='SERE.TButton')
		export_btn.pack(side=tk.RIGHT)
		refresh_btn.pack(side=tk.RIGHT, padx=(0, 10))
		self._attach_tooltip(refresh_btn, "Pull the latest quarantine + threat telemetry.")
		self._attach_tooltip(export_btn, "Export the current report to the sere_reports directory.")

		self._refresh_report_window()

	def _close_security_report(self) -> None:
		if self.report_window and self.report_window.winfo_exists():
			self.report_window.destroy()
		self.report_window = None
		self._report_quarantine_tree = None
		self._report_threat_tree = None

	def _refresh_report_window(self) -> None:
		if not (self.report_window and self.report_window.winfo_exists()):
			return
		try:
			quarantine = self.engine.get_quarantine_snapshot()
		except Exception:
			quarantine = []
		threats = list(self._latest_threats)
		active = len([t for t in threats if not getattr(t, 'resolved', False)])
		blocked = self.engine.metrics.get('threats_blocked', 0)
		self.report_summary_var.set(
			f"Quarantine zones: {len(quarantine)} | Active threats: {active} | Total blocked: {blocked}"
		)
		if self._report_quarantine_tree:
			tree = self._report_quarantine_tree
			tree.delete(*tree.get_children())
			if not quarantine:
				tree.insert('', tk.END, values=("None", "—", "—", "—", "—"))
			else:
				for zone in quarantine:
					since = self._format_since(zone.get('since'))
					values = (
						zone.get('ip', 'n/a'),
						zone.get('type', 'Unknown'),
						zone.get('status', 'n/a'),
						zone.get('isolation', 'n/a'),
						since,
					)
					tree.insert('', tk.END, values=values)
		if self._report_threat_tree:
			tree = self._report_threat_tree
			tree.delete(*tree.get_children())
			if not threats:
				tree.insert('', tk.END, values=("No threats", "", "", "", "", ""))
			else:
				for threat in threats[:30]:
					vector = threat.source or threat.target or "Unknown vector"
					stamp = threat.timestamp.strftime("%H:%M:%S") if isinstance(threat.timestamp, datetime) else "n/a"
					values = (
						threat.threat_id,
						threat.severity.name,
						threat.category.value,
						vector,
						self._format_intel_badge(threat),
						stamp,
					)
					tree.insert('', tk.END, values=values)

	def _export_security_report(self) -> None:
		try:
			quarantine = self.engine.get_quarantine_snapshot()
		except Exception as exc:
			quarantine = []
			self._log_console(f"Unable to pull quarantine snapshot: {exc}", tag='warning')
		threats = list(self._latest_threats)
		try:
			timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
			path = self.report_export_dir / f"SERE_SECURITY_REPORT_{timestamp}.txt"
			with path.open('w', encoding='utf-8') as fh:
				fh.write("=" * 80 + "\n")
				fh.write("S.E.R.E. Security Report\n")
				fh.write("=" * 80 + "\n")
				fh.write(f"Generated: {datetime.now().isoformat()}\n")
				fh.write(f"Quarantine Zones: {len(quarantine)}\n")
				fh.write(f"Active Threats: {len([t for t in threats if not getattr(t, 'resolved', False)])}\n")
				fh.write(f"Total Blocked Threats: {self.engine.metrics.get('threats_blocked', 0)}\n")
				fh.write("-" * 80 + "\nQUARANTINE DETAIL\n" + "-" * 80 + "\n")
				if not quarantine:
					fh.write("No quarantine zones active.\n")
				else:
					for zone in quarantine:
						fh.write(
							f"IP: {zone.get('ip', 'n/a')} | Type: {zone.get('type', 'Unknown')} | Status: {zone.get('status', 'n/a')}\n"
						)
						fh.write(
							f"Isolation: {zone.get('isolation', 'n/a')} | Since: {self._format_since(zone.get('since'))}\n\n"
						)
				fh.write("-" * 80 + "\nTHREAT BOARD\n" + "-" * 80 + "\n")
				if not threats:
					fh.write("No active threats detected.\n")
				else:
					for threat in threats[:40]:
						vector = threat.source or threat.target or "Unknown vector"
						stamp = threat.timestamp.isoformat() if isinstance(threat.timestamp, datetime) else "n/a"
						fh.write(
							f"[{threat.severity.name}] {threat.category.value} | {vector} | Intel {self._format_intel_badge(threat)}\n"
						)
						fh.write(f"Threat ID: {threat.threat_id} | Timestamp: {stamp}\n")
						fh.write(f"Summary: {self._format_intel_summary(threat, limit=160)}\n\n")
				fh.write("=" * 80 + "\n")
			self._log_console(f"Security report exported to {path.resolve()}", tag='status')
			messagebox.showinfo("Security Report", f"Report exported to:\n{path.resolve()}")
		except Exception as exc:
			messagebox.showerror("Security Report", f"Failed to export report: {exc}")
			self._log_console(f"Security report export failed: {exc}", tag='alert')

	# ------------------------------------------------------------------
	# UI builders
	# ------------------------------------------------------------------
	def _build_stat_card(self, parent, title: str, value_var: tk.StringVar, accent: str) -> tk.Frame:
		frame = tk.Frame(parent, bg=THEME['panel'], padx=18, pady=16)
		tk.Label(frame, text=title, font=('Consolas', 12), fg=THEME['text'], bg=THEME['panel']).pack(anchor='w')
		tk.Label(frame, textvariable=value_var, font=('Consolas', 24, 'bold'), fg=accent, bg=THEME['panel']).pack(anchor='w', pady=(6, 0))
		return frame

	def _build_resource_row(self, parent, label_text: str, value_var: tk.StringVar):
		row = tk.Frame(parent, bg=THEME['panel'])
		row.pack(fill=tk.X, pady=6)
		tk.Label(row, text=label_text, font=('Consolas', 12), fg=THEME['text'], bg=THEME['panel']).pack(side=tk.LEFT)
		tk.Label(row, textvariable=value_var, font=('Consolas', 12, 'bold'), fg=THEME['accent'], bg=THEME['panel']).pack(side=tk.RIGHT)
		bar = ttk.Progressbar(row, style='SERE.Horizontal.TProgressbar', maximum=100)
		bar.pack(fill=tk.X, pady=(6, 0))
		return bar

	def _render_crt_frame(self) -> None:
		if not hasattr(self, 'radar_canvas'):
			return
		canvas = self.radar_canvas
		canvas.delete('crt')
		width = int(canvas['width'])
		height = int(canvas['height'])
		canvas.create_rectangle(0, 0, width, height, fill=THEME['crt_case'], outline=THEME['crt_case_outline'], width=18, tags='crt')
		canvas.create_rectangle(10, 10, width - 10, height - 10, outline=THEME['crt_case_outline'], width=3, tags='crt')
		gradient = ['#03140f', '#042017', '#052b1f', '#063629', '#084333']
		for idx, color in enumerate(gradient):
			inset = 18 + idx * 6
			canvas.create_oval(inset, inset, width - inset, height - inset, outline=color, width=2, tags='crt')
		inner_inset = 18 + len(gradient) * 6
		canvas.create_oval(inner_inset, inner_inset, width - inner_inset, height - inner_inset,
				fill=THEME['crt_glass_inner'], outline=THEME['crt_glow'], width=3, tags='crt')
		canvas.create_oval(inner_inset + 8, inner_inset + 8, width - inner_inset - 8, height - inner_inset - 8,
				outline=THEME['crt_glow'], width=1, tags='crt')
		canvas.create_arc(inner_inset + 16, inner_inset + 16, width - inner_inset - 16, height - inner_inset - 16,
				start=30, extent=120, outline='#0f6f57', style=tk.ARC, width=2, tags='crt')

	def _render_crt_scanlines(self) -> None:
		if not hasattr(self, 'radar_canvas'):
			return
		canvas = self.radar_canvas
		canvas.delete('scanline')
		width = int(canvas['width'])
		height = int(canvas['height'])
		step = 6
		offset = self._crt_scanline_offset % step
		inset = 28
		for idx, base_y in enumerate(range(inset, height - inset, step)):
			y = base_y + offset
			if y >= height - inset:
				continue
			color = THEME['crt_scanline_light'] if idx % 2 == 0 else THEME['crt_scanline_dark']
			canvas.create_line(inset, y, width - inset, y, fill=color, width=1, tags='scanline')
		self._crt_scanline_offset = (self._crt_scanline_offset + 1) % step

	def _draw_radar_static(self) -> None:
		if not hasattr(self, 'radar_canvas'):
			return
		canvas = self.radar_canvas
		canvas.delete('baseline')
		width = int(canvas['width'])
		height = int(canvas['height'])
		cx, cy = width / 2, height / 2
		inset = 36
		radius = min(width, height) / 2 - inset
		rings = (
			(1.0, THEME['sonar_grid']),
			(0.8, THEME['sonar_grid_dim']),
			(0.6, THEME['sonar_grid']),
			(0.4, THEME['sonar_grid_dim']),
			(0.2, THEME['sonar_grid'])
		)
		for frac, color in rings:
			inner = radius * frac
			canvas.create_oval(cx - inner, cy - inner, cx + inner, cy + inner, outline=color, width=1, tags='baseline')
		for angle in range(0, 360, 15):
			theta = math.radians(angle)
			outer_x = cx + radius * math.cos(theta)
			outer_y = cy - radius * math.sin(theta)
			inner_x = cx + (radius - 16) * math.cos(theta)
			inner_y = cy - (radius - 16) * math.sin(theta)
			line_width = 2 if angle % 45 == 0 else 1
			canvas.create_line(inner_x, inner_y, outer_x, outer_y, fill=THEME['sonar_grid_dim'], width=line_width, tags='baseline')
		canvas.create_line(cx - radius, cy, cx + radius, cy, fill=THEME['sonar_grid'], width=1, tags='baseline')
		canvas.create_line(cx, cy - radius, cx, cy + radius, fill=THEME['sonar_grid'], width=1, tags='baseline')
		canvas.create_text(cx, cy, text="S · E · R · E", fill=THEME['sonar_ping'], font=('Consolas', 18, 'bold'), tags='baseline')
		canvas.create_oval(cx - 6, cy - 6, cx + 6, cy + 6, outline=THEME['sonar_ping'], fill=THEME['sonar_ping'], tags='baseline')

	def _start_radar_animation(self) -> None:
		if not hasattr(self, 'radar_canvas'):
			return
		if self._radar_job:
			self.radar_canvas.after_cancel(self._radar_job)
		self._radar_job = self.radar_canvas.after(60, self._animate_radar)

	def _animate_radar(self) -> None:
		self._radar_angle = (self._radar_angle + 3) % 360
		self._render_radar()
		self._radar_job = self.radar_canvas.after(60, self._animate_radar)

	def _render_radar(self) -> None:
		if not hasattr(self, 'radar_canvas'):
			return
		canvas = self.radar_canvas
		canvas.delete('sweep')
		canvas.delete('target')
		width = int(canvas['width'])
		height = int(canvas['height'])
		cx, cy = width / 2, height / 2
		inset = 36
		radius = min(width, height) / 2 - inset
		angle_rad = math.radians(self._radar_angle)
		x = cx + radius * math.cos(angle_rad)
		y = cy - radius * math.sin(angle_rad)
		canvas.create_arc(
			cx - radius,
			cy - radius,
			cx + radius,
			cy + radius,
			start=-self._radar_angle - 18,
			extent=36,
			outline='',
			fill=THEME['sonar_sweep'],
			tags='sweep'
		)
		canvas.create_line(cx, cy, x, y, fill=THEME['sonar_ping'], width=3, tags='sweep')
		canvas.create_oval(cx - 14, cy - 14, cx + 14, cy + 14, outline='', fill='#1fb58c', tags='sweep')
		severity_colors = {
			'CRITICAL': '#ff3b3b',
			'HIGH': '#ffb347',
			'MEDIUM': '#ffe066',
			'LOW': '#7cf9c7',
			'INFO': '#4fd1c5',
			'IDLE': '#1dd1a1',
		}
		for angle, r_norm, severity in self._radar_targets:
			theta = math.radians(angle)
			target_radius = radius * min(max(r_norm, 0.18), 0.98)
			tx = cx + target_radius * math.cos(theta)
			ty = cy - target_radius * math.sin(theta)
			color_key = severity.name if isinstance(severity, ThreatSeverity) else 'IDLE'
			color = severity_colors.get(color_key, THEME['accent'])
			canvas.create_oval(tx - 6, ty - 6, tx + 6, ty + 6, outline=color, fill=color, tags='target')
			canvas.create_line(cx, cy, tx, ty, fill=color, width=1, tags='target')
		canvas.create_oval(cx - radius, cy - radius, cx + radius, cy + radius, outline=THEME['crt_glow'], width=1, tags='target')
		self._render_crt_scanlines()

	def _generate_radar_targets(self, threats: List[DetectedThreat]) -> List[Tuple[float, float, Optional[ThreatSeverity]]]:
		if not threats:
			return [((self._radar_angle + offset) % 360, 0.35 + idx * 0.18, None) for idx, offset in enumerate((0, 120, 240))]
		targets: List[Tuple[float, float, Optional[ThreatSeverity]]] = []
		max_severity = max(sev.value for sev in ThreatSeverity)
		for threat in threats:
			severity = getattr(threat, 'severity', ThreatSeverity.MEDIUM)
			score = getattr(severity, 'value', 2)
			radius_factor = 0.35 + min(score / max_severity, 1.0) * 0.6
			seed = int(hashlib.sha1(threat.threat_id.encode('utf-8')).hexdigest(), 16)
			angle = seed % 360
			targets.append((angle, min(radius_factor, 0.95), severity))
		return targets

	def _stop_radar_animation(self) -> None:
		if self._radar_job and hasattr(self, 'radar_canvas'):
			self.radar_canvas.after_cancel(self._radar_job)
			self._radar_job = None

	# ------------------------------------------------------------------
	# Engine integration
	# ------------------------------------------------------------------
	def _start_monitoring(self) -> None:
		if self.monitor_thread and self.monitor_thread.is_alive():
			return
		self.monitor_stop.clear()
		self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
		self.monitor_thread.start()

	def _monitor_loop(self) -> None:
		cycle = 0
		while not self.monitor_stop.is_set():
			if self.monitor_paused:
				time.sleep(0.25)
				continue
			with self.engine_lock:
				result = self.engine.quick_scan()
				health = self.engine.get_system_health()
				status = self.engine.get_protection_status()
				threats = list(self.engine.detected_threats)
			cycle += 1
			self.root.after(0, self._consume_cycle, health, status, result, threats, cycle)
			slept = 0.0
			while slept < self.monitor_interval and not self.monitor_stop.is_set() and not self.monitor_paused:
				time.sleep(0.25)
				slept += 0.25

	def _consume_cycle(self, health: SystemHealth, status: Dict[str, Any], result: Any,
					threats: List[DetectedThreat], cycle: int) -> None:
		self._update_phase_for_health(health)
		self._update_resources(health)
		self._update_stats(status, threats)
		self._refresh_threat_feed(threats)
		self._radar_targets = self._generate_radar_targets(threats)
		self._render_radar()
		self._log_cycle_summary(result, cycle)
		if result.threats_found:
			self.last_event_var.set(f"Cycle {cycle}: Neutralized {result.threats_found} threat(s).")
		else:
			self.last_event_var.set(f"Cycle {cycle}: Perimeter secure.")
		hyper_status = self.engine.get_hyper_status()
		state_label = "ENGAGED" if hyper_status.get('enabled') else "STANDBY"
		events = hyper_status.get('events', 0)
		self.hyper_watch_var.set(
			f"Hyper Watch: {state_label} | Q:{hyper_status.get('quarantines', 0)} P:{hyper_status.get('ping_targets', 0)} E:{events}"
		)
		self.hyper_watch_detail_var.set(self._format_hyper_watch_detail(hyper_status))
		self._process_cycle_counter += 1
		if self._process_cycle_counter % 5 == 1:
			self._update_process_sentinel()

	def _format_hyper_watch_detail(self, hyper_status: Dict[str, Any]) -> str:
		last_event = hyper_status.get('last_event') or {}
		if not last_event:
			return "Last Hyper Defense: No telemetry logged."
		attack = last_event.get('attack') or "Unknown attack"
		source = last_event.get('source') or last_event.get('ip') or "Unknown source"
		timestamp = last_event.get('timestamp')
		if timestamp:
			try:
				event_time = datetime.fromisoformat(timestamp)
				time_label = event_time.strftime("%H:%M:%S")
			except ValueError:
				time_label = timestamp
		else:
			time_label = "n/a"
		severity = last_event.get('severity') or "UNKNOWN"
		return f"Last Hyper Defense: {attack} ({severity}) from {source} @ {time_label}"

	def _update_phase_for_health(self, health: SystemHealth) -> None:
		score = getattr(health, 'overall_score', health.protection_score)
		if score >= 80:
			phase = SEREPhase.SURVIVE
		elif score >= 65:
			phase = SEREPhase.EVADE
		elif score >= 45:
			phase = SEREPhase.RESIST
		else:
			phase = SEREPhase.ESCAPE
		if getattr(health, 'active_threats', 0) >= 3 and phase.value < SEREPhase.RESIST.value:
			phase = SEREPhase.RESIST
		if phase != self.sere_phase:
			self.sere_phase = phase
			self.phase_var.set(PHASE_NAMES[phase])
			self.phase_desc_var.set(PHASE_DESCRIPTIONS[phase])

	def _update_resources(self, health: SystemHealth) -> None:
		score = getattr(health, 'overall_score', health.protection_score)
		cpu_usage = getattr(health, 'cpu_usage', getattr(health, 'cpu_percent', 0.0))
		memory_usage = getattr(health, 'memory_usage', getattr(health, 'memory_percent', 0.0))
		disk_usage = getattr(health, 'disk_usage', getattr(health, 'disk_percent', 0.0))
		self.score_var.set(str(score))
		if self.cpu_bar is not None:
			self.cpu_bar['value'] = cpu_usage
		if self.mem_bar is not None:
			self.mem_bar['value'] = memory_usage
		if self.disk_bar is not None:
			self.disk_bar['value'] = disk_usage
		self.cpu_value_var.set(f"{cpu_usage:.1f}%")
		self.mem_value_var.set(f"{memory_usage:.1f}%")
		self.disk_value_var.set(f"{disk_usage:.1f}%")
		self.status_var.set(f"Firewall: {getattr(health, 'firewall_status', getattr(health, 'firewall_enabled', 'Unknown'))}")

	def _update_stats(self, status: Dict[str, Any], threats: List[DetectedThreat]) -> None:
		active = len([t for t in threats if not t.quarantined and not t.resolved])
		quarantined = len([t for t in threats if t.quarantined])
		blocked = self.engine.metrics.get('threats_blocked', 0)
		self.active_threats_var.set(str(active))
		self.quarantine_var.set(str(quarantined))
		self.blocked_var.set(str(blocked))
		if 'system_health' in status:
			cpu = status['system_health']['cpu']
			mem = status['system_health']['memory']
			disk = status['system_health']['disk']
			self.cpu_value_var.set(str(cpu))
			self.mem_value_var.set(str(mem))
			self.disk_value_var.set(str(disk))
		severity_counts = self._count_threat_severity(threats)
		state, detail = self._derive_escalation_state(severity_counts, active)
		self._apply_escalation_banner(state, detail)

	def _count_threat_severity(self, threats: List[DetectedThreat]) -> Dict[ThreatSeverity, int]:
		counts: Dict[ThreatSeverity, int] = {sev: 0 for sev in ThreatSeverity}
		for threat in threats:
			if getattr(threat, 'resolved', False):
				continue
			severity = getattr(threat, 'severity', ThreatSeverity.MEDIUM)
			counts[severity] = counts.get(severity, 0) + 1
		return counts

	def _derive_escalation_state(self, counts: Dict[ThreatSeverity, int], active: int) -> Tuple[str, str]:
		crit = counts.get(ThreatSeverity.CRITICAL, 0)
		high = counts.get(ThreatSeverity.HIGH, 0)
		med = counts.get(ThreatSeverity.MEDIUM, 0)
		detail_counts = f"Crit {crit} • High {high} • Med {med} • Active {active}"
		if crit > 0:
			return "BREACH", f"{detail_counts} // Execute escalation protocol"
		if high > 0 or med >= 3:
			return "ENGAGED", f"{detail_counts} // Suppress hostile vectors"
		if active > 0:
			return "CONTACT", f"{detail_counts} // Maintain overwatch"
		return "IDLE", f"{detail_counts} // Perimeter secure"

	def _apply_escalation_banner(self, state: str, detail: str) -> None:
		if state == self._current_escalation_state and self.escalation_detail_var.get() == detail:
			return
		self._current_escalation_state = state
		self.escalation_state_var.set(f"STATE: {state}")
		self.escalation_detail_var.set(detail)
		tone = ESCALATION_TONES.get(state, ESCALATION_TONES['IDLE'])
		if self.escalation_banner:
			self.escalation_banner.config(bg=tone['bg'], highlightbackground=tone['border'], highlightcolor=tone['border'])
		if self._escalation_state_label:
			self._escalation_state_label.config(bg=tone['bg'], fg=tone['fg'])
		if self._escalation_detail_label:
			self._escalation_detail_label.config(bg=tone['bg'], fg=tone['detail_fg'])

	def _trigger_operator_alert(self, threat: DetectedThreat, vector: str, intel_note: str) -> None:
		severity = getattr(threat, 'severity', ThreatSeverity.MEDIUM)
		if severity.value < ThreatSeverity.HIGH.value:
			return
		tone = 'CRITICAL' if severity == ThreatSeverity.CRITICAL else 'HIGH'
		message = f"{severity.name} CONTACT // {threat.category.value} at {vector} | {intel_note}"
		self.operator_alert_var.set(message)
		self._operator_alert_active = True
		self._show_operator_alert_panel(tone)
		self._start_operator_strobe(tone)

	def _show_operator_alert_panel(self, tone_key: str) -> None:
		if not self.operator_alert_frame:
			return
		if not self._operator_alert_visible:
			self.operator_alert_frame.pack(fill=tk.X, pady=(10, 0))
			self._operator_alert_visible = True
		tone = OPERATOR_ALERT_TONES.get(tone_key, OPERATOR_ALERT_TONES['HIGH'])
		self.operator_alert_frame.config(bg=tone['base'], highlightbackground=tone['flash'])
		if self._operator_alert_label:
			self._operator_alert_label.config(bg=tone['base'], fg=tone['text'])

	def _start_operator_strobe(self, tone_key: str) -> None:
		self._stop_operator_strobe()
		self._operator_alert_tone = tone_key
		self._operator_alert_strobe_state = False

		def pulse() -> None:
			if not self._operator_alert_active or not self.operator_alert_frame:
				return
			tone = OPERATOR_ALERT_TONES.get(self._operator_alert_tone, OPERATOR_ALERT_TONES['HIGH'])
			color = tone['flash'] if self._operator_alert_strobe_state else tone['base']
			self.operator_alert_frame.config(bg=color, highlightbackground=tone['flash'])
			if self._operator_alert_label:
				self._operator_alert_label.config(bg=color, fg=tone['text'])
			self._operator_alert_strobe_state = not self._operator_alert_strobe_state
			self._operator_alert_job = self.root.after(420, pulse)

		pulse()

	def _stop_operator_strobe(self) -> None:
		if self._operator_alert_job:
			self.root.after_cancel(self._operator_alert_job)
			self._operator_alert_job = None
		self._operator_alert_strobe_state = False

	def _acknowledge_operator_alert(self) -> None:
		if not self._operator_alert_visible:
			return
		self._stop_operator_strobe()
		self._operator_alert_active = False
		if self.operator_alert_frame and self._operator_alert_visible:
			self.operator_alert_frame.pack_forget()
			self._operator_alert_visible = False
		relentless_engaged = False
		engine = getattr(self, 'engine', None)
		if engine and hasattr(engine, 'enable_relentless_mode'):
			relentless_engaged = engine.enable_relentless_mode("Operator acknowledgement from desktop console")
		if relentless_engaged:
			self._log_console("Operator acknowledgement received. Relentless Hyper Defense engaged.", tag='warning')
		else:
			self._log_console("Operator alert acknowledged. Holding perimeter.", tag='status')
		if engine:
			if hasattr(engine, 'set_obtuse_defense'):
				engine.set_obtuse_defense(True, reason="Operator acknowledgement override")
			elif hasattr(engine, 'hyper_config'):
				engine.hyper_config["OBTUSE_DEFENSE_ENABLED"] = True
			if not self._obtuse_defense_latched:
				self._obtuse_defense_latched = True
				self._log_console("Obtuse defense field engaged until perimeter reports intruder clear.", tag='warning')

	@staticmethod
	def _widget_alive(w) -> bool:
		"""Return True if a Tk widget still exists (not destroyed)."""
		try:
			return bool(w and w.winfo_exists())
		except tk.TclError:
			return False

	def _refresh_threat_feed(self, threats: List[DetectedThreat]) -> None:
		sorted_threats = sorted(threats, key=lambda t: t.timestamp, reverse=True)
		# Filter out threats from trusted IPs
		filtered_threats = [t for t in sorted_threats if (t.source not in self.trusted_ips and t.target not in self.trusted_ips)]
		# Guard: popup may have been closed — widget could be destroyed
		try:
			tree_alive = hasattr(self, 'threat_tree') and self._widget_alive(self.threat_tree)
			if tree_alive:
				self.threat_tree.delete(*self.threat_tree.get_children())
				for threat in filtered_threats[:15]:
					stamp = threat.timestamp.strftime("%H:%M:%S")
					intel_badge = self._format_intel_badge(threat)
					vector = threat.source or threat.target or "Unknown vector"
					values = (
						threat.severity.name,
						intel_badge,
						threat.category.value,
						vector,
						stamp,
					)
					self.threat_tree.insert('', tk.END, values=values)
		except tk.TclError:
			pass
		current_signatures: Set[str] = set()
		new_threats: List[DetectedThreat] = []
		for threat in filtered_threats:
			signature = self._threat_signature(threat)
			current_signatures.add(signature)
			self._threat_signature_counts[signature] = self._threat_signature_counts.get(signature, 0) + 1
			if threat.threat_id not in self._seen_threat_ids:
				new_threats.append(threat)
			elif self._should_gunny_alert(threat, is_new=False):
				self._emit_gunny_alert('threat')
		self._prune_threat_signatures(current_signatures)
		self._latest_threats = sorted_threats
		self._evaluate_obtuse_defense_posture(sorted_threats)
		self._update_geolocation_panel(sorted_threats)
		self._collect_globe_points()
		self._refresh_threat_assessment_panel()
		self._update_incident_panel(sorted_threats)
		self._update_countermeasure_panel()
		for threat in new_threats:
			vector = threat.source or threat.target or "Unknown vector"
			badge = self._format_intel_badge(threat)
			intel_note = self._format_intel_summary(threat, limit=80)
			message = f"{threat.category.value} ({threat.severity.name}) at {vector} | Intel {badge} | {intel_note}"
			self._log_console(message, tag='alert')
			self._write_threat_log(message)
			if getattr(threat, 'severity', ThreatSeverity.MEDIUM).value >= ThreatSeverity.HIGH.value:
				self._trigger_operator_alert(threat, vector, intel_note)
			if self._should_gunny_alert(threat, is_new=True):
				self._emit_gunny_alert('threat')
		self._seen_threat_ids.update(t.threat_id for t in new_threats)

	def _threat_signature(self, threat: DetectedThreat) -> str:
		vector = threat.source or threat.target or getattr(threat, 'description', '') or 'UNKNOWN'
		return f"{threat.category.value}|{vector}"

	def _should_gunny_alert(self, threat: DetectedThreat, *, is_new: bool) -> bool:
		signature = self._threat_signature(threat)
		count = self._threat_signature_counts.get(signature, 0)
		if is_new:
			self._relentless_announced.discard(signature)
			return True
		if count >= self.RELENTLESS_ALERT_THRESHOLD and signature not in self._relentless_announced:
			self._relentless_announced.add(signature)
			return True
		return False

	def _emit_gunny_alert(self, category: str) -> None:
		if self.gunny_muted:
			return
		self.gunny.bark(category)

	def _prune_threat_signatures(self, active_signatures: Set[str]) -> None:
		stale = set(self._threat_signature_counts.keys()) - active_signatures
		for signature in stale:
			self._threat_signature_counts.pop(signature, None)
			self._relentless_announced.discard(signature)

	def _has_active_intruder(self, threats: List[DetectedThreat]) -> bool:
		for threat in threats:
			# Ignore trusted IPs
			if threat.source in self.trusted_ips or threat.target in self.trusted_ips:
				continue
			severity = getattr(threat, 'severity', ThreatSeverity.MEDIUM)
			if severity.value < ThreatSeverity.HIGH.value:
				continue
			if getattr(threat, 'resolved', False) or getattr(threat, 'quarantined', False):
				continue
			return True
		return False

	def _evaluate_obtuse_defense_posture(self, threats: List[DetectedThreat]) -> None:
		if not self._obtuse_defense_latched:
			return
		engine = getattr(self, 'engine', None)
		intruder_active = True
		if engine and hasattr(engine, 'has_active_intruder'):
			intruder_active = engine.has_active_intruder()
		else:
			intruder_active = self._has_active_intruder(threats)
		if intruder_active:
			return
		if engine and hasattr(engine, 'set_obtuse_defense'):
			engine.set_obtuse_defense(False, reason="Perimeter clear - operator acknowledgement cycle complete")
		elif engine and hasattr(engine, 'hyper_config'):
			engine.hyper_config["OBTUSE_DEFENSE_ENABLED"] = False
		self._obtuse_defense_latched = False
		self._log_console("Perimeter clear. Obtuse defense field returned to standby.", tag='status')

	def _log_cycle_summary(self, result, cycle: int) -> None:
		summary = (
			f"Cycle {cycle}: {result.scan_type} scanned {result.items_scanned:,} items | "
			f"{result.threats_found} threats"
		)
		self._log_console(summary, tag='status' if result.threats_found == 0 else 'warning')

	# ------------------------------------------------------------------
	# User actions
	# ------------------------------------------------------------------
	def start_scan(self, profile: Enum = None) -> None:
		profile = profile or ScanProfile.QUICK
		if self.manual_scan_thread and self.manual_scan_thread.is_alive():
			messagebox.showinfo("Scan In Progress", "A manual scan is already running.")
			return
		self.scan_progress_var.set(0)
		self.scan_status_var.set(f"{profile.value} initialized...")
		for btn in self.scan_buttons:
			btn.config(state=tk.DISABLED)
		self._begin_progress_animation()
		self._log_console(f"{profile.value} started.")
		self.manual_scan_thread = threading.Thread(target=self._run_manual_scan, args=(profile,), daemon=True)
		self.manual_scan_thread.start()

	def _attempt_escalate(self) -> None:
		self.full_system_run()

	def full_system_run(self) -> None:
		if self.manual_scan_thread and self.manual_scan_thread.is_alive():
			messagebox.showinfo("Scan In Progress", "Finish the current scan before launching a full run.")
			return
		self.scan_progress_var.set(0)
		self.scan_status_var.set("Full System Run initializing...")
		for btn in self.scan_buttons:
			btn.config(state=tk.DISABLED)
		self._log_console("Full System Run engaged. Gunny supervising every layer.", tag='warning')
		self.manual_scan_thread = threading.Thread(target=self._execute_full_system_run, daemon=True)
		self.manual_scan_thread.start()

	def activate_evade(self) -> None:
		if self.monitor_paused:
			self.toggle_realtime()
		self.monitor_interval = 1.2
		self.sere_phase = SEREPhase.EVADE
		self.phase_var.set(PHASE_NAMES[self.sere_phase])
		self.phase_desc_var.set(PHASE_DESCRIPTIONS[self.sere_phase])
		self.status_var.set("Evasion Protocol: High cadence sweeps engaged")
		self._log_console("Evade protocol engaged. Sensors sweeping at tactical cadence.", tag='warning')
		if not (self.manual_scan_thread and self.manual_scan_thread.is_alive()):
			self.start_scan(ScanProfile.QUICK)

	def _begin_progress_animation(self) -> None:
		if self._scan_progress_job:
			self.root.after_cancel(self._scan_progress_job)
		self._scan_progress_job = self.root.after(200, self._pulse_progress)

	def _stop_progress_animation(self) -> None:
		if self._scan_progress_job:
			self.root.after_cancel(self._scan_progress_job)
			self._scan_progress_job = None
		self.scan_progress_var.set(100)

	def _pulse_progress(self) -> None:
		value = (self.scan_progress_var.get() + 3) % 100
		self.scan_progress_var.set(value)
		self._scan_progress_job = self.root.after(200, self._pulse_progress)

	def _run_manual_scan(self, profile) -> None:
		with self.engine_lock:
			result = self.engine.quick_scan()
			if profile == ScanProfile.FULL:
				second_pass = self.engine.quick_scan()
				result.items_scanned += second_pass.items_scanned
				result.threats_found += second_pass.threats_found
			health = self.engine.get_system_health()
			status = self.engine.get_protection_status()
			threats = list(self.engine.detected_threats)
		self.root.after(0, self._finalize_scan, profile, result, health, status, threats)

	def _execute_full_system_run(self) -> None:
		phases = [
			"Phase Alpha — Process Sweep",
			"Phase Bravo — Network Recon",
			"Phase Charlie — Integrity Pass",
		]
		total_items = 0
		total_threats = 0
		result = None
		for idx, label in enumerate(phases, 1):
			self.root.after(0, lambda text=label: self.scan_status_var.set(text))
			with self.engine_lock:
				phase_result = self.engine.quick_scan()
			result = phase_result
			total_items += phase_result.items_scanned
			total_threats += phase_result.threats_found
			log_tag = 'status' if phase_result.threats_found == 0 else 'warning'
			self.root.after(0, self._log_console, f"{label}: {phase_result.threats_found} threats neutralized", log_tag)
			progress = int((idx / len(phases)) * 100)
			self.root.after(0, lambda val=progress: self.scan_progress_var.set(val))
			time.sleep(0.4)
		if not result:
			return
		result.scan_type = "Full System Run"
		result.items_scanned = total_items
		result.threats_found = total_threats
		with self.engine_lock:
			health = self.engine.get_system_health()
			status = self.engine.get_protection_status()
			threats = list(self.engine.detected_threats)
		self.root.after(0, self._finalize_scan, "Full System Run", result, health, status, threats)

	def _finalize_scan(self, profile, result, health, status, threats) -> None:
		label = profile.value if isinstance(profile, Enum) else str(profile)
		if self._scan_progress_job:
			self.root.after_cancel(self._scan_progress_job)
			self._scan_progress_job = None
		self.scan_progress_var.set(100)
		self.scan_status_var.set(f"{label} complete.")
		for btn in self.scan_buttons:
			btn.config(state=tk.NORMAL)
		self._refresh_escalate_button()
		self._log_console(
			f"{label} complete. {result.items_scanned:,} files | {result.threats_found} threats",
			tag='status' if result.threats_found == 0 else 'warning'
		)
		self.manual_scan_thread = None
		self._consume_cycle(health, status, result, threats, cycle=0)

	def stop_scan(self) -> None:
		messagebox.showinfo("Enterprise Scan", "Enterprise scans cannot be interrupted once engaged.")

	def toggle_realtime(self) -> None:
		self.monitor_paused = not self.monitor_paused
		if self.monitor_paused:
			self._log_console("Auto monitoring paused.", tag='warning')
			self.status_var.set("Monitoring Paused")
		else:
			self._log_console("Auto monitoring resumed.", tag='status')
			self.status_var.set("Active Protection")
		self._refresh_toggle_buttons()

	def toggle_hyper_watch(self) -> None:
		new_state = not getattr(self.engine, 'hyper_watch_enabled', True)
		self.engine.set_hyper_watch(new_state)
		state_label = "ENGAGED" if new_state else "STANDBY"
		self.hyper_watch_var.set(f"Hyper Watch: {state_label}")
		self._log_console(f"Hyper watch {state_label.lower()}.", tag='warning')
		self._refresh_toggle_buttons()

	def toggle_gunny_voice(self) -> None:
		self.gunny_muted = not self.gunny_muted
		self._refresh_gunny_button()
		if self.gunny_muted:
			self.gunny_last_var.set("Gunny muted. Awaiting manual override.")
			self._log_console("Gunny voice muted. Audio alerts suppressed.", tag='warning')
		else:
			self.gunny_last_var.set("Gunny online. Awaiting telemetry.")
			self._log_console("Gunny voice restored. Audio alerts active.", tag='status')

	def toggle_detection_mode(self) -> None:
		"""Simulation mode is permanently disabled — this method is a no-op retained for API compatibility."""
		self._log_console(
			"Simulation mode is permanently disabled. S.E.R.E. operates on REAL threats only.",
			tag='warning')

	def _refresh_gunny_button(self) -> None:
		if not self._gunny_button:
			return
		label = "Gunny Voice: MUTED" if self.gunny_muted else "Gunny Voice: ACTIVE"
		self._gunny_button.config(text=label)
		self._apply_toggle_palette(self._gunny_button, not self.gunny_muted)

	def _refresh_mode_indicator(self) -> None:
		"""Mode is permanently REAL — update the mode_var StringVar."""
		self.mode_var.set("Detection Mode: REAL")
		self._refresh_escalate_button()

	def _register_escalate_button(self, button: tk.Widget, base_label: str) -> None:
		self._escalate_buttons.append((button, base_label))
		self._refresh_escalate_button()

	def _refresh_escalate_button(self) -> None:
		if not self._escalate_buttons:
			return
		# Always REAL — escalate is always available
		for button, base_label in self._escalate_buttons:
			button.config(state=tk.NORMAL, text=base_label)

	def run_system_repair(self) -> None:
		thread = getattr(self, '_repair_thread', None)
		if thread and thread.is_alive():
			messagebox.showinfo("System Repair", "Repair routine already running.")
			return
		self._log_console("System repair initiated. Gunny supervising host integrity.", tag='warning')
		self.scan_status_var.set("Host repair running...")
		self._repair_thread = threading.Thread(target=self._perform_system_repair, daemon=True)
		self._repair_thread.start()

	def _perform_system_repair(self) -> None:
		results = self.engine.perform_system_repair()
		def finalize() -> None:
			for cmd, output in results.items():
				snippet = (output or "Completed")
				if len(snippet) > 220:
					snippet = snippet[:217] + "..."
				self._log_console(f"{cmd}: {snippet}", tag='status')
			self.scan_status_var.set("Host repair complete.")
		self.root.after(0, finalize)

	def _launch_ping_flood_dialog(self) -> None:
		"""Show a dialog to collect target IPs and intensity, then launch ping flood defense."""
		dialog = tk.Toplevel(self.root)
		dialog.title("Ping Flood Defense")
		dialog.configure(bg=THEME['panel'])
		dialog.resizable(False, False)
		dialog.grab_set()

		tk.Label(dialog, text="PING FLOOD DEFENSE", font=('Consolas', 14, 'bold'),
				 fg=THEME['hud_warning'], bg=THEME['panel']).pack(pady=(16, 4), padx=24)
		tk.Label(dialog, text="Enter confirmed threat IPs (comma-separated):",
				 font=('Consolas', 10), fg=THEME['text'], bg=THEME['panel']).pack(anchor='w', padx=24)
		ip_var = tk.StringVar()
		ip_entry = tk.Entry(dialog, textvariable=ip_var, font=('Consolas', 11),
							bg=THEME['bg'], fg=THEME['text'], insertbackground=THEME['text'], width=40)
		ip_entry.pack(padx=24, pady=4)

		tk.Label(dialog, text="Duration (seconds):", font=('Consolas', 10),
				 fg=THEME['text'], bg=THEME['panel']).pack(anchor='w', padx=24)
		dur_var = tk.StringVar(value="15")
		tk.Entry(dialog, textvariable=dur_var, font=('Consolas', 11),
				 bg=THEME['bg'], fg=THEME['text'], insertbackground=THEME['text'], width=10).pack(padx=24, pady=4, anchor='w')

		tk.Label(dialog, text="Intensity:", font=('Consolas', 10),
				 fg=THEME['text'], bg=THEME['panel']).pack(anchor='w', padx=24)
		intensity_var = tk.StringVar(value="medium")
		for label, val in [("Low (recon)", "low"), ("Medium (standard)", "medium"), ("High (max pressure)", "high")]:
			tk.Radiobutton(dialog, text=label, variable=intensity_var, value=val,
						   font=('Consolas', 10), fg=THEME['text'], bg=THEME['panel'],
						   selectcolor=THEME['bg'], activebackground=THEME['panel']).pack(anchor='w', padx=36)

		def _confirm() -> None:
			raw_ips = [ip.strip() for ip in ip_var.get().split(',') if ip.strip()]
			if not raw_ips:
				messagebox.showwarning("Ping Flood Defense", "Enter at least one IP address.", parent=dialog)
				return
			try:
				duration = max(1, min(120, int(dur_var.get())))
			except ValueError:
				duration = 15
			intensity = intensity_var.get()
			dialog.destroy()
			self._run_ping_flood_defense(raw_ips, duration, intensity)

		btn_frame = tk.Frame(dialog, bg=THEME['panel'])
		btn_frame.pack(pady=(12, 20), padx=24, fill=tk.X)
		tk.Button(btn_frame, text="DEPLOY", command=_confirm, font=('Consolas', 12, 'bold'),
				  bg=THEME['hud_warning'], fg='#000000', relief=tk.FLAT, pady=6).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0, 8))
		tk.Button(btn_frame, text="Cancel", command=dialog.destroy, font=('Consolas', 10),
				  bg=THEME['button'], fg=THEME['button_text'], relief=tk.FLAT).pack(side=tk.LEFT)

	def _run_ping_flood_defense(self, ips: List[str], duration: int, intensity: str) -> None:
		"""Execute ping flood defense in a background thread, routing through Safety Hierarchy."""
		self.scan_status_var.set("Ping Flood Defense deploying...")
		for btn in self.scan_buttons:
			btn.config(state=tk.DISABLED)
		self._begin_progress_animation()
		self._log_console(
			f"[PING FLOOD] Deploying {intensity.upper()} on {', '.join(ips)} for {duration}s. "
			f"Mythara Safety Hierarchy enforced.", tag='warning')

		def worker() -> None:
			with self.engine_lock:
				results = self.engine.ping_flood_defense(ips, duration=duration, intensity=intensity)
			self.root.after(0, _finalize, results)

		def _finalize(results: dict) -> None:
			self._stop_progress_animation()
			for btn in self.scan_buttons:
				btn.config(state=tk.NORMAL)
			self.scan_status_var.set("Ping Flood Defense complete.")
			for ip, data in results.items():
				if data.get('status') == 'blocked_by_hierarchy':
					self._log_console(f"[PING FLOOD] {ip} blocked by Safety Hierarchy.", tag='warning')
				else:
					self._log_console(
						f"[PING FLOOD] {ip} — {data.get('sent',0)} pings sent, "
						f"{data.get('success',0)} returned, avg {data.get('avg_latency_ms',0)}ms", tag='status')

		threading.Thread(target=worker, daemon=True).start()

	def run_big_meanie_assessment(self) -> None:
		if not getattr(self.engine, 'big_meanie_available', False):
			messagebox.showinfo("Big Meanie Assault", "Big Meanie module unavailable in this build.")
			self._log_console("Big Meanie assault skipped — module unavailable.", tag='warning')
			return
		if self._big_meanie_thread and self._big_meanie_thread.is_alive():
			messagebox.showinfo("Big Meanie Assault", "An assault is already running.")
			return
		self.scan_progress_var.set(0)
		self.scan_status_var.set("Big Meanie assault initializing...")
		for btn in self.scan_buttons:
			btn.config(state=tk.DISABLED)
		self._begin_progress_animation()
		self._log_console("Big Meanie assault engaged. Gunny unleashing maximum adversarial pressure.", tag='warning')

		def worker() -> None:
			with self.engine_lock:
				summary = self.engine.run_big_meanie_assessment()
				health = self.engine.get_system_health()
				status = self.engine.get_protection_status()
				threats = list(self.engine.detected_threats)
			self.root.after(0, self._finalize_big_meanie_assessment, summary, health, status, threats)

		self._big_meanie_thread = threading.Thread(target=worker, daemon=True)
		self._big_meanie_thread.start()

	def _finalize_big_meanie_assessment(self, summary: Dict[str, Any], health: SystemHealth, status: Dict[str, Any],
								threats: List[DetectedThreat]) -> None:
		if self._scan_progress_job:
			self.root.after_cancel(self._scan_progress_job)
			self._scan_progress_job = None
		self.scan_progress_var.set(100)
		for btn in self.scan_buttons:
			btn.config(state=tk.NORMAL)
		self._refresh_escalate_button()
		self._big_meanie_thread = None

		if not isinstance(summary, dict):
			self.scan_status_var.set("Big Meanie assault failed.")
			self._log_console("Big Meanie assault returned no telemetry.", tag='warning')
			return

		status_flag = summary.get('status')
		if status_flag == 'unavailable':
			self.scan_status_var.set("Big Meanie unavailable in this build.")
			messagebox.showinfo("Big Meanie Assault", "Big Meanie module unavailable in this environment.")
			self._log_console("Big Meanie assault blocked — module unavailable.", tag='warning')
			return
		if status_flag == 'error':
			error_msg = summary.get('error', 'Unknown error')
			self.scan_status_var.set("Big Meanie assault failed.")
			messagebox.showerror("Big Meanie Assault", f"Assessment failed: {error_msg}")
			self._log_console(f"Big Meanie assault failed: {error_msg}", tag='alert')
			return

		total = int(summary.get('total_attacks', 0) or 0)
		breaches = int(summary.get('breaches', 0) or 0)
		vulnerabilities = int(summary.get('vulnerabilities', 0) or 0)
		apt_hits = int(summary.get('apt_threats', 0) or 0)
		term_risk = float(summary.get('terminal_risk', 0.0) or 0.0)
		sec_score = summary.get('security_score')
		risk_level = summary.get('risk_level', 'UNKNOWN')
		score_text = f"{sec_score:.1f}%" if isinstance(sec_score, (int, float)) else "n/a"
		issues = breaches + vulnerabilities + apt_hits
		status_line = (
			f"Big Meanie assault complete — {breaches} breach(es), {vulnerabilities} exposure(s), "
			f"APT hits {apt_hits}. Risk {risk_level} | Score {score_text} | Terminal risk {term_risk:.2f}"
		)
		self.scan_status_var.set("Big Meanie assault complete.")
		self.last_event_var.set(
			f"Big Meanie risk {risk_level} | Breaches {breaches} | Terminal risk {term_risk:.2f}"
		)
		self._log_console(status_line, tag='warning' if issues else 'status')

		pseudo_result = SimpleNamespace(
			scan_type="Big Meanie Assault",
			items_scanned=total,
			threats_found=max(issues, 0),
		)
		self._consume_cycle(health, status, pseudo_result, threats, cycle=0)

	def show_quarantine(self) -> None:
		items = [t for t in self.engine.detected_threats if t.quarantined]
		if not items:
			messagebox.showinfo("Quarantine", "No items currently quarantined.")
			return
		lines = [f"{t.threat_id} | {t.category.value} | {t.source or t.target}" for t in items]
		messagebox.showinfo("Quarantine", "\n".join(lines[:10]))

	def open_threat_log(self) -> None:
		try:
			path_str = str(self.threat_log_path)
			if sys.platform.startswith('win'):
				os.startfile(path_str)
			elif sys.platform.startswith('darwin'):
				subprocess.Popen(['open', path_str])
			else:
				subprocess.Popen(['xdg-open', path_str])
		except Exception as exc:
			messagebox.showerror("Threat Log", f"Unable to open threat log: {exc}")

	# ------------------------------------------------------------------
	# Engine callbacks
	# ------------------------------------------------------------------
	def _write_threat_log(self, message: str) -> None:
		with self.threat_log_path.open('a', encoding='utf-8') as fh:
			fh.write(f"{datetime.now().isoformat()} {message}\n")

	def _update_geolocation_panel(self, threats: List[DetectedThreat]) -> None:
		if not hasattr(self, 'geo_board') or not self._widget_alive(self.geo_board):
			return
		lines: List[Tuple[ThreatSeverity, str, str, str]] = []
		for threat in threats[:4]:
			badge = self._format_intel_badge(threat)
			summary = self._format_intel_summary(threat, limit=96)
			lines.append((threat.severity, self._describe_threat_location(threat), badge, summary))
		if not lines:
			lines = [
				(
					ThreatSeverity.INFO,
					"No hostile telemetry on scope.",
					"00% CLEAR [IDLE]",
					"Awaiting hostiles..."
				)
			]
		self.geo_board.config(state='normal')
		self.geo_board.delete('1.0', tk.END)
		for severity, text, badge, summary in lines:
			sev = severity if isinstance(severity, ThreatSeverity) else ThreatSeverity.INFO
			if sev.value >= ThreatSeverity.HIGH.value:
				tag = 'alert'
			elif sev.value >= ThreatSeverity.MEDIUM.value:
				tag = 'warning'
			else:
				tag = 'status'
			self.geo_board.insert(tk.END, f"{text}\n", tag)
			intel_line = f"  -> Intel {badge} | {summary}\n"
			self.geo_board.insert(tk.END, intel_line, 'intel')
			self.geo_board.insert(tk.END, "\n")
		self.geo_board.config(state='disabled')
		self._collect_globe_points()
		self._refresh_threat_assessment_panel()

	def _describe_threat_location(self, threat: DetectedThreat) -> str:
		vector = threat.source or threat.target or "Unknown vector"
		ip = self._extract_ip_from_threat(threat)
		label = threat.category.value
		if not ip:
			return f"{label} • {vector} (location unknown)"
		if ip in self.geolocation_cache:
			geo = self.geolocation_cache[ip]
			city = geo.get('city') or 'Unknown City'
			region = geo.get('region') or geo.get('country') or 'Unknown Region'
			return f"{label} • {city}, {region} ({ip})"
		if ip not in self._geo_pending:
			self._geo_pending.add(ip)
			self._geolocate_ip_async(ip)
		return f"{label} • {ip} (triangulating)"

	def _update_incident_panel(self, threats: List[DetectedThreat]) -> None:
		profile = self._derive_incident_profile(threats)
		self.incident_root_var.set(profile['root'])
		self.incident_assets_var.set(profile['assets'])
		self.incident_response_var.set(profile['response'])

	def _derive_incident_profile(self, threats: List[DetectedThreat]) -> Dict[str, str]:
		active = [t for t in threats if not getattr(t, 'resolved', False)]
		if not active:
			return {
				'root': "No active incidents. Perimeter calm.",
				'assets': "Assets secure. No telemetry anomalies.",
				'response': "Recommended response: Standby.",
			}
		prioritized = sorted(active, key=lambda t: (getattr(t, 'severity', ThreatSeverity.MEDIUM).value, getattr(t, 'timestamp', datetime.now())), reverse=True)
		primary = prioritized[0]
		vector = primary.source or primary.target or "Unknown vector"
		root = f"{primary.category.value} via {vector}. Severity {primary.severity.name}."
		assets = self._summarize_impacted_assets(prioritized)
		response = self._recommended_response(primary)
		return {'root': root, 'assets': assets, 'response': response}

	def _summarize_impacted_assets(self, threats: List[DetectedThreat]) -> str:
		assets: List[str] = []
		for threat in threats[:10]:
			for field in (threat.source, threat.target):
				if field:
					assets.append(str(field))
		if not assets:
			return "Impacted assets: Unknown vectors."
		counts = Counter(assets)
		top = counts.most_common(3)
		parts = []
		for asset, count in top:
			parts.append(f"{asset} x{count}" if count > 1 else asset)
		return "Impacted assets: " + ', '.join(parts)

	def _recommended_response(self, threat: DetectedThreat) -> str:
		severity = getattr(threat, 'severity', ThreatSeverity.MEDIUM)
		playbook = {
			ThreatSeverity.CRITICAL: "Response: Initiate escalation, isolate segments, notify command.",
			ThreatSeverity.HIGH: "Response: Contain host, enforce quarantine, verify credentials.",
			ThreatSeverity.MEDIUM: "Response: Increase monitoring, validate network pathways.",
			ThreatSeverity.LOW: "Response: Track activity, prep countermeasures.",
		}
		base = playbook.get(severity, "Response: Maintain situational awareness.")
		intel = self._format_intel_summary(threat, limit=90)
		return f"{base} Intel: {intel}"

	def _update_countermeasure_panel(self) -> None:
		if not self.countermeasure_board or not self._widget_alive(self.countermeasure_board):
			return
		try:
			hyper = self.engine.get_hyper_status()
			quarantine = self.engine.get_quarantine_snapshot()
			ping = self.engine.get_ping_snapshot()
		except Exception:
			return
		blocked_ips = len(getattr(self.engine, 'blocked_ips', set()))
		blocked_procs = len(getattr(self.engine, 'blocked_processes', set()))
		mode_label = "REAL OPS"
		state_label = "ENGAGED" if hyper.get('enabled') else "STANDBY"
		status = (
			f"{mode_label} | HyperWatch {state_label} | Events {hyper.get('events', 0)} | "
			f"Quarantine {len(quarantine)} | PingWatch {len(ping)} | Blocks {blocked_ips} IP / {blocked_procs} PROC"
		)
		self.countermeasure_status_var.set(status)
		lines: List[str] = []
		for zone in quarantine[:3]:
			lines.append(f"Quarantine {zone['ip']} ({zone['type']}) [{zone['status']}]")
		for monitor in ping[:3]:
			alive = "STABLE" if monitor.get('alive') else f"FAIL x{monitor.get('failures')}"
			latency = monitor.get('response_time')
			lat_label = f"{int(latency)}ms" if isinstance(latency, (int, float)) else "n/a"
			lines.append(f"PingWatch {monitor['ip']} {alive} ({lat_label})")
		if blocked_ips:
			sample = list(getattr(self.engine, 'blocked_ips', set()))[:3]
			lines.append(f"Blocked IPs: {', '.join(sample)}")
		if blocked_procs:
			sample_proc = list(str(pid) for pid in getattr(self.engine, 'blocked_processes', set()))[:3]
			lines.append(f"Blocked PIDs: {', '.join(sample_proc)}")
		last_event = hyper.get('last_event') or {}
		if last_event:
			attack = last_event.get('attack') or 'Unknown'
			source = last_event.get('source') or last_event.get('ip') or 'Unknown'
			severity = last_event.get('severity') or 'UNKNOWN'
			lines.append(f"Hyper Defense last: {attack} ({severity}) from {source}")
		else:
			lines.append("Hyper Defense last: No telemetry.")
		if not lines:
			lines = ["No countermeasures currently active."]
		self.countermeasure_board.config(state='normal')
		self.countermeasure_board.delete('1.0', tk.END)
		for line in lines:
			self.countermeasure_board.insert(tk.END, f"{line}\n")
		self.countermeasure_board.config(state='disabled')

	def _format_intel_badge(self, threat: Optional[DetectedThreat]) -> str:
		score = float(getattr(threat, 'intel_score', 0.0) or 0.0)
		score = max(0.0, min(score, 0.99))
		percent = int(round(score * 100))
		if percent >= 85:
			label = "CRITICAL"
		elif percent >= 70:
			label = "HIGH"
		elif percent >= 50:
			label = "ELEVATED"
		elif percent >= 30:
			label = "LOW"
		else:
			label = "CLEAR"
		sources = list(getattr(threat, 'intel_sources', []) or [])
		short_sources = '/'.join(self._shorten_intel_source(src) for src in sources[:2]) or 'HEUR'
		return f"{percent:02d}% {label} [{short_sources}]"

	@staticmethod
	def _shorten_intel_source(source: Optional[str]) -> str:
		if not source:
			return 'HEUR'
		compact = source.strip().split()[0]
		return compact.upper()

	def _format_intel_summary(self, threat: Optional[DetectedThreat], *, limit: int = 96) -> str:
		summary = getattr(threat, 'intel_summary', '') if threat else 'No hostile telemetry on scope.'
		if not summary:
			summary = 'Awaiting external verdict'
		summary = summary.strip()
		if len(summary) > limit:
			summary = summary[:limit - 1].rstrip() + '…'
		return summary or 'Awaiting external verdict'

	def _extract_ip_from_threat(self, threat: DetectedThreat) -> Optional[str]:
		candidates: List[str] = []
		if getattr(threat, 'network_info', None):
			candidates.extend([
				str(threat.network_info.get('remote_ip', '')),
				str(threat.network_info.get('ip', '')),
			])
		for field in (threat.source, threat.target, getattr(threat, 'description', '')):
			if field:
				candidates.append(str(field))
		for candidate in candidates:
			match = IPV4_PATTERN.search(candidate)
			if match:
				return match.group(0)
		return None

	def _geolocate_ip_async(self, ip: str) -> None:
		def worker() -> None:
			data = self._fetch_geolocation(ip)
			if data:
				self.geolocation_cache[ip] = data
			self._geo_pending.discard(ip)
			self.root.after(0, lambda: self._update_geolocation_panel(self._latest_threats))

		threading.Thread(target=worker, daemon=True).start()

	def _fetch_geolocation(self, ip: str) -> Optional[Dict[str, str]]:
		try:
			ip_obj = ipaddress.ip_address(ip)
			if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_multicast:
				return None
		except ValueError:
			return None
		try:
			req = urllib_request.Request(
				f"https://ip-api.com/json/{ip}",
				headers={'User-Agent': 'SERE-Tactical-GUI'}
			)
			with urllib_request.urlopen(req, timeout=2) as resp:
				payload = resp.read().decode('utf-8')
				data = json.loads(payload)
			if data.get('status') == 'success':
				return {
					'city': data.get('city', ''),
					'region': data.get('regionName', ''),
					'country': data.get('country', ''),
					'lat': data.get('lat'),
					'lon': data.get('lon'),
				}
		except URLError:
			return None
		except Exception:
			return None
		return None

	def _bootstrap_engine_logs(self) -> None:
		for event in list(self.engine.event_log):
			level = event.get('level', 'INFO')
			message = event.get('message', '')
			tag = self._log_tag_for_level(level)
			self._log_console(f"[{level}] {message}", tag)

	def _handle_engine_log_event(self, event: Dict[str, Any]) -> None:
		level = event.get('level', 'INFO').upper()
		message = event.get('message', '')
		tag = self._log_tag_for_level(level)

		def push():
			self._log_console(f"[{level}] {message}", tag=tag)

		self.root.after(0, push)
		self._relay_gunny_for_level(level, message)

	def _log_tag_for_level(self, level: str) -> str:
		mapping = {
			'INFO': 'status',
			'SUCCESS': 'status',
			'WARNING': 'warning',
			'ALERT': 'warning',
			'CRITICAL': 'alert',
		}
		return mapping.get(level.upper(), 'status')

	def _relay_gunny_for_level(self, level: str, message: str) -> None:
		level = level.upper()
		if level not in {'ALERT', 'CRITICAL'}:
			return
		now = time.time()
		if now - self._last_log_voice < self._log_voice_cooldown:
			return
		self._last_log_voice = now
		if self.gunny_muted:
			return
		bucket = 'gunny' if level == 'CRITICAL' else 'cease'
		persona_text = persona_line(bucket)
		self.gunny.speak_async(f"{persona_text} // {message}")

	def _queue_gunny_message(self, text: str) -> None:
		if self.gunny_muted:
			return
		def push() -> None:
			self.gunny_last_var.set(text)
			self._log_console(text, tag='warning')
		self.root.after(0, push)

	# ------------------------------------------------------------------
	# Logging helpers
	# ------------------------------------------------------------------
	def _log_console(self, message: str, tag: str = 'status') -> None:
		timestamp = datetime.now().strftime('%H:%M:%S')
		self.log_text.config(state='normal')
		self.log_text.insert('end', f"[{timestamp}] {message}\n", tag)
		self.log_text.see('end')
		self.log_text.config(state='disabled')

	# ------------------------------------------------------------------
	# Shutdown
	# ------------------------------------------------------------------
	def shutdown(self) -> None:
		self.monitor_stop.set()
		self._close_threat_assessment()
		if self.monitor_thread and self.monitor_thread.is_alive():
			self.monitor_thread.join(timeout=2)
		if self.manual_scan_thread and self.manual_scan_thread.is_alive():
			self.manual_scan_thread.join(timeout=2)
		self.engine.remove_log_listener(self._handle_engine_log_event)
		self._stop_visualizers()
		self._stop_radar_animation()
		self._stop_operator_strobe()
		self.root.destroy()


class ScanProfile(Enum):
	QUICK = "Quick Scan"
	FULL = "Full Scan"


def _print_startup_hints() -> None:
	"""Print quick operator hints when launching the desktop console."""
	print("[S.E.R.E.] Desktop console starting")
	print("[S.E.R.E.] Quick guide:")
	print("  - Gunny Voice toggle: enable or mute guided voice")
	print("  - Detection Mode: REAL mode stays active for host safety")
	print("  - Start Scan / Full Sweep are available in Mission Commands")
	print("[S.E.R.E.] Tip: close the main window for a clean shutdown.")


if __name__ == "__main__":
	_print_startup_hints()
	app = SEREDesktopGUI()
	app.run()
