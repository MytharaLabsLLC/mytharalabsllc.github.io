#!/usr/bin/env python3
"""
S.E.R.E. Incident Response Playbook Automation.

Copyright © 2025 Herbert Velez Jr. All rights reserved.
Proprietary and Confidential.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import logging
import os
import platform
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

import psutil

from sere_hyper_defense import lookup_geolocation, WINDOWS_EVENT_LOG_AVAILABLE

try:  # pragma: no cover - optional dependency on Windows
    import win32evtlog  # type: ignore
except ImportError:  # pragma: no cover - optional dependency
    win32evtlog = None

LOG = logging.getLogger(__name__)

DEFAULT_PLAYBOOK_CONFIG = {
    "trusted_internal_ranges": [
        "10.0.0.0/8",
        "172.16.0.0/12",
        "192.168.0.0/16",
    ],
    "trusted_partner_ranges": [
        {"name": "AzureEastUS", "cidr": "13.64.0.0/11", "country": "United States"},
        {"name": "AzureWestUS", "cidr": "20.33.0.0/16", "country": "United States"},
        {"name": "GitHub", "cidr": "140.82.0.0/16", "country": "United States"},
    ],
    "expected_countries": ["United States", "Canada"],
    "trusted_dns_servers": ["8.8.8.8", "1.1.1.1"],
    "sensitive_domains": ["mythara", "bank", "fin"],
    "firewall_log_paths": [
        r"C:\\Windows\\System32\\LogFiles\\Firewall",
        "/var/log/ufw.log",
    ],
    "packet_capture_paths": [
        "./captures",
        str(Path.home() / "captures"),
    ],
}


@dataclass
class AlertInput:
    """Container for alert inputs that feed the incident playbook."""

    ip: str
    category: str = "Network Intrusion"
    severity: str = "MEDIUM"
    timestamp: datetime = field(default_factory=datetime.utcnow)
    location: Optional[str] = None

    @staticmethod
    def _parse_timestamp(value: Any) -> datetime:
        if isinstance(value, datetime):
            return value
        if isinstance(value, (int, float)):
            try:
                return datetime.fromtimestamp(value)
            except (ValueError, OSError):
                return datetime.utcnow()
        if isinstance(value, str):
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%m/%d/%Y %H:%M:%S"):
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    continue
            try:
                return datetime.fromisoformat(value.replace("Z", "+00:00"))
            except ValueError:
                return datetime.utcnow()
        return datetime.utcnow()

    @classmethod
    def from_payload(cls, payload: Dict[str, Any], fallback_severity: str = "MEDIUM") -> "AlertInput":
        ip_value = str(
            payload.get("ip")
            or payload.get("source_ip")
            or payload.get("source")
            or payload.get("location")
            or ""
        ).strip()
        timestamp = cls._parse_timestamp(
            payload.get("timestamp")
            or payload.get("time")
            or payload.get("observed_at")
        )
        severity_value = str(payload.get("severity") or fallback_severity).upper()
        category_value = str(payload.get("category") or payload.get("type") or "Network Intrusion")
        location_value = payload.get("location")
        return cls(
            ip=ip_value,
            category=category_value,
            severity=severity_value,
            timestamp=timestamp,
            location=location_value,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ip": self.ip,
            "category": self.category,
            "severity": self.severity,
            "timestamp": self.timestamp.isoformat(),
            "location": self.location,
        }


class IncidentResponsePlaybook:
    """Automates response actions for inbound alerts."""

    def __init__(self, engine: Any, config_path: Optional[Path] = None):
        self.engine = engine
        self.runtime_path = getattr(engine, "runtime_path", Path.home() / ".sere_enterprise")
        self.runtime_path.mkdir(parents=True, exist_ok=True)
        self.artifact_path = self.runtime_path / "playbook_artifacts"
        self.artifact_path.mkdir(exist_ok=True)
        self.config_path = (
            Path(config_path)
            if config_path
            else self.runtime_path / "incident_playbook.json"
        )
        self.config = self._load_config()

    def execute(
        self,
        alerts: Sequence[AlertInput],
        window_minutes: int = 15,
        capture_packets: bool = False,
        auto_block: bool = False,
    ) -> Dict[str, Any]:
        if not alerts:
            raise ValueError("alerts are required for the playbook")
        now = datetime.utcnow()
        window_start = now - timedelta(minutes=window_minutes)
        processed: List[Dict[str, Any]] = []
        geofence_plan: List[Dict[str, Any]] = []

        for alert in alerts:
            if not alert.ip:
                continue
            verdict = self._classify_ip(alert.ip, alert.severity)
            firewall_hits = self._collect_firewall_hits(alert.ip, window_start)
            session_traces = self._collect_session_traces(alert.ip)
            sere_events = self._collect_engine_events(alert.ip, window_start)
            packet_artifacts = self._collect_packet_artifacts(alert.ip, window_start)
            capture_summary = None
            if capture_packets:
                capture_summary = self._run_targeted_capture(alert.ip)
            action_result = None
            if auto_block and verdict.get("recommended_action") == "block" and not verdict.get("is_internal"):
                if alert.ip not in self.engine.blocked_ips:
                    blocked = self.engine.block_ip(alert.ip)
                    action_result = "blocked" if blocked else "block_failed"
                else:
                    action_result = "already_blocked"
                geofence_plan.append({
                    "ip": alert.ip,
                    "classification": verdict.get("classification"),
                    "action": action_result,
                })

            processed.append(
                {
                    "alert": alert.to_dict(),
                    "verdict": verdict,
                    "firewall": firewall_hits,
                    "session_traces": session_traces,
                    "sere_events": sere_events,
                    "packet_artifacts": packet_artifacts,
                    "capture": capture_summary,
                    "actions": action_result,
                }
            )

        endpoint_report = self._verify_endpoint_integrity(window_start)
        return {
            "generated_at": now.isoformat(),
            "alert_window_minutes": window_minutes,
            "alerts_processed": len(processed),
            "results": processed,
            "endpoint_integrity": endpoint_report,
            "geofence_plan": geofence_plan,
        }

    # ------------------------------------------------------------------
    # Classification helpers
    # ------------------------------------------------------------------
    def _load_config(self) -> Dict[str, Any]:
        if self.config_path.exists():
            try:
                data = json.loads(self.config_path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    merged = dict(DEFAULT_PLAYBOOK_CONFIG)
                    merged.update(data)
                    return merged
            except json.JSONDecodeError:
                LOG.warning("Invalid incident playbook config, falling back to defaults")
        self.config_path.write_text(json.dumps(DEFAULT_PLAYBOOK_CONFIG, indent=2))
        return dict(DEFAULT_PLAYBOOK_CONFIG)

    def _classify_ip(self, ip: str, severity: str) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "ip": ip,
            "severity": severity,
            "classification": "unknown",
            "intel_hits": [],
            "recommended_action": "observe",
            "geolocation": None,
            "is_internal": False,
            "partner": None,
        }
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            record["classification"] = "invalid"
            record["recommended_action"] = "ignore"
            return record

        if any(addr in ipaddress.ip_network(cidr) for cidr in self.config["trusted_internal_ranges"]):
            record["classification"] = "internal"
            record["is_internal"] = True
            record["recommended_action"] = "monitor"
            return record

        partner = None
        for entry in self.config["trusted_partner_ranges"]:
            try:
                network = ipaddress.ip_network(entry["cidr"])
            except ValueError:
                continue
            if addr in network:
                partner = entry
                break
        if partner:
            record["classification"] = "partner"
            record["partner"] = partner.get("name")
            record["recommended_action"] = "monitor"
        else:
            if ip in self.engine.intel.malicious_ips:
                record["classification"] = "known-malicious"
                record["intel_hits"].append("local_reputation")
                record["recommended_action"] = "block"
            else:
                record["classification"] = "external"
                record["recommended_action"] = "investigate"

        geo = lookup_geolocation(ip)
        if geo:
            geo_summary = {
                "ip": geo.ip,
                "city": geo.city,
                "region": geo.region,
                "country": geo.country,
                "org": geo.org,
            }
            record["geolocation"] = geo_summary
            if self.config["expected_countries"] and geo.country not in self.config["expected_countries"]:
                record["intel_hits"].append("geo_mismatch")
                if record["classification"] == "external":
                    record["recommended_action"] = "block"
                    record["classification"] = "geo-risk"
        return record

    # ------------------------------------------------------------------
    # Evidence collection
    # ------------------------------------------------------------------
    def _collect_firewall_hits(self, ip: str, window_start: datetime) -> Dict[str, Any]:
        hits: List[Dict[str, Any]] = []
        deadline = window_start.timestamp()
        for path_entry in self.config["firewall_log_paths"]:
            path = Path(path_entry).expanduser()
            if not path.exists():
                continue
            files: Iterable[Path]
            if path.is_dir():
                files = sorted(path.glob("*.log"), reverse=True)
            else:
                files = [path]
            for file in files:
                try:
                    for line in file.read_text(encoding="utf-8", errors="ignore").splitlines():
                        if ip not in line or line.startswith("#"):
                            continue
                        parts = line.split()
                        if len(parts) < 8:
                            continue
                        ts = self._parse_firewall_timestamp(parts[0], parts[1])
                        if ts and ts.timestamp() >= deadline:
                            hits.append(
                                {
                                    "timestamp": ts.isoformat(),
                                    "action": parts[2],
                                    "protocol": parts[3],
                                    "src_ip": parts[4],
                                    "dest_ip": parts[5],
                                    "src_port": parts[6],
                                    "dest_port": parts[7],
                                    "path": str(file),
                                }
                            )
                        if len(hits) >= 25:
                            break
                except OSError:
                    continue
                if len(hits) >= 25:
                    break
            if hits:
                break
        return {"matches": hits, "status": "found" if hits else "none"}

    @staticmethod
    def _parse_firewall_timestamp(date_part: str, time_part: str) -> Optional[datetime]:
        try:
            return datetime.strptime(f"{date_part} {time_part}", "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return None

    def _collect_session_traces(self, ip: str) -> Dict[str, Any]:
        matches: List[Dict[str, Any]] = []
        try:
            connections = psutil.net_connections(kind="inet")
        except Exception as exc:  # pragma: no cover - psutil may fail without perms
            return {"status": "error", "error": str(exc)}
        for conn in connections:
            remote = conn.raddr.ip if conn.raddr else None
            if remote != ip:
                continue
            entry: Dict[str, Any] = {
                "local": f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else None,
                "remote": f"{remote}:{conn.raddr.port}" if conn.raddr else None,
                "status": conn.status,
            }
            if conn.pid:
                try:
                    proc = psutil.Process(conn.pid)
                    entry["process"] = proc.name()
                    entry["pid"] = conn.pid
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    entry["pid"] = conn.pid
            matches.append(entry)
            if len(matches) >= 20:
                break
        return {"status": "found" if matches else "none", "connections": matches}

    def _collect_engine_events(self, ip: str, window_start: datetime) -> List[Dict[str, Any]]:
        events: List[Dict[str, Any]] = []
        for event in reversed(list(self.engine.event_log)):
            try:
                ts = datetime.fromisoformat(event.get("timestamp"))
            except Exception:
                continue
            if ts < window_start:
                continue
            payload = json.dumps(event)
            if ip in payload:
                events.append(event)
            if len(events) >= 20:
                break
        return events

    def _collect_packet_artifacts(self, ip: str, window_start: datetime) -> Dict[str, Any]:
        artifacts: List[Dict[str, Any]] = []
        threshold = window_start.timestamp()
        for entry in self.config["packet_capture_paths"]:
            path = Path(entry).expanduser()
            if not path.exists():
                continue
            files = []
            if path.is_file():
                files = [path]
            else:
                files = list(path.glob("**/*.pcap*")) + list(path.glob("**/*.etl"))
            for file in files:
                try:
                    if file.stat().st_mtime < threshold:
                        continue
                    artifacts.append({"path": str(file), "size": file.stat().st_size})
                except OSError:
                    continue
            if artifacts:
                break
        return {"status": "found" if artifacts else "none", "artifacts": artifacts}

    def _run_targeted_capture(self, ip: str, duration: int = 5) -> Dict[str, Any]:
        if platform.system() == "Windows" and shutil.which("netsh"):
            return self._run_netsh_trace(ip, duration)
        if shutil.which("tcpdump"):
            return self._run_tcpdump_capture(ip, duration)
        return {"status": "skipped", "reason": "no capture tool"}

    def _run_netsh_trace(self, ip: str, duration: int) -> Dict[str, Any]:
        timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
        trace_path = self.artifact_path / f"netsh_{ip.replace('.', '_')}_{timestamp}.etl"
        try:
            subprocess.run(
                [
                    "netsh",
                    "trace",
                    "start",
                    "capture=yes",
                    "report=no",
                    "persistent=no",
                    f"tracefile={trace_path}",
                    "maxsize=25",
                    "overwrite=yes",
                ],
                check=False,
                capture_output=True,
                text=True,
                timeout=10,
            )
            time.sleep(max(1, duration))
            subprocess.run(
                ["netsh", "trace", "stop"],
                check=False,
                capture_output=True,
                text=True,
                timeout=10,
            )
            return {"status": "captured", "path": str(trace_path)}
        except Exception as exc:  # pragma: no cover - best effort only
            return {"status": "error", "reason": str(exc)}

    def _run_tcpdump_capture(self, ip: str, duration: int) -> Dict[str, Any]:
        timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
        output_path = self.artifact_path / f"tcpdump_{ip.replace('.', '_')}_{timestamp}.pcap"
        cmd = [
            "tcpdump",
            "-nn",
            f"host {ip}",
            "-w",
            str(output_path),
        ]
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            time.sleep(max(1, duration))
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
            return {"status": "captured", "path": str(output_path)}
        except Exception as exc:  # pragma: no cover
            return {"status": "error", "reason": str(exc)}

    # ------------------------------------------------------------------
    # Endpoint integrity checks
    # ------------------------------------------------------------------
    def _verify_endpoint_integrity(self, window_start: datetime) -> Dict[str, Any]:
        dns_status = self._check_dns_settings()
        hosts_status = self._check_hosts_file()
        cert_status = self._check_certificate_store()
        cred_events = self._collect_credential_events(window_start)
        return {
            "dns": dns_status,
            "hosts_file": hosts_status,
            "certificates": cert_status,
            "credential_events": cred_events,
        }

    def _check_dns_settings(self) -> Dict[str, Any]:
        servers = self._get_dns_servers()
        allowed = set(self.config.get("trusted_dns_servers", []))
        unexpected = [srv for srv in servers if allowed and srv not in allowed]
        status = "clean" if not unexpected else "mismatch"
        return {"status": status, "servers": servers, "unexpected": unexpected}

    def _get_dns_servers(self) -> List[str]:
        servers: List[str] = []
        if platform.system() == "Windows":
            try:
                result = subprocess.run(
                    ["ipconfig", "/all"], capture_output=True, text=True, timeout=10
                )
            except Exception:
                return servers
            pending = None
            for line in result.stdout.splitlines():
                if "DNS Servers" in line:
                    _, value = line.split(":", 1)
                    pending = value.strip()
                    if pending:
                        servers.append(pending)
                elif line.startswith(" ") and pending is not None:
                    value = line.strip()
                    if value:
                        servers.append(value)
                else:
                    pending = None
            return [srv for srv in servers if srv]
        resolv_path = Path("/etc/resolv.conf")
        if resolv_path.exists():
            for line in resolv_path.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip()
                if line.startswith("nameserver"):
                    _, value = line.split()
                    servers.append(value)
        return servers

    def _check_hosts_file(self) -> Dict[str, Any]:
        hosts_paths = [
            Path(os.environ.get("SystemRoot", r"C:\\Windows")) / "System32" / "drivers" / "etc" / "hosts",
            Path("/etc/hosts"),
        ]
        findings: List[str] = []
        for path in hosts_paths:
            if not path.exists():
                continue
            try:
                content = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for line in content.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if any(token.lower() in line.lower() for token in self.config["sensitive_domains"]):
                    findings.append(f"{path}: {line}")
        return {"status": "alert" if findings else "clean", "findings": findings}

    def _check_certificate_store(self) -> Dict[str, Any]:
        if platform.system() != "Windows" or not shutil.which("certutil"):
            return {"status": "skipped", "reason": "certutil unavailable"}
        baseline_path = self.runtime_path / "cert_baseline.json"
        try:
            result = subprocess.run(
                ["certutil", "-store", "root"],
                capture_output=True,
                text=True,
                timeout=25,
            )
        except Exception as exc:  # pragma: no cover
            return {"status": "error", "reason": str(exc)}
        digest = hashlib.sha256(result.stdout.encode("utf-8", errors="ignore")).hexdigest()
        status = "clean"
        if not baseline_path.exists():
            baseline_path.write_text(json.dumps({"captured_at": datetime.utcnow().isoformat(), "hash": digest}, indent=2))
            status = "baseline_created"
        else:
            try:
                baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
                if baseline.get("hash") != digest:
                    status = "changed"
            except json.JSONDecodeError:
                status = "baseline_corrupt"
        return {"status": status, "hash": digest, "baseline": str(baseline_path)}

    def _collect_credential_events(self, window_start: datetime) -> Dict[str, Any]:
        if not (WINDOWS_EVENT_LOG_AVAILABLE and win32evtlog):
            return {"status": "skipped", "reason": "win32evtlog unavailable"}
        events: List[Dict[str, Any]] = []
        try:
            hand = win32evtlog.OpenEventLog(None, "Security")  # type: ignore[arg-type]
            flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
            while True:
                batch = win32evtlog.ReadEventLog(hand, flags, 0)
                if not batch:
                    break
                for event in batch:
                    if event.EventID not in {4648, 4624, 4625}:
                        continue
                    if event.TimeGenerated < window_start:
                        win32evtlog.CloseEventLog(hand)
                        return {"status": "ok", "events": events}
                    payload = " ".join(event.StringInserts or [])
                    events.append(
                        {
                            "event_id": event.EventID,
                            "time": event.TimeGenerated.isoformat(),
                            "data": payload[:200],
                        }
                    )
                    if len(events) >= 25:
                        win32evtlog.CloseEventLog(hand)
                        return {"status": "ok", "events": events}
            win32evtlog.CloseEventLog(hand)
        except Exception as exc:  # pragma: no cover
            return {"status": "error", "reason": str(exc)}
        return {"status": "ok", "events": events}
