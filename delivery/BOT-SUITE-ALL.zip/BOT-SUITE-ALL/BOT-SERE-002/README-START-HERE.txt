SERE Desktop Security Suite (BOT-SERE-002)
==================================
Mythara Labs LLC

What this is
------------
SERE is a desktop security suite for a single Windows machine. It watches
processes, files, and network connections in real time, scores what it sees
against bundled threat signatures and heuristics, quarantines what crosses
the line, and writes every event to a local record you keep. It includes a
desktop console, an incident playbook, Windows firewall control, and a
local AI assistant that can use Ollama on your own machine.

SERE is defensive software. It detects, contains, profiles, and logs. Its
countermeasure functions are locked to sandbox and simulation use and
cannot be fired at live targets from this package.

How to run it
-------------
Option 1: double-click Run_SERE_Security.bat
Option 2: from this folder, run:

    python sere_bot.py

Run it as Administrator if you want the firewall and quarantine actions
available; without elevation it still monitors and reports.

Requirements
------------
Windows 10 or 11. Python 3.11 or newer. Two third-party packages:

    pip install psutil requests

Optional: Ollama installed locally enables the AI assistant features.
Without it, SERE runs in its standard mode.

Notes
-----
SERE works offline. Signatures are bundled, events are stored locally in
SQLite, and the only optional outbound call is an IP geolocation lookup
you can ignore. It is a single-machine suite: it does not manage fleets,
and it is not a replacement for a full incident response process.

Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.
