@echo off
powershell -ExecutionPolicy Bypass -File "C:\Users\Mythara\Desktop\Clone Repo Mythara\Mythara_Archive\Run_SERE_Security.ps1"
pause
