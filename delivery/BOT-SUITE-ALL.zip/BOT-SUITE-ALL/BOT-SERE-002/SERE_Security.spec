# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['C:\\Users\\Mythara\\Desktop\\Clone Repo Mythara\\Mythara_Archive\\sere_bot.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=['sere_bot_clean', 'sere_bot_full', 'sere_security_engine', 'psutil', 'sqlite3', 'tkinter'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='SERE_Security',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='SERE_Security',
)
