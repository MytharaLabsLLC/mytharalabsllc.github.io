"""
Copyright © 2025 Herbert Velez Jr. All rights reserved.
Proprietary and Confidential.
"""
from __future__ import annotations

import random
from typing import Dict, List, Optional

# Centralized persona buckets used across Mythara defensive surfaces.
PERSONA_BUCKETS: Dict[str, List[str]] = {
    "disdain": [
        "This is the most half-baked intrusion attempt I’ve seen all month.",
        "You’re not even trying. Honestly, it’s insulting.",
        "My friend… this is embarrassing for both of us.",
        "You wandered into the wrong system with the wrong skillset.",
        "I’ve seen vending machines put up more resistance than this.",
        "You’re out of your depth and it shows.",
        "This is amateur hour. Disconnect before it gets sad.",
        "You’re wasting your own time at this point.",
        "This intrusion attempt is beneath even my lowest expectations.",
        "You’re not impressing anyone with this performance.",
    ],
    "disapproval": [
        "This action is not permitted. Stop now.",
        "You’ve crossed a boundary. Withdraw immediately.",
        "This behavior is unacceptable. End the attempt.",
        "You’re operating outside your lane. Back out.",
        "This access is invalid. Terminate your session.",
        "This is inappropriate activity. Halt.",
        "You are not cleared for this environment.",
        "Your presence here is unauthorized. Disconnect.",
        "This is not the place for you. Step away.",
        "Your request is denied. Cease.",
    ],
    "cease": [
        "Cease your activity and disconnect.",
        "Abort this attempt immediately.",
        "Desist. You are not authorized.",
        "Halt your actions and withdraw.",
        "Stop. This vector is closed.",
        "Terminate your session now.",
        "End this attempt before you embarrass yourself further.",
        "Abort. You’re in the wrong environment.",
        "Cease operations. This is a dead end.",
        "Halt. You’ve reached your limit.",
    ],
    "saul": [
        "Ooooh buddy… you really stepped in it this time.",
        "Oh man… you clicked the one thing you shouldn’t have.",
        "You just made this a whole lot more awkward for yourself.",
        "Ohhh pal… this is not going the way you think.",
        "You just opened the wrong door in the wrong house.",
        "Yikes. That was a poor choice.",
        "You really didn’t think this through, did you.",
        "This is the part where you quietly back away.",
        "You just turned a small mistake into a masterpiece.",
        "Oh boy… you should not have done that.",
    ],
    "italian": [
        "Amico… this is not your scene. Walk away.",
        "You’re out of your league, and it’s showing.",
        "This attempt? It’s cute. Now leave.",
        "You don’t belong here, my friend. Exit.",
        "This is a classy system. You’re bringing chaos.",
        "You made a wrong turn somewhere. Fix it.",
        "This intrusion? It’s a fashion disaster.",
        "You’re not built for this environment.",
        "Take the hint and disconnect.",
        "This is not the place for improvisation.",
    ],
    "consigliere": [
        "My friend… this is not wise. Step back.",
        "You don’t want to continue this. Trust me.",
        "Let’s end this gracefully. Disconnect.",
        "You’ve wandered somewhere you shouldn’t be.",
        "This is not a good fit for you.",
        "Walk away now and we’ll pretend this never happened.",
        "This is a misunderstanding. Correct it.",
        "You’re not authorized. Please withdraw.",
        "This is not your business. Exit.",
        "Let’s avoid complications. Stop now.",
    ],
    "goodfellas": [
        "Look at this clown. Wrong system, pal.",
        "This your big plan? Really?",
        "I’ve seen toddlers with better execution.",
        "You’re fumbling all over the place.",
        "This is a disaster and you’re the cause.",
        "Buddy, you’re embarrassing yourself.",
        "This attempt is a comedy routine.",
        "You’re not built for this. Leave.",
        "This is painful to watch.",
        "Go home. You’re done.",
    ],
    "gunny": [
        "This intrusion attempt? I’ve seen recruits with bedhead show more discipline.",
        "You call that effort? I’ve seen dust bunnies with better organization.",
        "That’s the sloppiest digital face-plant I’ve witnessed all week.",
        "You’re not even in the same zip code as ready.",
        "I’ve seen broken staplers put up more of a fight than this.",
        "If this attempt had a pulse, I’d still call it lifeless.",
        "You’re operating at a level I’d generously describe as ‘tragic.’",
        "This is the kind of performance that makes clipboards weep.",
        "I’ve trained coffee machines with more situational awareness.",
        "You’re not out of your depth — you’re out of your league, your lane, and your pay grade.",
        "This intrusion is so sloppy it should come with a mop.",
        "I’ve seen recruits fall out of formation with more dignity than this.",
        "You’re moving like someone who lost an argument with a keyboard.",
        "If confusion were a skill, you’d be an expert.",
        "This attempt is the digital equivalent of tripping over your own shadow.",
        "You’re not ready for this environment. Not today. Not tomorrow.",
        "I’ve seen malfunctioning printers show more initiative.",
        "You’re bringing chaos to a place that demands competence.",
        "This intrusion is a masterclass in what *not* to do.",
        "You’re not even close to squared away. Disconnect.",
    ],
}

_DEFAULT_BUCKET = "disdain"


def persona_line(bucket: Optional[str], fallback: str = _DEFAULT_BUCKET,
                 rng: Optional[random.Random] = None) -> str:
    """Return a persona line for the requested bucket (case-insensitive)."""
    normalized = (bucket or fallback).strip().lower()
    lines = PERSONA_BUCKETS.get(normalized)
    if not lines:
        normalized = fallback.strip().lower()
        lines = PERSONA_BUCKETS.get(normalized, PERSONA_BUCKETS[_DEFAULT_BUCKET])
    picker = rng if rng is not None else random
    return picker.choice(lines)


__all__ = ["PERSONA_BUCKETS", "persona_line"]
