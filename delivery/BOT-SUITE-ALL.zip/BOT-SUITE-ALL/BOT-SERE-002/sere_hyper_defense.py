"""
Copyright © 2025 Herbert Velez Jr. All rights reserved.
Proprietary and Confidential.
"""
from __future__ import annotations

import logging
import platform
import subprocess
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Optional, Sequence

try:
    import ipaddress
except ImportError:  # pragma: no cover - stdlib
    ipaddress = None

try:
    import requests
except ImportError:  # pragma: no cover - optional
    requests = None

try:
    import wmi  # type: ignore
except ImportError:  # pragma: no cover - optional
    wmi = None

try:
    import win32evtlog  # type: ignore
    WINDOWS_EVENT_LOG_AVAILABLE = True
except ImportError:  # pragma: no cover - optional
    WINDOWS_EVENT_LOG_AVAILABLE = False

LOG = logging.getLogger(__name__)

HYPER_CONFIG = {
    "ENABLE_CONTINUOUS_PING": True,
    "WINDOWS_EVENT_LOG_LOOKBACK_MINUTES": 5,
    "FAILED_LOGIN_THRESHOLD": 3,
    "WARN_TOR_CONNECTIONS": True,
    "ENABLE_DNS_MONITORING": True,
    "ENABLE_WMI_DETECTION": True,
    "ENABLE_EVENT_LOG_DETECTION": True,
    "ENABLE_REAL_DETECTION": True,
    "ENABLE_REAL_BLOCKING": True,
    "FIREWALL_RULE_PREFIX": "SERE_BLOCK_",
    "BLOCK_DURATION_SECONDS": 604800,
    "OBTUSE_DEFENSE_ENABLED": True,
    "OBTUSE_DEFENSE_DWELL_SECONDS": 45,
    "OBTUSE_DEFENSE_JITTER_MS": 1200,
    "OBTUSE_DEFENSE_DECAY_MINUTES": 12,
    "ENABLE_INTRUSION_NOTICE": True,
    "INTRUSION_NOTICE_STYLE": "gunny",
    "PING_INTERVAL": 30,
    "PING_TIMEOUT": 5,
    "MAX_CONCURRENT_PINGS": 10,
    "MAX_MONITORED_IPS": 200,
    "MAX_QUARANTINE_ZONES": 50,
    "MAX_THREAT_HISTORY_MB": 10,
    "SAFE_IP_ALLOWLIST": {
        "140.82.114.21",  # GitHub front-end, commonly contacted by development tooling
    },
}

INTRUSION_NOTICE_LIBRARY = {
    "gunny": (
        "ATTENTION: UNAUTHORIZED ACCESS.\n\n"
        "You are inside a secured system without clearance.\n"
        "Your session, headers, playback, and telemetry are recorded.\n\n"
        "You are now on an active incident board.\n"
        "Disconnect immediately and do not return."
    ),
    "dod": (
        "SECURITY NOTICE: UNAUTHORIZED ACCESS.\n\n"
        "Your connection has been identified and logged.\n"
        "This system does not permit unapproved activity.\n\n"
        "All session data is being captured for security review and may be forwarded to investigative authorities.\n"
        "Terminate your connection immediately."
    ),
    "forensic": (
        "UNAUTHORIZED ACCESS EVENT.\n\n"
        "This node is operating under continuous telemetry capture.\n"
        "Session identifiers, packet traces, and authentication attempts have been archived.\n\n"
        "Your activity is unauthorized and subject to escalation.\n"
        "Disconnect now."
    ),
}


class ThreatLevel(Enum):
    NONE = 0
    MINIMAL = 1
    MODERATE = 2
    SUBSTANTIAL = 3
    SEVERE = 4
    CRITICAL = 5


class AttackType(Enum):
    DDOS = "Distributed Denial of Service"
    SQL_INJECTION = "SQL Injection"
    XSS = "Cross-Site Scripting"
    BRUTE_FORCE = "Brute Force"
    MALWARE = "Malware Infection"
    PHISHING = "Phishing Attack"
    MITM = "Man-in-the-Middle"
    ZERO_DAY = "Zero-Day Exploit"
    RANSOMWARE = "Ransomware"
    DATA_BREACH = "Data Breach Attempt"
    SUSPICIOUS_OUTBOUND = "Suspicious Outbound Connection"
    TOR_USAGE = "Tor Network Usage"
    DATA_EXFILTRATION = "Potential Data Exfiltration"
    CALLBACK_THREAT = "Malware Callback Detected"


@dataclass
class GeoLocation:
    ip: str
    city: str = "Unknown"
    region: str = "Unknown"
    country: str = "Unknown"
    loc: str = "Unknown"
    org: str = "Unknown"
    postal: str = "Unknown"
    timezone: str = "Unknown"


@dataclass
class ThreatDetection:
    threat_id: str
    attack_type: AttackType
    severity: ThreatLevel
    source_ip: str
    timestamp: datetime
    indicators: List[str]
    recommended_action: str
    geolocation: Optional[GeoLocation] = None


@dataclass
class PingMonitor:
    monitor_id: str
    target_ip: str
    is_alive: bool
    last_ping_time: datetime
    response_time: float
    consecutive_failures: int
    total_pings: int
    successful_pings: int
    status: str = "active"


@dataclass
class QuarantineZone:
    quarantine_id: str
    threat_ip: str
    threat_type: str
    quarantine_start: datetime
    quarantine_duration: int
    status: str
    isolation_level: str
    notes: List[str] = field(default_factory=list)


def compose_intrusion_notice(style: str = "gunny", context: Optional[Dict[str, str]] = None) -> str:
    """Compose a lawful defensive notice using the requested style."""
    template = INTRUSION_NOTICE_LIBRARY.get(style.lower(), INTRUSION_NOTICE_LIBRARY["gunny"])
    message_lines = [template.strip()]
    if context:
        context_lines = [f" - {key}: {value}" for key, value in context.items() if value]
        if context_lines:
            message_lines.append("")
            message_lines.append("Context:")
            message_lines.extend(context_lines)
    return "\n".join(message_lines)


def issue_intrusion_notice(
    *, style: str = "gunny", context: Optional[Dict[str, str]] = None, logger: Optional[logging.Logger] = None
) -> str:
    """Compose and log a defensive intrusion notice, returning the rendered text."""
    rendered = compose_intrusion_notice(style, context)
    active_logger = logger or LOG
    active_logger.warning("Defensive notice dispatched (%s):\n%s", style.upper(), rendered)
    return rendered


def _safe_ip(ip: str) -> bool:
    if not ipaddress:
        return True
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return not (addr.is_private or addr.is_loopback or addr.is_multicast)


def lookup_geolocation(ip: str) -> Optional[GeoLocation]:
    if not requests or not _safe_ip(ip):
        return None
    try:
        response = requests.get(f"https://ip-api.com/json/{ip}", timeout=2)
        if response.status_code != 200:
            return None
        payload = response.json()
        if payload.get("status") != "success":
            return None
        return GeoLocation(
            ip=ip,
            city=payload.get("city", "Unknown"),
            region=payload.get("regionName", "Unknown"),
            country=payload.get("country", "Unknown"),
            loc=f"{payload.get('lat', '')},{payload.get('lon', '')}",
            org=payload.get("isp", "Unknown"),
            postal=payload.get("zip", "Unknown"),
            timezone=payload.get("timezone", "Unknown"),
        )
    except requests.RequestException:
        return None


class RealThreatDetector:
    def __init__(self, config: Optional[Dict[str, object]] = None):
        self.config = dict(HYPER_CONFIG)
        if config:
            self.config.update(config)
        self.failed_login_tracker: Dict[str, int] = {}
        self.last_event_scan = datetime.utcnow() - timedelta(
            minutes=self.config["WINDOWS_EVENT_LOG_LOOKBACK_MINUTES"]
        )

    def get_real_threats(self) -> List[ThreatDetection]:
        findings: List[ThreatDetection] = []
        findings.extend(self._detect_event_log())
        findings.extend(self._detect_network())
        if self.config.get("ENABLE_DNS_MONITORING", True):
            findings.extend(self._detect_dns())
        if self.config.get("ENABLE_WMI_DETECTION", True):
            findings.extend(self._detect_wmi_processes())
            findings.extend(self._detect_wmi_services())
        findings.extend(self._detect_outbound())
        self._emit_intrusion_notices(findings)
        return findings

    def _emit_intrusion_notices(self, findings: Sequence[ThreatDetection]) -> None:
        if not (findings and self.config.get("ENABLE_INTRUSION_NOTICE", False)):
            return
        style = str(self.config.get("INTRUSION_NOTICE_STYLE", "gunny"))
        for threat in findings:
            context = {
                "Threat ID": threat.threat_id,
                "Threat Type": threat.attack_type.value,
                "Severity": threat.severity.name,
                "Source": threat.source_ip,
            }
            if threat.geolocation and threat.geolocation.country != "Unknown":
                context["Geo"] = f"{threat.geolocation.city}, {threat.geolocation.country}".strip(", ")
            issue_intrusion_notice(style=style, context=context)

    # Event log -------------------------------------------------------------
    def _detect_event_log(self) -> List[ThreatDetection]:
        if not (WINDOWS_EVENT_LOG_AVAILABLE and self.config.get("ENABLE_EVENT_LOG_DETECTION", True)):
            return []
        threats: List[ThreatDetection] = []
        try:
            hand = win32evtlog.OpenEventLog(None, "Security")  # type: ignore[arg-type]
            flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
            events = win32evtlog.ReadEventLog(hand, flags, 0)
            max_events = 100
            count = 0
            for event in events:
                if count >= max_events:
                    break
                count += 1
                if event.EventID != 4625:
                    continue
                event_time = event.TimeGenerated
                if event_time < self.last_event_scan:
                    continue
                payload = " ".join(event.StringInserts or [])
                ip_match = self._extract_ip(payload)
                if not ip_match:
                    continue
                self.failed_login_tracker[ip_match] = self.failed_login_tracker.get(ip_match, 0) + 1
                if self.failed_login_tracker[ip_match] >= self.config["FAILED_LOGIN_THRESHOLD"]:
                    threats.append(
                        ThreatDetection(
                            threat_id=f"EVT_{int(time.time())}_{ip_match.replace('.', '_')}",
                            attack_type=AttackType.BRUTE_FORCE,
                            severity=ThreatLevel.SUBSTANTIAL,
                            source_ip=ip_match,
                            timestamp=event_time,
                            indicators=[
                                f"{self.failed_login_tracker[ip_match]} failed logins",
                                "Windows Event ID 4625",
                            ],
                            recommended_action="Enable account lockout and block the source IP",
                        )
                    )
                    self.failed_login_tracker[ip_match] = 0
            win32evtlog.CloseEventLog(hand)
            self.last_event_scan = datetime.utcnow()
        except Exception as exc:  # pragma: no cover - best effort
            LOG.debug("Event log scan failed: %s", exc)
        return threats

    # Network ---------------------------------------------------------------
    def _detect_network(self) -> List[ThreatDetection]:
        threats: List[ThreatDetection] = []
        try:
            result = subprocess.run(["netstat", "-ano"], capture_output=True, text=True, timeout=10)
        except Exception as exc:  # pragma: no cover
            LOG.debug("netstat failed: %s", exc)
            return threats
        suspicious_ports = {4444, 5555, 6666, 8888, 9999, 31337, 27374}
        tor_ports = {9050, 9051, 9150, 9151}
        for line in result.stdout.splitlines():
            parts = line.split()
            if len(parts) < 4 or parts[0] not in {"TCP", "UDP"}:
                continue
            remote_addr = parts[2]
            if ":" not in remote_addr:
                continue
            host, _, port_str = remote_addr.rpartition(":")
            try:
                remote_port = int(port_str)
            except ValueError:
                continue
            if host in {"0.0.0.0", "127.0.0.1"}:
                continue
            reason = None
            if remote_port in suspicious_ports:
                reason = f"Suspicious port {remote_port}"
            elif remote_port in tor_ports and self.config.get("WARN_TOR_CONNECTIONS", True):
                reason = f"Tor port {remote_port}"
            if reason:
                threats.append(
                    ThreatDetection(
                        threat_id=f"NET_{int(time.time())}_{remote_port}",
                        attack_type=AttackType.MITM,
                        severity=ThreatLevel.SUBSTANTIAL,
                        source_ip=host,
                        timestamp=datetime.utcnow(),
                        indicators=[reason, f"Remote {remote_addr}"],
                        recommended_action="Block the remote host and inspect the process",
                    )
                )
        return threats

    def _detect_dns(self) -> List[ThreatDetection]:
        threats: List[ThreatDetection] = []
        try:
            result = subprocess.run(["netstat", "-an"], capture_output=True, text=True, timeout=10)
        except Exception as exc:  # pragma: no cover
            LOG.debug("DNS netstat failed: %s", exc)
            return threats
        for line in result.stdout.splitlines():
            if ":53" not in line:
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            remote_addr = parts[2]
            host, _, _ = remote_addr.rpartition(":")
            if self._is_private(host):
                continue
            threats.append(
                ThreatDetection(
                    threat_id=f"DNS_{int(time.time())}",
                    attack_type=AttackType.MITM,
                    severity=ThreatLevel.MODERATE,
                    source_ip=host,
                    timestamp=datetime.utcnow(),
                    indicators=["External DNS resolution", remote_addr],
                    recommended_action="Verify DNS configuration and prefer trusted resolvers",
                )
            )
        return threats

    def _detect_outbound(self) -> List[ThreatDetection]:
        threats: List[ThreatDetection] = []
        try:
            result = subprocess.run(["netstat", "-ano"], capture_output=True, text=True, timeout=10)
        except Exception as exc:  # pragma: no cover
            LOG.debug("Outbound netstat failed: %s", exc)
            return threats
        for line in result.stdout.splitlines():
            if "ESTABLISHED" not in line:
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            remote_addr = parts[2]
            host, _, port_str = remote_addr.rpartition(":")
            if self._is_private(host):
                continue
            try:
                remote_port = int(port_str)
            except ValueError:
                continue
            if remote_port in {9050, 9051, 9150, 9151}:
                attack = AttackType.TOR_USAGE
                severity = ThreatLevel.MINIMAL
                indicators = [f"Tor proxy port {remote_port}"]
            else:
                attack = AttackType.SUSPICIOUS_OUTBOUND
                severity = ThreatLevel.MODERATE
                indicators = [f"High risk outbound to {remote_addr}"]
            threats.append(
                ThreatDetection(
                    threat_id=f"OUT_{int(time.time())}_{remote_port}",
                    attack_type=attack,
                    severity=severity,
                    source_ip=host,
                    timestamp=datetime.utcnow(),
                    indicators=indicators,
                    recommended_action="Inspect outbound connection and confirm legitimacy",
                )
            )
        return threats

    def _detect_wmi_processes(self) -> List[ThreatDetection]:
        if not wmi or not self.config.get("ENABLE_WMI_DETECTION", True):
            return []
        threats: List[ThreatDetection] = []
        suspicious_keywords = [
            "mimikatz",
            "psexec",
            "metasploit",
            "backdoor",
            "ransomware",
            "trojan",
            "worm",
            "virus",
            "powershell -enc",
            "wget",
            "curl",
            "shellcode",
            "exploit",
        ]
        try:
            client = wmi.WMI()
            for idx, proc in enumerate(client.Win32_Process()):
                if idx >= 500:
                    break
                cmd_line = (proc.CommandLine or "").lower()
                name = (proc.Name or "").lower()
                if any(keyword in cmd_line or keyword in name for keyword in suspicious_keywords):
                    threats.append(
                        ThreatDetection(
                            threat_id=f"PROC_{proc.ProcessId}_{int(time.time())}",
                            attack_type=AttackType.MALWARE,
                            severity=ThreatLevel.SEVERE,
                            source_ip="LOCAL",
                            timestamp=datetime.utcnow(),
                            indicators=[name, cmd_line[:200]],
                            recommended_action=f"Terminate PID {proc.ProcessId} and investigate",
                        )
                    )
        except Exception as exc:  # pragma: no cover
            LOG.debug("WMI process scan failed: %s", exc)
        return threats

    def _detect_wmi_services(self) -> List[ThreatDetection]:
        if not wmi or not self.config.get("ENABLE_WMI_DETECTION", True):
            return []
        threats: List[ThreatDetection] = []
        suspicious_paths = ["\\temp\\", "\\appdata\\", "%temp%", "c:\\windows\\temp"]
        try:
            client = wmi.WMI()
            for idx, svc in enumerate(client.Win32_Service()):
                if idx >= 500:
                    break
                path = (svc.PathName or "").lower()
                if any(marker in path for marker in suspicious_paths):
                    threats.append(
                        ThreatDetection(
                            threat_id=f"SVC_{svc.Name}_{int(time.time())}",
                            attack_type=AttackType.MALWARE,
                            severity=ThreatLevel.SUBSTANTIAL,
                            source_ip="LOCAL",
                            timestamp=datetime.utcnow(),
                            indicators=[svc.Name, path[:160]],
                            recommended_action=f"Disable service {svc.Name} and inspect binary",
                        )
                    )
        except Exception as exc:  # pragma: no cover
            LOG.debug("WMI service scan failed: %s", exc)
        return threats

    @staticmethod
    def _extract_ip(payload: str) -> Optional[str]:
        parts = payload.split()
        for token in parts:
            if token.count(".") == 3 and all(seg.isdigit() for seg in token.split(".")):
                return token
        return None

    @staticmethod
    def _is_private(host: str) -> bool:
        if not ipaddress:
            return host.startswith("192.168")
        try:
            addr = ipaddress.ip_address(host)
        except ValueError:
            return True
        return addr.is_private or addr.is_loopback


class WindowsFirewallController:
    def __init__(self):
        self.blocked_ips: Dict[str, str] = {}

    def block(self, ip: str, rule_prefix: str = "SERE_BLOCK") -> bool:
        if platform.system().lower() != "windows":
            LOG.info("Firewall block simulated for %s", ip)
            return True
        if not _safe_ip(ip):
            return False
        rule_name = f"{rule_prefix}_{ip.replace('.', '_')}"
        cmd = [
            "netsh",
            "advfirewall",
            "firewall",
            "add",
            "rule",
            f"name={rule_name}",
            "dir=in",
            "action=block",
            f"remoteip={ip}",
            "enable=yes",
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=6)
            if result.returncode == 0:
                self.blocked_ips[ip] = rule_name
                return True
            stderr = (result.stderr or "").strip()
            lowered = stderr.lower()
            if any(phrase in lowered for phrase in ("requires elevation", "access is denied")):
                LOG.warning("Firewall block requires elevated privileges for %s; recording simulated block", ip)
                self.blocked_ips[ip] = f"{rule_name}_SIM"
                return True
            LOG.warning("Firewall block failed for %s: %s", ip, stderr or "unknown error")
        except Exception as exc:  # pragma: no cover
            LOG.error("Firewall command failed: %s", exc)
        return False

    def unblock(self, ip: str) -> bool:
        rule_name = self.blocked_ips.get(ip)
        if not rule_name:
            return True
        cmd = ["netsh", "advfirewall", "firewall", "delete", "rule", f"name={rule_name}"]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=6)
            if result.returncode == 0:
                self.blocked_ips.pop(ip, None)
                return True
            LOG.warning("Firewall unblock failed for %s: %s", ip, result.stderr.strip())
        except Exception as exc:  # pragma: no cover
            LOG.error("Firewall unblock failed: %s", exc)
        return False


class QuarantineManager:
    def __init__(self, firewall: WindowsFirewallController, config: Optional[Dict[str, object]] = None):
        self.firewall = firewall
        self.config = dict(HYPER_CONFIG)
        if config:
            self.config.update(config)
        self.zones: Dict[str, QuarantineZone] = {}
        self.lock = threading.Lock()

    def quarantine(self, ip: str, threat_type: str, duration: int = 3600, isolation_level: str = "high") -> bool:
        if not _safe_ip(ip):
            return False
        allowlist = set(self.config.get("SAFE_IP_ALLOWLIST", []) or [])
        if ip in allowlist:
            LOG.info("Quarantine skipped for allowlisted IP %s (%s)", ip, threat_type)
            return False
        with self.lock:
            if len(self.zones) >= self.config["MAX_QUARANTINE_ZONES"]:
                LOG.warning("Quarantine limit reached")
                return False
            if ip in self.zones:
                return True
            zone = QuarantineZone(
                quarantine_id=f"QUAR_{int(time.time())}_{ip.replace('.', '_')}",
                threat_ip=ip,
                threat_type=threat_type,
                quarantine_start=datetime.utcnow(),
                quarantine_duration=duration,
                status="active",
                isolation_level=isolation_level,
            )
            self.zones[ip] = zone
        blocked = self.firewall.block(ip)
        if not blocked:
            LOG.warning("Firewall block skipped for %s", ip)
        if self.config.get("ENABLE_INTRUSION_NOTICE", False):
            notice = issue_intrusion_notice(
                style=str(self.config.get("INTRUSION_NOTICE_STYLE", "gunny")),
                context={
                    "Threat IP": ip,
                    "Threat Type": threat_type,
                    "Isolation Level": isolation_level,
                    "Quarantine ID": zone.quarantine_id,
                },
            )
            zone.notes.append(f"Notice issued at {datetime.utcnow().isoformat()}Z")
            zone.notes.append(notice)
        return True

    def release(self, ip: str) -> bool:
        with self.lock:
            zone = self.zones.pop(ip, None)
        if not zone:
            return False
        self.firewall.unblock(ip)
        return True

    def snapshot(self) -> List[QuarantineZone]:
        with self.lock:
            return list(self.zones.values())


class PingDefenseManager:
    def __init__(self, config: Optional[Dict[str, object]] = None):
        self.config = dict(HYPER_CONFIG)
        if config:
            self.config.update(config)
        self.monitors: Dict[str, PingMonitor] = {}
        self._lock = threading.Lock()
        self._task: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def track(self, ip: str) -> None:
        if not _safe_ip(ip):
            return
        with self._lock:
            if ip in self.monitors:
                return
            monitor = PingMonitor(
                monitor_id=f"PING_{int(time.time())}_{ip.replace('.', '_')}",
                target_ip=ip,
                is_alive=True,
                last_ping_time=datetime.utcnow(),
                response_time=0.0,
                consecutive_failures=0,
                total_pings=0,
                successful_pings=0,
            )
            self.monitors[ip] = monitor
        self._ensure_thread()

    def untrack(self, ip: str) -> None:
        with self._lock:
            self.monitors.pop(ip, None)
        if not self.monitors:
            self._stop_event.set()

    def _ensure_thread(self) -> None:
        if self._task and self._task.is_alive():
            return
        self._stop_event.clear()
        self._task = threading.Thread(target=self._loop, daemon=True)
        self._task.start()

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            with self._lock:
                targets = list(self.monitors.values())
            if not targets:
                break
            for monitor in targets:
                self._ping_once(monitor)
            self._stop_event.wait(timeout=self.config["PING_INTERVAL"])

    def _ping_once(self, monitor: PingMonitor) -> None:
        cmd = self._ping_command(monitor.target_ip)
        try:
            start = time.time()
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=self.config["PING_TIMEOUT"])
            elapsed = (time.time() - start) * 1000
            success = result.returncode == 0
        except Exception:
            elapsed = 0.0
            success = False
        monitor.last_ping_time = datetime.utcnow()
        monitor.total_pings += 1
        monitor.is_alive = success
        if success:
            monitor.response_time = elapsed
            monitor.successful_pings += 1
            monitor.consecutive_failures = 0
            monitor.status = "alive"
        else:
            monitor.consecutive_failures += 1
            monitor.status = "unreachable"

    @staticmethod
    def _ping_command(ip: str) -> Sequence[str]:
        if platform.system().lower() == "windows":
            return ["ping", "-n", "1", ip]
        return ["ping", "-c", "1", ip]

    def status(self) -> List[PingMonitor]:
        with self._lock:
            return list(self.monitors.values())


class SystemRepairManager:
    def run_repair(self) -> Dict[str, str]:
        if platform.system().lower() == "windows":
            commands = [
                ["sfc", "/scannow"],
                ["DISM", "/Online", "/Cleanup-Image", "/ScanHealth"],
            ]
        else:
            commands = [["/usr/bin/true"]]
        results: Dict[str, str] = {}
        for cmd in commands:
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
                key = " ".join(cmd)
                if result.returncode == 0:
                    results[key] = result.stdout.strip() or "Completed"
                else:
                    results[key] = result.stderr.strip() or f"Failed with code {result.returncode}"
            except Exception as exc:  # pragma: no cover
                results[" ".join(cmd)] = f"Error: {exc}"
        return results


__all__ = [
    "HYPER_CONFIG",
    "ThreatLevel",
    "AttackType",
    "GeoLocation",
    "ThreatDetection",
    "PingMonitor",
    "QuarantineZone",
    "RealThreatDetector",
    "WindowsFirewallController",
    "QuarantineManager",
    "PingDefenseManager",
    "SystemRepairManager",
    "lookup_geolocation",
    "compose_intrusion_notice",
    "issue_intrusion_notice",
    "INTRUSION_NOTICE_LIBRARY",
]
