#!/usr/bin/env python3
"""
S.E.R.E. Security Engine - Enterprise Cybersecurity Platform
Compete with McAfee, Norton, and Bitdefender

Copyright © 2025 Herbert Velez Jr. All rights reserved.
Proprietary and Confidential.

Features:
- Real-time threat detection and protection
- Firewall management
- Network traffic monitoring
- Malware/virus scanning
- Ransomware protection
- Web protection / safe browsing
- Identity & privacy protection
- System optimization
- Scheduled scans
- Quarantine management
- Automatic updates
- Detailed logging and reports
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import platform
import psutil
import random
import re
import socket
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from pathlib import Path
from typing import List, Dict, Any, Optional, Callable, Set, Protocol
from collections import defaultdict
import uuid

logger = logging.getLogger("sere_engine")

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION & CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

VERSION = "2.0.0"
PRODUCT_NAME = "S.E.R.E. Security Suite"
VENDOR = "Mythara Engine"

# Threat database signatures (simulated - in production, this would be a large DB)
DEFAULT_KNOWN_MALWARE_HASHES = {
    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855": "Empty.File.Suspicious",
    "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3": "Test.Malware.Generic",
}

# Suspicious file extensions
DANGEROUS_EXTENSIONS = {
    ".exe", ".scr", ".bat", ".cmd", ".vbs", ".js", ".jse", ".wsf", ".wsh",
    ".msi", ".msp", ".com", ".pif", ".gadget", ".jar", ".ps1", ".psm1"
}

# Suspicious process names
DEFAULT_SUSPICIOUS_PROCESSES = {
    "mimikatz", "lazagne", "procdump", "pwdump", "wce", "gsecdump",
    "nc.exe", "ncat", "netcat", "psexec", "paexec", "crackmapexec"
}

# Known malicious domains (sample)
DEFAULT_MALICIOUS_DOMAINS = {
    "malware-domain.com", "phishing-site.net", "cryptominer.io",
    "ransomware-c2.ru", "botnet-controller.cn"
}

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS & DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class ThreatCategory(Enum):
    VIRUS = "Virus"
    MALWARE = "Malware"
    TROJAN = "Trojan"
    RANSOMWARE = "Ransomware"
    SPYWARE = "Spyware"
    ADWARE = "Adware"
    ROOTKIT = "Rootkit"
    WORM = "Worm"
    PUP = "Potentially Unwanted Program"
    PHISHING = "Phishing"
    EXPLOIT = "Exploit"
    CRYPTOMINER = "Cryptominer"
    BOTNET = "Botnet"
    DDOS = "DDoS Attack"
    BRUTE_FORCE = "Brute Force"
    DATA_EXFIL = "Data Exfiltration"
    MITM = "Man-in-the-Middle"
    ZERO_DAY = "Zero-Day Threat"
    APT = "Advanced Persistent Threat"
    NETWORK_INTRUSION = "Network Intrusion"


class ThreatSeverity(Enum):
    INFO = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4
    EMERGENCY = 5


class ProtectionStatus(Enum):
    DISABLED = "Disabled"
    PASSIVE = "Passive Monitoring"
    ACTIVE = "Active Protection"
    AGGRESSIVE = "Aggressive Mode"
    LOCKDOWN = "Full Lockdown"


class ScanType(Enum):
    QUICK = "Quick Scan"
    FULL = "Full System Scan"
    CUSTOM = "Custom Scan"
    MEMORY = "Memory Scan"
    BOOT = "Boot-Time Scan"
    NETWORK = "Network Scan"
    ROOTKIT = "Rootkit Scan"
    VULNERABILITY = "Vulnerability Scan"


class FirewallRule(Enum):
    ALLOW = "Allow"
    BLOCK = "Block"
    ASK = "Ask User"
    LOG = "Log Only"


@dataclass
class ThreatSignature:
    """Threat signature definition."""
    sig_id: str
    name: str
    category: ThreatCategory
    severity: ThreatSeverity
    description: str
    hash_patterns: List[str] = field(default_factory=list)
    yara_rules: List[str] = field(default_factory=list)
    behavior_patterns: List[str] = field(default_factory=list)
    created: datetime = field(default_factory=datetime.utcnow)
    last_seen: Optional[datetime] = None


@dataclass
class DetectedThreat:
    """Detected threat instance."""
    threat_id: str
    signature: Optional[ThreatSignature]
    category: ThreatCategory
    severity: ThreatSeverity
    source: str
    location: str
    file_hash: Optional[str] = None
    process_id: Optional[int] = None
    network_info: Optional[Dict[str, Any]] = None
    detection_time: datetime = field(default_factory=datetime.utcnow)
    status: str = "detected"
    action_taken: Optional[str] = None
    confidence: float = 0.95
    indicators: List[str] = field(default_factory=list)
    raw_data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class QuarantineItem:
    """Quarantined item."""
    item_id: str
    original_path: str
    quarantine_path: str
    threat: DetectedThreat
    quarantine_time: datetime = field(default_factory=datetime.utcnow)
    can_restore: bool = True
    encrypted: bool = True


@dataclass
class NetworkConnection:
    """Active network connection."""
    local_addr: str
    local_port: int
    remote_addr: str
    remote_port: int
    protocol: str
    status: str
    process_name: str
    process_id: int
    risk_level: ThreatSeverity = ThreatSeverity.INFO


@dataclass 
class ScanResult:
    """Scan result summary."""
    scan_id: str
    scan_type: ScanType
    start_time: datetime
    end_time: Optional[datetime] = None
    files_scanned: int = 0
    threats_found: int = 0
    threats_cleaned: int = 0
    threats_quarantined: int = 0
    errors: int = 0
    status: str = "running"
    detected_threats: List[DetectedThreat] = field(default_factory=list)


@dataclass
class SystemHealth:
    """System health metrics."""
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    network_activity: float
    active_threats: int
    quarantined_items: int
    last_scan: Optional[datetime]
    protection_status: ProtectionStatus
    firewall_enabled: bool
    real_time_protection: bool
    definitions_version: str
    definitions_date: datetime
    overall_score: int  # 0-100


@dataclass
class ThreatIntelBundle:
    """Provider-supplied threat intelligence bundle."""
    version: str
    malware_hashes: Dict[str, str] = field(default_factory=dict)
    suspicious_processes: Set[str] = field(default_factory=set)
    malicious_domains: Set[str] = field(default_factory=set)
    signatures: List[ThreatSignature] = field(default_factory=list)


class ThreatIntelProvider(Protocol):
    """Source for threat intelligence data loaded by the engine."""

    def load_bundle(self) -> ThreatIntelBundle:
        ...


def _default_signatures() -> List[ThreatSignature]:
    return [
        ThreatSignature(
            sig_id="SIG-001",
            name="Generic.Trojan.Agent",
            category=ThreatCategory.TROJAN,
            severity=ThreatSeverity.HIGH,
            description="Generic trojan agent detection"
        ),
        ThreatSignature(
            sig_id="SIG-002",
            name="Ransom.WannaCry",
            category=ThreatCategory.RANSOMWARE,
            severity=ThreatSeverity.CRITICAL,
            description="WannaCry ransomware variant"
        ),
        ThreatSignature(
            sig_id="SIG-003",
            name="Cryptominer.Generic",
            category=ThreatCategory.CRYPTOMINER,
            severity=ThreatSeverity.MEDIUM,
            description="Cryptocurrency mining malware"
        ),
    ]


class StaticThreatIntelProvider:
    """Default in-memory threat intelligence provider."""

    def __init__(self, bundle: Optional[ThreatIntelBundle] = None):
        self.bundle = bundle or ThreatIntelBundle(
            version="2026.01.28.001",
            malware_hashes=dict(DEFAULT_KNOWN_MALWARE_HASHES),
            suspicious_processes=set(DEFAULT_SUSPICIOUS_PROCESSES),
            malicious_domains=set(DEFAULT_MALICIOUS_DOMAINS),
            signatures=_default_signatures(),
        )

    def load_bundle(self) -> ThreatIntelBundle:
        return ThreatIntelBundle(
            version=self.bundle.version,
            malware_hashes=dict(self.bundle.malware_hashes),
            suspicious_processes=set(self.bundle.suspicious_processes),
            malicious_domains=set(self.bundle.malicious_domains),
            signatures=list(self.bundle.signatures),
        )


class JSONThreatIntelProvider:
    """Load threat intelligence from JSON, with fallback to another provider."""

    def __init__(self, intel_path: Path, fallback: Optional[ThreatIntelProvider] = None):
        self.intel_path = intel_path
        self.fallback = fallback or StaticThreatIntelProvider()

    def load_bundle(self) -> ThreatIntelBundle:
        if not self.intel_path.exists():
            return self.fallback.load_bundle()

        try:
            data = json.loads(self.intel_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning(f"Failed to load threat intel from {self.intel_path}: {exc}")
            return self.fallback.load_bundle()

        try:
            signatures = [self._parse_signature(item) for item in data.get("signatures", [])]
            return ThreatIntelBundle(
                version=data.get("version") or datetime.utcnow().strftime("%Y.%m.%d.%H%M"),
                malware_hashes={k.lower(): v for k, v in data.get("malware_hashes", {}).items()},
                suspicious_processes={item.lower() for item in data.get("suspicious_processes", [])},
                malicious_domains={item.lower() for item in data.get("malicious_domains", [])},
                signatures=signatures,
            )
        except (KeyError, ValueError, TypeError) as exc:
            logger.warning(f"Threat intel schema invalid in {self.intel_path}: {exc}")
            return self.fallback.load_bundle()

    def _parse_signature(self, item: Dict[str, Any]) -> ThreatSignature:
        return ThreatSignature(
            sig_id=item["sig_id"],
            name=item["name"],
            category=ThreatCategory[item["category"]],
            severity=ThreatSeverity[item["severity"]],
            description=item["description"],
            hash_patterns=list(item.get("hash_patterns", [])),
            yara_rules=list(item.get("yara_rules", [])),
            behavior_patterns=list(item.get("behavior_patterns", [])),
        )


# ═══════════════════════════════════════════════════════════════════════════════
# CORE SECURITY ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class SERESecurityEngine:
    """
    S.E.R.E. Security Engine - Enterprise-Grade Cybersecurity Platform
    
    Competes with McAfee, Norton, Bitdefender with:
    - Real-time protection
    - Behavioral analysis
    - Network monitoring
    - Firewall management
    - Web protection
    - Identity shield
    """
    
    def __init__(self, data_dir: Optional[Path] = None,
                 intel_provider: Optional[ThreatIntelProvider] = None):
        self.version = VERSION
        self.product_name = PRODUCT_NAME
        
        # Data directories
        self.data_dir = data_dir or Path.home() / ".sere_security"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.quarantine_dir = self.data_dir / "quarantine"
        self.quarantine_dir.mkdir(exist_ok=True)
        self.logs_dir = self.data_dir / "logs"
        self.logs_dir.mkdir(exist_ok=True)
        self.db_path = self.data_dir / "sere_security.db"
        self.intel_provider = intel_provider or JSONThreatIntelProvider(
            self.data_dir / "threat_intel.json"
        )
        
        # State
        self.protection_status = ProtectionStatus.ACTIVE
        self.real_time_protection = True
        self.firewall_enabled = True
        self.web_protection = True
        self.ransomware_protection = True
        self.network_monitoring = True
        
        # Threat tracking
        self.detected_threats: List[DetectedThreat] = []
        self.quarantine: Dict[str, QuarantineItem] = {}
        self.blocked_ips: Set[str] = set()
        self.blocked_domains: Set[str] = set()
        self.trusted_apps: Set[str] = set()
        self.known_malware_hashes: Dict[str, str] = {}
        self.suspicious_processes: Set[str] = set()
        
        # Scanning
        self.current_scan: Optional[ScanResult] = None
        self.scan_history: List[ScanResult] = []
        self._scan_thread: Optional[threading.Thread] = None
        self._scan_stop_event = threading.Event()
        self._monitor_thread: Optional[threading.Thread] = None
        self._monitor_stop_event = threading.Event()
        self.monitor_interval = 5.0
        
        # Network connections cache
        self.active_connections: List[NetworkConnection] = []
        
        # Definitions
        self.definitions_version = "2026.01.28.001"
        self.definitions_date = datetime.now()
        self.threat_signatures: Dict[str, ThreatSignature] = {}
        
        # Statistics
        self.stats = {
            "threats_blocked": 0,
            "scans_completed": 0,
            "files_scanned": 0,
            "network_attacks_blocked": 0,
            "phishing_blocked": 0,
            "malware_quarantined": 0,
            "session_start": datetime.now()
        }
        
        # Callbacks for real-time events
        self.on_threat_detected: Optional[Callable[[DetectedThreat], None]] = None
        self.on_threat_blocked: Optional[Callable[[DetectedThreat], None]] = None
        self.on_scan_complete: Optional[Callable[[ScanResult], None]] = None
        self.on_monitor_cycle: Optional[Callable[[Dict[str, Any]], None]] = None
        
        # Initialize database
        self._init_database()
        
        # Load definitions
        self._load_definitions()
        
        logger.info(f"{PRODUCT_NAME} v{VERSION} initialized")
    
    def _init_database(self):
        """Initialize SQLite database for persistent storage."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.executescript("""
            CREATE TABLE IF NOT EXISTS threats (
                id TEXT PRIMARY KEY,
                category TEXT,
                severity INTEGER,
                source TEXT,
                location TEXT,
                detection_time TEXT,
                status TEXT,
                action_taken TEXT,
                raw_data TEXT
            );
            
            CREATE TABLE IF NOT EXISTS quarantine (
                id TEXT PRIMARY KEY,
                original_path TEXT,
                quarantine_path TEXT,
                threat_id TEXT,
                quarantine_time TEXT,
                encrypted INTEGER
            );
            
            CREATE TABLE IF NOT EXISTS scan_history (
                id TEXT PRIMARY KEY,
                scan_type TEXT,
                start_time TEXT,
                end_time TEXT,
                files_scanned INTEGER,
                threats_found INTEGER,
                status TEXT
            );
            
            CREATE TABLE IF NOT EXISTS blocked_items (
                item TEXT PRIMARY KEY,
                item_type TEXT,
                blocked_time TEXT,
                reason TEXT
            );
            
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT,
                event_time TEXT,
                details TEXT
            );
        """)
        
        conn.commit()
        conn.close()
    
    def _load_definitions(self):
        """Load threat definitions."""
        bundle = self.intel_provider.load_bundle()
        self.known_malware_hashes = dict(bundle.malware_hashes)
        self.suspicious_processes = {item.lower() for item in bundle.suspicious_processes}
        self.blocked_domains.update(domain.lower() for domain in bundle.malicious_domains)
        self.threat_signatures = {sig.sig_id: sig for sig in bundle.signatures}
        self.definitions_version = bundle.version
        self.definitions_date = datetime.now()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # REAL-TIME PROTECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def enable_real_time_protection(self):
        """Enable real-time protection."""
        self.real_time_protection = True
        self.protection_status = ProtectionStatus.ACTIVE
        self._log_event("PROTECTION", "Real-time protection enabled")
        logger.info("Real-time protection ENABLED")
    
    def disable_real_time_protection(self):
        """Disable real-time protection (not recommended)."""
        self.real_time_protection = False
        self.protection_status = ProtectionStatus.PASSIVE
        self._log_event("PROTECTION", "Real-time protection disabled")
        logger.warning("Real-time protection DISABLED - System at risk!")
    
    def check_file(self, file_path: str) -> Optional[DetectedThreat]:
        """
        Scan a single file for threats.
        Called by real-time protection on file access.
        """
        path = Path(file_path)
        if not path.exists():
            return None
        
        threat = None
        
        # Check extension
        if path.suffix.lower() in DANGEROUS_EXTENSIONS:
            # Hash the file
            file_hash = self._hash_file(path)
            
            # Check against known malware
            if file_hash in self.known_malware_hashes:
                threat = self._create_threat(
                    category=ThreatCategory.MALWARE,
                    severity=ThreatSeverity.HIGH,
                    source="file_scan",
                    location=str(path),
                    file_hash=file_hash,
                    indicators=[f"Known malware: {self.known_malware_hashes[file_hash]}"]
                )
            
            # Behavioral/heuristic analysis
            elif self._heuristic_scan(path):
                threat = self._create_threat(
                    category=ThreatCategory.PUP,
                    severity=ThreatSeverity.MEDIUM,
                    source="heuristic_scan",
                    location=str(path),
                    file_hash=file_hash,
                    indicators=["Suspicious behavior detected"]
                )
        
        if threat:
            self._handle_threat(threat)
        
        return threat
    
    def _hash_file(self, path: Path) -> str:
        """Calculate SHA-256 hash of file."""
        sha256 = hashlib.sha256()
        try:
            with open(path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except (IOError, PermissionError):
            return ""
    
    def _heuristic_scan(self, path: Path) -> bool:
        """
        Perform heuristic analysis on file.
        Returns True if suspicious.
        """
        try:
            # Check file size (very small executables are suspicious)
            if path.stat().st_size < 1024 and path.suffix in {'.exe', '.dll'}:
                return True
            
            # Check for suspicious strings in file
            suspicious_strings = [
                b'CreateRemoteThread',
                b'VirtualAllocEx',
                b'WriteProcessMemory',
                b'mimikatz',
                b'payload',
                b'shellcode'
            ]
            
            with open(path, 'rb') as f:
                content = f.read(65536)  # First 64KB
                for sus in suspicious_strings:
                    if sus.lower() in content.lower():
                        return True
            
            return False
        except:
            return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SCANNING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def start_scan(self, scan_type: ScanType = ScanType.QUICK, 
                   paths: Optional[List[str]] = None,
                   progress_callback: Optional[Callable[[float, int], None]] = None,
                   stop_flag: Optional[threading.Event] = None) -> ScanResult:
        """Start a system scan with optional progress callback and stop flag."""
        if self.current_scan and self.current_scan.status == "running":
            logger.warning("Scan already in progress")
            return self.current_scan
        scan_id = f"SCAN-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:8]}"
        self.current_scan = ScanResult(
            scan_id=scan_id,
            scan_type=scan_type,
            start_time=datetime.now()
        )
        if stop_flag is not None:
            self._scan_stop_event = stop_flag
        else:
            self._scan_stop_event.clear()
        # Determine paths to scan
        if paths:
            scan_paths = [Path(p) for p in paths]
        elif scan_type == ScanType.QUICK:
            scan_paths = self._get_quick_scan_paths()
        elif scan_type == ScanType.FULL:
            scan_paths = self._get_full_scan_paths()
        else:
            scan_paths = self._get_quick_scan_paths()
        # Start scan in background thread
        self._scan_thread = threading.Thread(
            target=self._scan_worker,
            args=(scan_paths, progress_callback),
            daemon=True
        )
        self._scan_thread.start()
        self._log_event("SCAN", f"Started {scan_type.value}")
        logger.info(f"Started {scan_type.value}")
        return self.current_scan
    
    def stop_scan(self):
        """Stop the current scan."""
        if self.current_scan and self.current_scan.status == "running":
            self._scan_stop_event.set()
            logger.info("Scan stop requested")
    
    def _scan_worker(self, paths: List[Path], progress_callback: Optional[Callable[[float, int], None]] = None):
        """Background scan worker with progress callback."""
        try:
            total_files = self._count_files(paths)
            files_scanned = 0
            for path in paths:
                if self._scan_stop_event.is_set():
                    break
                files_scanned += self._scan_path_with_progress(path, progress_callback, total_files, files_scanned)
                if progress_callback:
                    percent = min(100, (files_scanned / total_files) * 100 if total_files else 100)
                    progress_callback(percent, files_scanned)
            # Complete scan
            if self.current_scan:
                self.current_scan.end_time = datetime.now()
                self.current_scan.status = "completed" if not self._scan_stop_event.is_set() else "stopped"
                self.scan_history.append(self.current_scan)
                self.stats["scans_completed"] += 1
                if self.on_scan_complete:
                    self.on_scan_complete(self.current_scan)
                self._log_event("SCAN", f"Completed: {self.current_scan.files_scanned} files, {self.current_scan.threats_found} threats")
        except Exception as e:
            logger.error(f"Scan error: {e}")
            if self.current_scan:
                self.current_scan.status = "error"
                self.current_scan.errors += 1

    def _count_files(self, paths: List[Path]) -> int:
        count = 0
        for path in paths:
            if path.is_file():
                count += 1
            elif path.is_dir():
                try:
                    for item in path.rglob('*'):
                        if item.is_file():
                            count += 1
                except Exception:
                    continue
        return count

    def _scan_path_with_progress(self, path: Path, progress_callback: Optional[Callable[[float, int], None]], total_files: int, files_scanned: int) -> int:
        """Recursively scan a path and update progress."""
        scanned = 0
        if self._scan_stop_event.is_set():
            return 0
        try:
            if path.is_file():
                self._scan_file(path)
                scanned += 1
                if progress_callback:
                    percent = min(100, ((files_scanned + scanned) / total_files) * 100 if total_files else 100)
                    progress_callback(percent, files_scanned + scanned)
            elif path.is_dir():
                for item in path.iterdir():
                    if self._scan_stop_event.is_set():
                        break
                    scanned += self._scan_path_with_progress(item, progress_callback, total_files, files_scanned + scanned)
        except PermissionError:
            pass
        return scanned
    
    def _scan_path(self, path: Path):
        """Recursively scan a path."""
        if self._scan_stop_event.is_set():
            return
        
        try:
            if path.is_file():
                self._scan_file(path)
            elif path.is_dir():
                for item in path.iterdir():
                    if self._scan_stop_event.is_set():
                        break
                    self._scan_path(item)
        except PermissionError:
            pass
        except Exception as e:
            if self.current_scan:
                self.current_scan.errors += 1
    
    def _scan_file(self, path: Path):
        """Scan a single file."""
        if self.current_scan:
            self.current_scan.files_scanned += 1
            self.stats["files_scanned"] += 1
        
        threat = self.check_file(str(path))
        
        if threat and self.current_scan:
            self.current_scan.threats_found += 1
            self.current_scan.detected_threats.append(threat)
    
    def _get_quick_scan_paths(self) -> List[Path]:
        """Get paths for quick scan."""
        paths = []
        
        if platform.system() == "Windows":
            paths.extend([
                Path(os.environ.get("USERPROFILE", "")) / "Downloads",
                Path(os.environ.get("USERPROFILE", "")) / "Desktop",
                Path(os.environ.get("APPDATA", "")),
                Path(os.environ.get("LOCALAPPDATA", "")) / "Temp",
                Path("C:/Windows/Temp"),
            ])
        else:
            home = Path.home()
            paths.extend([
                home / "Downloads",
                home / "Desktop",
                Path("/tmp"),
            ])
        
        return [p for p in paths if p.exists()]
    
    def _get_full_scan_paths(self) -> List[Path]:
        """Get paths for full system scan."""
        paths = []
        
        if platform.system() == "Windows":
            # All fixed drives
            for letter in "CDEFGHIJ":
                drive = Path(f"{letter}:/")
                if drive.exists():
                    paths.append(drive)
        else:
            paths.append(Path("/"))
        
        return paths
    
    # ═══════════════════════════════════════════════════════════════════════════
    # NETWORK MONITORING & FIREWALL
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_network_connections(self) -> List[NetworkConnection]:
        """Get all active network connections with risk assessment."""
        connections = []
        
        try:
            for conn in psutil.net_connections(kind='inet'):
                if conn.status == 'ESTABLISHED' and conn.raddr:
                    try:
                        proc = psutil.Process(conn.pid) if conn.pid else None
                        proc_name = proc.name() if proc else "Unknown"
                    except:
                        proc_name = "Unknown"
                    
                    # Assess risk
                    risk = self._assess_connection_risk(
                        conn.raddr[0] if conn.raddr else "",
                        proc_name
                    )
                    
                    connections.append(NetworkConnection(
                        local_addr=conn.laddr[0] if conn.laddr else "",
                        local_port=conn.laddr[1] if conn.laddr else 0,
                        remote_addr=conn.raddr[0] if conn.raddr else "",
                        remote_port=conn.raddr[1] if conn.raddr else 0,
                        protocol="TCP" if conn.type == socket.SOCK_STREAM else "UDP",
                        status=conn.status,
                        process_name=proc_name,
                        process_id=conn.pid or 0,
                        risk_level=risk
                    ))
        except Exception as e:
            logger.error(f"Error getting connections: {e}")
        
        self.active_connections = connections
        return connections
    
    def _assess_connection_risk(self, remote_ip: str, process_name: str) -> ThreatSeverity:
        """Assess risk level of a network connection."""
        # Check blocked IPs
        if remote_ip in self.blocked_ips:
            return ThreatSeverity.CRITICAL
        
        # Check suspicious processes
        if process_name.lower() in self.suspicious_processes:
            return ThreatSeverity.HIGH
        
        # Check for suspicious ports
        suspicious_ports = {4444, 5555, 6666, 31337, 12345}  # Common backdoor ports
        # Note: Would need the port here for full check
        
        return ThreatSeverity.INFO
    
    def block_ip(self, ip: str, reason: str = "Manual block"):
        """Block an IP address."""
        self.blocked_ips.add(ip)
        self._log_event("FIREWALL", f"Blocked IP: {ip} - {reason}")
        self.stats["network_attacks_blocked"] += 1
        logger.info(f"Blocked IP: {ip}")
    
    def unblock_ip(self, ip: str):
        """Unblock an IP address."""
        self.blocked_ips.discard(ip)
        self._log_event("FIREWALL", f"Unblocked IP: {ip}")
        logger.info(f"Unblocked IP: {ip}")
    
    def block_domain(self, domain: str, reason: str = "Manual block"):
        """Block a domain."""
        self.blocked_domains.add(domain.lower())
        self._log_event("WEB_PROTECTION", f"Blocked domain: {domain} - {reason}")
        logger.info(f"Blocked domain: {domain}")
    
    def check_url(self, url: str) -> bool:
        """
        Check if URL is safe.
        Returns True if safe, False if blocked.
        """
        # Extract domain from URL
        domain_match = re.search(r'https?://([^/]+)', url.lower())
        if domain_match:
            domain = domain_match.group(1)
            
            # Check against blocked domains
            for blocked in self.blocked_domains:
                if blocked in domain:
                    self.stats["phishing_blocked"] += 1
                    self._log_event("WEB_PROTECTION", f"Blocked URL: {url}")
                    return False
        
        return True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PROCESS MONITORING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def scan_running_processes(self) -> List[DetectedThreat]:
        """Scan all running processes for threats."""
        threats = []
        
        for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
            try:
                info = proc.info
                proc_name = info['name'].lower() if info['name'] else ""
                
                # Check against suspicious process list
                if any(sus in proc_name for sus in self.suspicious_processes):
                    threat = self._create_threat(
                        category=ThreatCategory.MALWARE,
                        severity=ThreatSeverity.HIGH,
                        source="process_scan",
                        location=info['exe'] or proc_name,
                        process_id=info['pid'],
                        indicators=[f"Suspicious process: {proc_name}"]
                    )
                    threats.append(threat)
                    self._handle_threat(threat)
                
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        return threats
    
    def get_process_list(self) -> List[Dict[str, Any]]:
        """Get list of running processes with security info."""
        processes = []
        
        for proc in psutil.process_iter(['pid', 'name', 'exe', 'username', 'cpu_percent', 'memory_percent']):
            try:
                info = proc.info
                proc_name = info['name'].lower() if info['name'] else ""
                
                # Determine trust level
                trust = "trusted" if info['exe'] and str(info['exe']) in self.trusted_apps else "unknown"
                if any(sus in proc_name for sus in self.suspicious_processes):
                    trust = "suspicious"
                
                processes.append({
                    "pid": info['pid'],
                    "name": info['name'],
                    "exe": info['exe'],
                    "user": info['username'],
                    "cpu": info['cpu_percent'],
                    "memory": info['memory_percent'],
                    "trust_level": trust
                })
            except:
                continue
        
        return processes
    
    # ═══════════════════════════════════════════════════════════════════════════
    # RANSOMWARE PROTECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def enable_ransomware_protection(self):
        """Enable ransomware protection."""
        self.ransomware_protection = True
        self._log_event("RANSOMWARE", "Ransomware protection enabled")
        logger.info("Ransomware protection ENABLED")
    
    def check_ransomware_behavior(self, path: str, operation: str) -> bool:
        """
        Check if an operation might be ransomware behavior.
        Returns True if blocked, False if allowed.
        """
        if not self.ransomware_protection:
            return False
        
        # Ransomware indicators
        ransomware_extensions = {
            '.encrypted', '.locked', '.crypto', '.crypt', '.enc', '.crypted',
            '.locky', '.zepto', '.cerber', '.wallet', '.petya', '.wannacry'
        }
        
        path_obj = Path(path)
        
        # Check for ransomware extension being added
        if operation == "rename" and path_obj.suffix.lower() in ransomware_extensions:
            self._create_threat(
                category=ThreatCategory.RANSOMWARE,
                severity=ThreatSeverity.CRITICAL,
                source="ransomware_protection",
                location=path,
                indicators=["Ransomware encryption attempt detected"]
            )
            return True  # Block the operation
        
        return False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # QUARANTINE MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    def quarantine_file(self, file_path: str, threat: DetectedThreat) -> Optional[QuarantineItem]:
        """Move a file to quarantine."""
        try:
            src = Path(file_path)
            if not src.exists():
                return None
            
            # Create quarantine entry
            item_id = f"Q-{uuid.uuid4().hex[:12]}"
            quarantine_path = self.quarantine_dir / f"{item_id}.quarantine"
            
            # Encrypt and move (simplified - in production would use proper encryption)
            import shutil
            shutil.move(str(src), str(quarantine_path))
            
            item = QuarantineItem(
                item_id=item_id,
                original_path=str(src),
                quarantine_path=str(quarantine_path),
                threat=threat,
                encrypted=True
            )
            
            self.quarantine[item_id] = item
            self.stats["malware_quarantined"] += 1
            
            self._log_event("QUARANTINE", f"Quarantined: {file_path}")
            logger.info(f"Quarantined: {file_path}")
            
            return item
            
        except Exception as e:
            logger.error(f"Quarantine failed: {e}")
            return None
    
    def restore_from_quarantine(self, item_id: str) -> bool:
        """Restore a file from quarantine."""
        if item_id not in self.quarantine:
            return False
        
        item = self.quarantine[item_id]
        
        try:
            import shutil
            shutil.move(item.quarantine_path, item.original_path)
            del self.quarantine[item_id]
            
            self._log_event("QUARANTINE", f"Restored: {item.original_path}")
            logger.info(f"Restored from quarantine: {item.original_path}")
            return True
            
        except Exception as e:
            logger.error(f"Restore failed: {e}")
            return False
    
    def delete_quarantined(self, item_id: str) -> bool:
        """Permanently delete a quarantined file."""
        if item_id not in self.quarantine:
            return False
        
        item = self.quarantine[item_id]
        
        try:
            Path(item.quarantine_path).unlink()
            del self.quarantine[item_id]
            
            self._log_event("QUARANTINE", f"Deleted: {item.original_path}")
            logger.info(f"Deleted from quarantine: {item.original_path}")
            return True
            
        except Exception as e:
            logger.error(f"Delete failed: {e}")
            return False
    
    def get_quarantine_list(self) -> List[QuarantineItem]:
        """Get all quarantined items."""
        return list(self.quarantine.values())
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SYSTEM HEALTH & STATUS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_system_health(self) -> SystemHealth:
        """Get comprehensive system health status."""
        
        # Calculate overall security score
        score = 100
        
        if not self.real_time_protection:
            score -= 30
        if not self.firewall_enabled:
            score -= 20
        if not self.ransomware_protection:
            score -= 15
        if len(self.detected_threats) > 0:
            score -= min(len(self.detected_threats) * 5, 25)
        
        # Check for recent scan
        last_scan = self.scan_history[-1].start_time if self.scan_history else None
        if last_scan:
            days_since_scan = (datetime.now() - last_scan).days
            if days_since_scan > 7:
                score -= 10
        else:
            score -= 10
        
        score = max(0, score)
        
        return SystemHealth(
            cpu_usage=psutil.cpu_percent(),
            memory_usage=psutil.virtual_memory().percent,
            disk_usage=psutil.disk_usage('/').percent if platform.system() != "Windows" else psutil.disk_usage('C:/').percent,
            network_activity=sum(1 for c in self.active_connections if c.status == 'ESTABLISHED'),
            active_threats=len([t for t in self.detected_threats if t.status == "detected"]),
            quarantined_items=len(self.quarantine),
            last_scan=last_scan,
            protection_status=self.protection_status,
            firewall_enabled=self.firewall_enabled,
            real_time_protection=self.real_time_protection,
            definitions_version=self.definitions_version,
            definitions_date=self.definitions_date,
            overall_score=score
        )
    
    def get_dashboard_summary(self) -> Dict[str, Any]:
        """Get dashboard summary for UI."""
        health = self.get_system_health()
        
        return {
            "product": PRODUCT_NAME,
            "version": VERSION,
            "status": "Protected" if health.overall_score >= 70 else "At Risk",
            "score": health.overall_score,
            "protection": {
                "real_time": self.real_time_protection,
                "firewall": self.firewall_enabled,
                "web_protection": self.web_protection,
                "ransomware": self.ransomware_protection,
                "network_monitoring": self.network_monitoring
            },
            "threats": {
                "active": health.active_threats,
                "quarantined": health.quarantined_items,
                "total_blocked": self.stats["threats_blocked"]
            },
            "system": {
                "cpu": health.cpu_usage,
                "memory": health.memory_usage,
                "disk": health.disk_usage
            },
            "definitions": {
                "version": self.definitions_version,
                "date": self.definitions_date.isoformat(),
                "signature_count": len(self.threat_signatures)
            },
            "last_scan": health.last_scan.isoformat() if health.last_scan else None,
            "session_stats": self.stats
        }
    
    # ═══════════════════════════════════════════════════════════════════════════
    # THREAT HANDLING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _create_threat(self, category: ThreatCategory, severity: ThreatSeverity,
                       source: str, location: str, **kwargs) -> DetectedThreat:
        """Create a new threat detection."""
        threat_id = f"THREAT-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:8]}"
        
        threat = DetectedThreat(
            threat_id=threat_id,
            signature=None,
            category=category,
            severity=severity,
            source=source,
            location=location,
            **kwargs
        )
        
        return threat
    
    def _handle_threat(self, threat: DetectedThreat):
        """Handle a detected threat."""
        self.detected_threats.append(threat)
        self.stats["threats_blocked"] += 1
        
        # Log the event
        self._log_event("THREAT", f"{threat.category.value} detected at {threat.location}")
        
        # Callback
        if self.on_threat_detected:
            self.on_threat_detected(threat)
        
        # Auto-actions based on severity
        if self.protection_status == ProtectionStatus.ACTIVE:
            if threat.severity in [ThreatSeverity.HIGH, ThreatSeverity.CRITICAL]:
                # Auto-quarantine high severity threats
                if threat.location and Path(threat.location).exists():
                    self.quarantine_file(threat.location, threat)
                    threat.action_taken = "quarantined"
                    threat.status = "quarantined"
        
        logger.warning(f"THREAT: {threat.category.value} - {threat.severity.name} - {threat.location}")
    
    def _log_event(self, event_type: str, details: str):
        """Log a security event."""
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO events (event_type, event_time, details) VALUES (?, ?, ?)",
                (event_type, datetime.now().isoformat(), details)
            )
            conn.commit()
            conn.close()
        except:
            pass
    
    def get_event_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent security events."""
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute(
                "SELECT event_type, event_time, details FROM events ORDER BY id DESC LIMIT ?",
                (limit,)
            )
            rows = cursor.fetchall()
            conn.close()
            
            return [
                {"type": r[0], "time": r[1], "details": r[2]}
                for r in rows
            ]
        except:
            return []
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CONTINUOUS MONITORING
    # ═══════════════════════════════════════════════════════════════════════════
    
    def start_monitoring(self, interval: float = 5.0):
        """Start continuous monitoring in a background thread."""
        self.monitor_interval = max(0.5, interval)
        if self._monitor_thread and self._monitor_thread.is_alive():
            return
        self._monitor_stop_event.clear()
        self._monitor_thread = threading.Thread(target=self._monitor_loop, name="SERE-Monitor", daemon=True)
        self._monitor_thread.start()
        self._log_event("MONITOR", f"Monitoring started @ {self.monitor_interval:.1f}s interval")

    def stop_monitoring(self, wait: bool = False):
        """Signal the monitoring thread to stop."""
        self._monitor_stop_event.set()
        if wait and self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=self.monitor_interval + 1.0)

    def _monitor_loop(self):
        """Internal loop that dispatches monitoring cycles asynchronously."""
        while not self._monitor_stop_event.is_set():
            findings = self.run_monitoring_cycle()
            if self.on_monitor_cycle:
                try:
                    self.on_monitor_cycle(findings)
                except Exception as exc:
                    logger.error(f"Monitor callback failure: {exc}")
            if self._monitor_stop_event.wait(self.monitor_interval):
                break

    def run_monitoring_cycle(self) -> Dict[str, Any]:
        """
        Run a single monitoring cycle.
        Returns summary of findings.
        """
        cycle_start = datetime.now()
        findings = {
            "timestamp": cycle_start.isoformat(),
            "threats": [],
            "network_alerts": [],
            "process_alerts": [],
            "system_health": None
        }
        
        # 1. Process scan
        process_threats = self.scan_running_processes()
        findings["process_alerts"] = [
            {"id": t.threat_id, "category": t.category.value, "severity": t.severity.name}
            for t in process_threats
        ]
        
        # 2. Network monitoring
        connections = self.get_network_connections()
        high_risk = [c for c in connections if c.risk_level.value >= ThreatSeverity.MEDIUM.value]
        findings["network_alerts"] = [
            {"remote": c.remote_addr, "port": c.remote_port, "process": c.process_name, "risk": c.risk_level.name}
            for c in high_risk
        ]
        
        # 3. System health
        health = self.get_system_health()
        findings["system_health"] = {
            "score": health.overall_score,
            "status": self.protection_status.value,
            "active_threats": health.active_threats
        }
        
        return findings

    def shutdown(self):
        """Gracefully stop active scans/monitoring threads."""
        self.stop_monitoring(wait=True)
        self.stop_scan()


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    """Test the security engine."""
    print(f"\n{'='*60}")
    print(f"  {PRODUCT_NAME} v{VERSION}")
    print(f"  {VENDOR}")
    print(f"{'='*60}\n")
    
    engine = SERESecurityEngine()
    
    # Get dashboard
    dashboard = engine.get_dashboard_summary()
    print(f"Status: {dashboard['status']}")
    print(f"Security Score: {dashboard['score']}/100")
    print(f"Real-time Protection: {'ON' if dashboard['protection']['real_time'] else 'OFF'}")
    print(f"Firewall: {'ON' if dashboard['protection']['firewall'] else 'OFF'}")
    print()
    
    # Run monitoring cycle
    print("Running monitoring cycle...")
    findings = engine.run_monitoring_cycle()
    print(f"  Process Alerts: {len(findings['process_alerts'])}")
    print(f"  Network Alerts: {len(findings['network_alerts'])}")
    print(f"  System Score: {findings['system_health']['score']}")
    
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
