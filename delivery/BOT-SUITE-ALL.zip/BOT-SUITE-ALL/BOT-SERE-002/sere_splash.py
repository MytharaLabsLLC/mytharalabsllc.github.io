#!/usr/bin/env python3
"""
S.E.R.E. Security Suite - Professional Graphical Splash Screen
Copyright © 2025 Herbert Velez Jr. All rights reserved.
Proprietary and Confidential.

Tactical HUD-style animated splash with radar sweep and shield effects.
"""

import tkinter as tk
import math
import threading
import time
from typing import Any, Callable, Dict, Optional

# Colors - Military/Tactical HUD theme
COLORS = {
    'bg_dark': '#0a0c10',
    'bg_medium': '#12161f', 
    'accent_green': '#00ff41',
    'accent_cyan': '#00d4ff',
    'accent_amber': '#ffb000',
    'accent_red': '#ff3333',
    'text_white': '#ffffff',
    'text_gray': '#556677',
    'grid': '#1a2030',
    'glow_green': '#00ff4180',
}


class SEROSplashScreen:
    """Professional tactical HUD splash screen for S.E.R.E."""
    
    def __init__(self, duration: float = None, on_complete: callable = None,
                 telemetry_provider: Optional[Callable[[], Dict[str, Any]]] = None):
        """
        Args:
            duration: How long to show splash (seconds). None = permanent until clicked/key press.
            on_complete: Callback when splash closes.
        """
        self.duration = duration  # None means permanent
        self.on_complete = on_complete
        self.telemetry_provider = telemetry_provider
        self._telemetry_cache: Optional[Dict[str, Any]] = None
        self._telemetry_cache_time = 0.0
        self.root = None
        self.canvas = None
        self.animation_running = True
        self.frame = 0
        self.radar_angle = 0
        self.shield_segments = 0
        self.scan_lines = []
        
    def show(self):
        """Display the splash screen."""
        self.root = tk.Tk()
        self.root.title("S.E.R.E. Security Suite")
        
        # Remove window decorations for splash effect
        self.root.overrideredirect(True)
        
        # Window size
        self.width = 800
        self.height = 500
        
        # Center on screen
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - self.width) // 2
        y = (screen_height - self.height) // 2
        self.root.geometry(f"{self.width}x{self.height}+{x}+{y}")
        
        # Make it stay on top
        self.root.attributes('-topmost', True)
        
        # Bind click and key to close (for permanent mode)
        self.root.bind('<Button-1>', lambda e: self._close())
        self.root.bind('<Key>', lambda e: self._close())
        self.root.bind('<Escape>', lambda e: self._close())
        
        # Create canvas
        self.canvas = tk.Canvas(
            self.root, 
            width=self.width, 
            height=self.height, 
            bg=COLORS['bg_dark'],
            highlightthickness=0
        )
        self.canvas.pack()
        
        # Draw static elements
        self._draw_background()
        self._draw_ui_frame()
        
        # Start animation
        self._animate()
        
        # Close after duration only if duration is set
        if self.duration is not None:
            self.root.after(int(self.duration * 1000), self._close)
        
        # Run
        self.root.mainloop()

    def _get_telemetry(self) -> Optional[Dict[str, Any]]:
        """Pull telemetry data from the provider with light caching."""
        if not self.telemetry_provider:
            return None
        now = time.time()
        if (self._telemetry_cache is None) or (now - self._telemetry_cache_time > 0.5):
            try:
                data = self.telemetry_provider()
            except Exception:
                data = None
            if data:
                self._telemetry_cache = data
                self._telemetry_cache_time = now
        return self._telemetry_cache
    
    def _draw_background(self):
        """Draw the tactical grid background."""
        # Grid lines
        for i in range(0, self.width, 40):
            self.canvas.create_line(i, 0, i, self.height, fill=COLORS['grid'], width=1)
        for i in range(0, self.height, 40):
            self.canvas.create_line(0, i, self.width, i, fill=COLORS['grid'], width=1)
    
    def _draw_ui_frame(self):
        """Draw the HUD frame elements."""
        w, h = self.width, self.height
        
        # Corner brackets - top left
        self.canvas.create_line(10, 10, 10, 50, fill=COLORS['accent_cyan'], width=2)
        self.canvas.create_line(10, 10, 50, 10, fill=COLORS['accent_cyan'], width=2)
        
        # Corner brackets - top right
        self.canvas.create_line(w-10, 10, w-10, 50, fill=COLORS['accent_cyan'], width=2)
        self.canvas.create_line(w-10, 10, w-50, 10, fill=COLORS['accent_cyan'], width=2)
        
        # Corner brackets - bottom left
        self.canvas.create_line(10, h-10, 10, h-50, fill=COLORS['accent_cyan'], width=2)
        self.canvas.create_line(10, h-10, 50, h-10, fill=COLORS['accent_cyan'], width=2)
        
        # Corner brackets - bottom right
        self.canvas.create_line(w-10, h-10, w-10, h-50, fill=COLORS['accent_cyan'], width=2)
        self.canvas.create_line(w-10, h-10, w-50, h-10, fill=COLORS['accent_cyan'], width=2)
        
        # Top status bar background
        self.canvas.create_rectangle(60, 8, w-60, 35, fill=COLORS['bg_medium'], outline='')
        
        # "SYSTEM INITIALIZING" text at top
        self.status_text = self.canvas.create_text(
            w//2, 22,
            text="[ SYSTEM INITIALIZING ]",
            font=("Consolas", 11, "bold"),
            fill=COLORS['accent_amber']
        )
        
        # Copyright at bottom
        self.canvas.create_text(
            w//2, h-20,
            text="© 2025 Herbert Velez Jr. | MYTHARA ENGINE | ALL RIGHTS RESERVED",
            font=("Consolas", 9),
            fill=COLORS['text_gray']
        )
    
    def _draw_radar(self, cx, cy, radius):
        """Draw tactical radar display."""
        self.canvas.delete('radar')
        
        # Outer ring
        self.canvas.create_oval(
            cx-radius, cy-radius, cx+radius, cy+radius,
            outline=COLORS['accent_cyan'], width=2, tags='radar'
        )
        
        # Inner rings
        for r in [radius*0.7, radius*0.4]:
            self.canvas.create_oval(
                cx-r, cy-r, cx+r, cy+r,
                outline=COLORS['text_gray'], width=1, tags='radar'
            )
        
        # Cross hairs
        self.canvas.create_line(cx-radius, cy, cx+radius, cy, fill=COLORS['text_gray'], width=1, tags='radar')
        self.canvas.create_line(cx, cy-radius, cx, cy+radius, fill=COLORS['text_gray'], width=1, tags='radar')
        
        # Radar sweep (pie slice)
        sweep_angle = 45
        start_angle = self.radar_angle
        
        # Create glowing sweep effect
        for i in range(3):
            alpha_tag = f'radar_sweep_{i}'
            offset = i * 15
            self.canvas.create_arc(
                cx-radius+5, cy-radius+5, cx+radius-5, cy+radius-5,
                start=start_angle - offset, extent=sweep_angle,
                fill=COLORS['accent_green'] if i == 0 else '',
                outline=COLORS['accent_green'],
                width=2 if i == 0 else 1,
                style='pieslice' if i == 0 else 'arc',
                tags='radar'
            )
        
        # Center dot
        self.canvas.create_oval(
            cx-4, cy-4, cx+4, cy+4,
            fill=COLORS['accent_green'], outline='', tags='radar'
        )
        
        # Blips on radar (appear as sweep passes)
        blip_positions = [
            (0.3, 0.2), (0.6, 0.7), (0.8, 0.3), (0.2, 0.6), (0.5, 0.5)
        ]
        for i, (rx, ry) in enumerate(blip_positions):
            blip_angle = math.degrees(math.atan2(ry - 0.5, rx - 0.5)) + 180
            angle_diff = (start_angle - blip_angle) % 360
            
            if angle_diff < 90:  # Show blip if sweep recently passed
                intensity = 1 - (angle_diff / 90)
                bx = cx + (rx - 0.5) * radius * 1.6
                by = cy + (ry - 0.5) * radius * 1.6
                size = 3 + intensity * 3
                
                color = COLORS['accent_green'] if intensity > 0.5 else COLORS['text_gray']
                self.canvas.create_oval(
                    bx-size, by-size, bx+size, by+size,
                    fill=color, outline='', tags='radar'
                )
    
    def _draw_shield(self, cx, cy, radius, segments_active):
        """Draw animated shield/protection indicator."""
        self.canvas.delete('shield')
        
        total_segments = 8
        segment_angle = 360 / total_segments
        gap = 8  # degrees between segments
        
        for i in range(total_segments):
            start = i * segment_angle + gap/2
            extent = segment_angle - gap
            
            if i < segments_active:
                # Active segment - bright
                color = COLORS['accent_green']
                width = 8
            else:
                # Inactive segment - dim
                color = COLORS['text_gray']
                width = 3
            
            self.canvas.create_arc(
                cx-radius, cy-radius, cx+radius, cy+radius,
                start=start, extent=extent,
                outline=color, width=width, style='arc',
                tags='shield'
            )
        
        # Inner glow when fully active
        if segments_active >= total_segments:
            for r in range(3):
                inner_r = radius - 20 - r*10
                self.canvas.create_oval(
                    cx-inner_r, cy-inner_r, cx+inner_r, cy+inner_r,
                    outline=COLORS['accent_green'], width=1,
                    tags='shield'
                )
    
    def _draw_sere_logo(self, alpha_level):
        """Draw the SERE logo with fade-in effect."""
        self.canvas.delete('logo')
        
        cx = self.width // 2
        cy = 200
        
        # Only show if past initial phase
        if alpha_level <= 0:
            return
        
        # Main title - S.E.R.E.
        color = COLORS['accent_green'] if alpha_level > 0.5 else COLORS['text_gray']
        
        self.canvas.create_text(
            cx, cy,
            text="S.E.R.E.",
            font=("Consolas", 72, "bold"),
            fill=color,
            tags='logo'
        )
        
        # Subtitle
        if alpha_level > 0.3:
            self.canvas.create_text(
                cx, cy + 55,
                text="SURVIVE  •  EVADE  •  RESIST  •  ESCAPE",
                font=("Consolas", 14),
                fill=COLORS['text_gray'] if alpha_level < 0.7 else COLORS['accent_cyan'],
                tags='logo'
            )
        
        # Security Suite text
        if alpha_level > 0.6:
            self.canvas.create_text(
                cx, cy + 90,
                text="SECURITY SUITE v2.0.0",
                font=("Consolas", 18, "bold"),
                fill=COLORS['text_white'],
                tags='logo'
            )
        
        # Enterprise text
        if alpha_level > 0.8:
            self.canvas.create_text(
                cx, cy + 120,
                text="Enterprise Cybersecurity Platform",
                font=("Consolas", 12),
                fill=COLORS['text_gray'],
                tags='logo'
            )
    
    def _draw_scan_effect(self, progress):
        """Draw scanning line effect."""
        self.canvas.delete('scan')
        
        # Horizontal scan line
        scan_y = int(progress * self.height)
        
        # Main scan line
        self.canvas.create_line(
            0, scan_y, self.width, scan_y,
            fill=COLORS['accent_cyan'], width=2, tags='scan'
        )
        
        # Trailing glow
        for i in range(1, 8):
            y = scan_y - i * 3
            if y > 0:
                self.canvas.create_line(
                    0, y, self.width, y,
                    fill=COLORS['grid'], width=1, tags='scan'
                )
    
    def _draw_status_indicators(self, progress):
        """Draw status indicators and loading info."""
        self.canvas.delete('status')
        telemetry = self._get_telemetry()
        
        # Left side indicators
        y_start = 300
        x = 80
        
        if telemetry:
            protection = telemetry.get('protection', {})
            indicators = [
                ("FIREWALL", protection.get('firewall', False)),
                ("REALTIME SCAN", protection.get('real_time', False)),
                ("NETWORK MONITOR", protection.get('network_monitoring', False)),
                ("WEB PROTECTION", protection.get('web_protection', False)),
                ("RANSOMWARE SHIELD", protection.get('ransomware', False)),
                ("THREAT DATABASE", bool(telemetry.get('definitions', {}).get('version'))),
            ]
        else:
            indicators = [
                ("FIREWALL", progress > 0.1),
                ("REALTIME SCAN", progress > 0.25),
                ("NETWORK MONITOR", progress > 0.4),
                ("RANSOMWARE SHIELD", progress > 0.55),
                ("THREAT DATABASE", progress > 0.7),
                ("SYSTEM INTEGRITY", progress > 0.85),
            ]
        
        for i, (name, active) in enumerate(indicators):
            y = y_start + i * 25
            if active:
                self.canvas.create_text(
                    x, y, text="[✓]", font=("Consolas", 10, "bold"),
                    fill=COLORS['accent_green'], anchor='w', tags='status'
                )
                self.canvas.create_text(
                    x + 35, y, text=name, font=("Consolas", 10),
                    fill=COLORS['accent_green'], anchor='w', tags='status'
                )
            else:
                self.canvas.create_text(
                    x, y, text="[ ]", font=("Consolas", 10),
                    fill=COLORS['text_gray'], anchor='w', tags='status'
                )
                self.canvas.create_text(
                    x + 35, y, text=name, font=("Consolas", 10),
                    fill=COLORS['text_gray'], anchor='w', tags='status'
                )
        
        # Right side - threat stats (live data when available)
        x_right = self.width - 220
        if telemetry:
            threats = telemetry.get('threats', {})
            definitions = telemetry.get('definitions', {})
            stats = [
                ("SECURITY SCORE", f"{telemetry.get('score', 0)}"),
                ("THREATS BLOCKED", f"{threats.get('total_blocked', 0):,}"),
                ("ACTIVE THREATS", f"{threats.get('active', 0)}"),
                ("DEFINITIONS", definitions.get('version', 'N/A')),
            ]
        else:
            stats = [
                ("THREATS BLOCKED", "0"),
                ("SIGNATURES", "1,247,832"),
                ("LAST UPDATE", "2026.01.28"),
            ]
        
        for i, (label, value) in enumerate(stats):
            y = y_start + i * 30
            if telemetry or progress > 0.3 + i * 0.2:
                self.canvas.create_text(
                    x_right, y, text=label, font=("Consolas", 9),
                    fill=COLORS['text_gray'], anchor='w', tags='status'
                )
                self.canvas.create_text(
                    x_right + 140, y, text=value, font=("Consolas", 11, "bold"),
                    fill=COLORS['accent_cyan'], anchor='e', tags='status'
                )
        
        # Progress bar at bottom
        bar_x = 150
        bar_y = 450
        bar_width = 500
        bar_height = 12
        
        self.canvas.create_rectangle(
            bar_x, bar_y, bar_x + bar_width, bar_y + bar_height,
            fill=COLORS['bg_medium'], outline=COLORS['text_gray'],
            tags='status'
        )
        
        fill_width = int(bar_width * progress)
        if fill_width > 0:
            self.canvas.create_rectangle(
                bar_x + 2, bar_y + 2, bar_x + fill_width - 2, bar_y + bar_height - 2,
                fill=COLORS['accent_green'], outline='',
                tags='status'
            )
        
        self.canvas.create_text(
            bar_x + bar_width + 20, bar_y + bar_height//2,
            text=f"{int(progress * 100)}%",
            font=("Consolas", 11, "bold"),
            fill=COLORS['accent_green'],
            tags='status'
        )
        
        if telemetry:
            definitions = telemetry.get('definitions', {})
            sigs = definitions.get('signature_count')
            last_scan = telemetry.get('last_scan')
            if last_scan:
                message = f"Last scan {last_scan[:19]} | Signatures: {sigs:,}" if sigs is not None else f"Last scan {last_scan[:19]}"
            else:
                message = "Baseline telemetry established. Awaiting initial scan." if not last_scan else ""
        else:
            messages = [
                "Initializing core systems...",
                "Loading threat signatures...",
                "Configuring firewall rules...",
                "Starting network monitor...",
                "Activating ransomware shield...",
                "Verifying system integrity...",
                "Protection systems online."
            ]
            msg_idx = min(int(progress * len(messages)), len(messages) - 1)
            message = messages[msg_idx]
        
        self.canvas.create_text(
            self.width // 2, bar_y + 30,
            text=message,
            font=("Consolas", 10),
            fill=COLORS['accent_amber'],
            tags='status'
        )
        
        if self.duration is None and progress >= 1.0:
            self.canvas.create_text(
                self.width // 2, bar_y + 55,
                text="[ CLICK OR PRESS ANY KEY TO CONTINUE ]",
                font=("Consolas", 10, "bold"),
                fill=COLORS['accent_cyan'],
                tags='status'
            )
    
    def _animate(self):
        """Run the animation sequence (loops forever in permanent mode)."""
        if not self.animation_running:
            return
        
        self.frame += 1
        
        # For permanent mode, use a fixed cycle length for repeating animations
        cycle_frames = 210  # ~7 seconds at 30fps for one full cycle
        
        if self.duration is not None:
            total_frames = int(self.duration * 30)
            progress = min(1.0, self.frame / total_frames)
        else:
            # Permanent mode: progress goes 0->1 then stays at 1
            progress = min(1.0, self.frame / cycle_frames)
        
        # Update radar (always spinning)
        self.radar_angle = (self.radar_angle + 6) % 360
        self._draw_radar(650, 150, 80)
        
        # Update shield segments (build up over time)
        self.shield_segments = min(8, int(progress * 12))
        self._draw_shield(150, 150, 70, self.shield_segments)
        
        # Logo fade in (starts at 20% progress)
        logo_alpha = max(0, (progress - 0.2) / 0.4)
        self._draw_sere_logo(min(1.0, logo_alpha))
        
        # Scan line effect (first half of animation, then periodic in permanent mode)
        if self.duration is None:
            # Permanent: scan line loops every 3 seconds after initial load
            if progress < 0.5 or (self.frame % 90 < 45 and progress >= 1.0):
                scan_progress = (self.frame % 45) / 45.0
                self._draw_scan_effect(scan_progress)
        elif progress < 0.5:
            scan_progress = (progress * 2) % 1.0
            self._draw_scan_effect(scan_progress)
        
        # Status indicators
        self._draw_status_indicators(progress)
        
        telemetry = self._get_telemetry()
        if telemetry:
            status = f"[ {telemetry.get('status', 'Protected').upper()} | SCORE {telemetry.get('score', 0):03} ]"
        elif progress < 0.3:
            status = "[ SYSTEM INITIALIZING ]"
        elif progress < 0.6:
            status = "[ LOADING PROTECTION MODULES ]"
        elif progress < 0.9:
            status = "[ ACTIVATING DEFENSES ]"
        else:
            status = "[ PROTECTION ACTIVE ]"
        self.canvas.itemconfig(self.status_text, text=status)
        
        # Continue animation
        if self.duration is None:
            # Permanent mode: keep animating forever
            self.root.after(33, self._animate)
        elif self.frame < int(self.duration * 30):
            self.root.after(33, self._animate)
    
    def _close(self):
        """Close the splash screen."""
        self.animation_running = False
        if self.root:
            self.root.destroy()
            self.root = None
        if self.on_complete:
            self.on_complete()


def show_splash(duration: float = None, callback: callable = None,
                telemetry_provider: Optional[Callable[[], Dict[str, Any]]] = None):
    """
    Show the S.E.R.E. splash screen.
    
    Args:
        duration: How long to show splash (seconds). None = permanent until click/keypress.
        callback: Function to call when splash closes
        telemetry_provider: Callable returning dashboard-like telemetry dict
    """
    splash = SEROSplashScreen(duration=duration, on_complete=callback, telemetry_provider=telemetry_provider)
    splash.show()


def show_splash_async(duration: float = None, telemetry_provider: Optional[Callable[[], Dict[str, Any]]] = None):
    """Show splash in a separate thread (non-blocking)."""
    thread = threading.Thread(target=show_splash, args=(duration, None, telemetry_provider), daemon=True)
    thread.start()
    return thread


# Test
if __name__ == "__main__":
    print("Showing S.E.R.E. splash screen (click or press any key to close)...")
    show_splash()  # Permanent by default
    print("Splash complete!")
