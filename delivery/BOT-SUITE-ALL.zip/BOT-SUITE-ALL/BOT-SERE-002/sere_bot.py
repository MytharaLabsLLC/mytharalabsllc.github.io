#!/usr/bin/env python3
"""
if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):if isinstance(arg, int) or isinstance(arg, long):S.E.R.E. Security Suite - Enterprise Cybersecurity Platform
Survive • Evade • Resist • Escape

Copyright © 2025 Herbert Velez Jr. All rights reserved.
Proprietary and Confidential.

ENTERPRISE-GRADE CYBERSECURITY - Competes with McAfee, Norton, Bitdefender
CONTINUOUS MONITORING SYSTEM - Runs until force stopped (Ctrl+C)

Features:
- Real-time threat detection and protection
- Advanced malware scanning
- Ransomware protection  
- Firewall management
- Network intrusion detection
- Process monitoring
- Web protection / Safe browsing
- Quarantine management
- System health monitoring
- Automatic startup capability
"""
# Core imports
import random

from sere_persona_catalog import persona_line
from typing import Dict

# Console encoding fix (2026-11-23): Windows consoles default to cp1252, which
# cannot print this suite's banners, check marks, or box drawing, and crashed
# the dashboard menu (see sere_error.log). Force UTF-8 with safe replacement.
try:
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


class PersonaProfile:
    """Callable persona wrapper that emits fresh lines per category."""

    def __init__(self, bucket_map: Dict[str, str]):
        self._bucket_map = bucket_map

    def line(self, category: str, fallback: str = "disdain") -> str:
        bucket = self._bucket_map.get(category, fallback)
        return persona_line(bucket)


PERSONA_TONE_PRESETS = {
    "default": {
        "greet": "consigliere",
        "threat": "disapproval",
        "clear": "disdain",
        "scan_complete": "consigliere",
    },
    "gunny": {
        "greet": "gunny",
        "threat": "gunny",
        "clear": "disdain",
        "scan_complete": "gunny",
    },
}


# Persona selection (default: 'default', override with --persona gunny)
def get_persona(args):
    persona_key = getattr(args, 'persona', 'default') or 'default'
    persona_key = persona_key.lower()
    bucket_map = PERSONA_TONE_PRESETS.get(persona_key, PERSONA_TONE_PRESETS['default'])
    return PersonaProfile(bucket_map)
import sys
import os
import logging
import subprocess
import signal
import time
import platform
import json
from datetime import datetime
from pathlib import Path
from typing import Optional, Any

# --- BEGIN: Print all uncaught exceptions to console ---
import traceback
def excepthook(type, value, tb):
    traceback.print_exception(type, value, tb)
    sys.exit(1)
sys.excepthook = excepthook
# --- END: Print all uncaught exceptions to console ---
import traceback

# Modes we support
SUPPORTED_MODES = ["monitor", "scan", "dashboard", "legacy"]

# Product info
VERSION = "2.0.0"
PRODUCT_NAME = "S.E.R.E. Security Suite"
VENDOR = "Mythara Engine"

logger = logging.getLogger(__name__)

# Global flag for graceful shutdown
_shutdown_requested = False

# Application metadata for startup registration
APP_NAME = "SERE_Security"
APP_DESCRIPTION = "S.E.R.E. Enterprise Cybersecurity Platform"


def get_startup_paths():
    """Get relevant paths for startup configuration."""
    script_path = Path(__file__).resolve()
    python_exe = sys.executable
    
    # Windows Startup folder
    if platform.system() == "Windows":
        startup_folder = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
        shortcut_path = startup_folder / f"{APP_NAME}.bat"
        return {
            "script": script_path,
            "python": python_exe,
            "startup_folder": startup_folder,
            "shortcut": shortcut_path,
            "is_windows": True
        }
    else:
        # Linux/Mac - use systemd or launchd (basic support)
        return {
            "script": script_path,
            "python": python_exe,
            "startup_folder": Path.home() / ".config" / "autostart",
            "shortcut": Path.home() / ".config" / "autostart" / f"{APP_NAME}.desktop",
            "is_windows": False
        }


def install_startup() -> bool:
    """Install S.E.R.E. to run on system startup."""
    paths = get_startup_paths()
    
    print(f"[S.E.R.E.] Installing to startup...")
    print(f"[S.E.R.E.] Script: {paths['script']}")
    print(f"[S.E.R.E.] Python: {paths['python']}")
    
    try:
        if paths["is_windows"]:
            # Create a batch file in Windows Startup folder
            paths["startup_folder"].mkdir(parents=True, exist_ok=True)
            
            bat_content = f'''@echo off
title S.E.R.E. Continuous Monitoring
cd /d "{paths['script'].parent}"
"{paths['python']}" "{paths['script']}" --monitor
pause
'''
            paths["shortcut"].write_text(bat_content)
            print(f"[S.E.R.E.] ✓ Startup shortcut created: {paths['shortcut']}")
            
            # Also create a VBS wrapper for silent/background startup
            vbs_path = paths["startup_folder"] / f"{APP_NAME}_silent.vbs"
            vbs_content = f'''Set WshShell = CreateObject("WScript.Shell")
WshShell.Run chr(34) & "{paths['shortcut']}" & chr(34), 0
Set WshShell = Nothing
'''
            vbs_path.write_text(vbs_content)
            print(f"[S.E.R.E.] ✓ Silent launcher created: {vbs_path}")
            
        else:
            # Linux .desktop file
            paths["startup_folder"].mkdir(parents=True, exist_ok=True)
            desktop_content = f'''[Desktop Entry]
Type=Application
Name={APP_NAME}
Comment={APP_DESCRIPTION}
Exec={paths['python']} {paths['script']} --monitor
Terminal=true
Hidden=false
X-GNOME-Autostart-enabled=true
'''
            paths["shortcut"].write_text(desktop_content)
            print(f"[S.E.R.E.] ✓ Autostart entry created: {paths['shortcut']}")
        
        print(f"[S.E.R.E.] ✓ S.E.R.E. will now run on system startup!")
        return True
        
    except Exception as e:
        print(f"[S.E.R.E.] ✗ Failed to install startup: {e}")
        return False


def uninstall_startup() -> bool:
    """Remove S.E.R.E. from system startup."""
    paths = get_startup_paths()
    
    print(f"[S.E.R.E.] Removing from startup...")
    
    try:
        removed = False
        
        if paths["shortcut"].exists():
            paths["shortcut"].unlink()
            print(f"[S.E.R.E.] ✓ Removed: {paths['shortcut']}")
            removed = True
        
        if paths["is_windows"]:
            # Also remove VBS silent launcher
            vbs_path = paths["startup_folder"] / f"{APP_NAME}_silent.vbs"
            if vbs_path.exists():
                vbs_path.unlink()
                print(f"[S.E.R.E.] ✓ Removed: {vbs_path}")
                removed = True
        
        if removed:
            print(f"[S.E.R.E.] ✓ S.E.R.E. removed from startup!")
        else:
            print(f"[S.E.R.E.] No startup entries found to remove.")
        
        return True
        
    except Exception as e:
        print(f"[S.E.R.E.] ✗ Failed to uninstall startup: {e}")
        return False


def check_startup_status() -> bool:
    """Check if S.E.R.E. is installed in startup."""
    paths = get_startup_paths()
    installed = paths["shortcut"].exists()
    
    if installed:
        print(f"[S.E.R.E.] ✓ Startup ENABLED: {paths['shortcut']}")
    else:
        print(f"[S.E.R.E.] ✗ Startup NOT configured")
    
    return installed


def signal_handler(signum, frame):
    """Handle interrupt signals for graceful shutdown."""
    global _shutdown_requested
    _shutdown_requested = True
    print("\n[S.E.R.E.] Shutdown signal received. Completing current cycle...")


# Register signal handlers
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)


def print_splash(use_gui: bool = True, telemetry_provider=None) -> None:
    """
    Display the S.E.R.E. splash screen.
    
    Args:
        use_gui: If True, show graphical splash window. If False, use ASCII fallback.
    """
    # Always try graphical splash first on all platforms (Windows, Linux, Android)
    try:
        from sere_splash import show_splash
        show_splash(duration=3.0, telemetry_provider=telemetry_provider)  # 3 second splash
        return
    except ImportError:
        # sere_splash.py not found, use ASCII fallback
        pass
    except Exception as e:
        # GUI might fail in headless/SSH environments or if tkinter not available
        print(f"[INFO] GUI splash unavailable ({e}), using text mode...")
        pass
    
    # ASCII fallback for terminal-only environments
    _print_ascii_splash()


def _print_ascii_splash() -> None:
    """Display ASCII splash screen (simple loading animation)."""
    import sys
    
    # Clear screen
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Simple loading animation - no complex ASCII art
    loading_chars = ['⣾', '⣽', '⣻', '⢿', '⡿', '⣟', '⣯', '⣷']
    
    try:
        # Show a simple loading spinner with SERE initializing
        os.system('cls' if os.name == 'nt' else 'clear')
        print("\n" * 8)
        print("  " + "═" * 70)
        print()
        
        for i in range(20):
            spinner = loading_chars[i % len(loading_chars)]
            sys.stdout.write(f"\r      {spinner} Initializing S.E.R.E. Security Platform...")
            sys.stdout.flush()
            time.sleep(0.1)
        
        print("\n")
        print("  " + "═" * 70)
        time.sleep(0.3)
        
        os.system('cls' if os.name == 'nt' else 'clear')
        
    except (KeyboardInterrupt, Exception):
        pass  # Skip animation on interrupt or if terminal doesn't support it
    
    # Final static display (always shown)
    print()
    print("  ═══════════════════════════════════════════════════════════════════════")
    print()
    print("  ███████╗███████╗██████╗ ███████╗")
    print("  ██╔════╝██╔════╝██╔══██╗██╔════╝")
    print("  ███████╗█████╗  ██████╔╝█████╗  ")
    print("  ╚════██║██╔══╝  ██╔══██╗██╔══╝  ")
    print("  ███████║███████╗██║  ██║███████╗")
    print("  ╚══════╝╚══════╝╚═╝  ╚═╝╚══════╝")
    print()
    print("       S U R V I V E  •  E V A D E  •  R E S I S T  •  E S C A P E")
    print()
    print(f"   Version {VERSION}  |  Enterprise Cybersecurity Platform  |  Mythara Engine")
    print("   Copyright © 2025 Herbert Velez Jr. All rights reserved.")
    print()
    print("   ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ REAL-TIME PROTECTION ACTIVE ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓")
    print("  ═══════════════════════════════════════════════════════════════════════")
    print()


def print_banner() -> None:
    """Render the S.E.R.E. operational banner."""
    print()
    print("  ╔════════════════════════════════════════════════════════════════╗")
    print("  ║  S.E.R.E. SECURITY SUITE — Enterprise Cybersecurity Platform   ║")
    print("  ║  Real-time Protection • Malware Defense • Network Security     ║")
    print("  ╚════════════════════════════════════════════════════════════════╝")
    print()


def main(argv=None) -> int:
    """
    S.E.R.E. Security Suite - Enterprise Cybersecurity Platform
    
    Main entry point for real-time protection, scanning, and monitoring.
    Competes with McAfee, Norton, Bitdefender.
    """
    argv = list(argv or sys.argv[1:])
    import argparse
    
    parser = argparse.ArgumentParser(
        description='S.E.R.E. Security Suite - Enterprise Cybersecurity Platform',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  sere_bot.py                    Start continuous protection (default)
  sere_bot.py --scan quick       Run quick scan
  sere_bot.py --scan full        Run full system scan
  sere_bot.py --dashboard        Show security dashboard
  sere_bot.py --install-startup  Run on Windows startup
        """
    )

    # Persona selection
    parser.add_argument('--persona', choices=['default', 'gunny'], default='default', help='Select bot persona (default or gunny)')
    

    # Protection modes
    parser.add_argument('--monitor', '-m', action='store_true', 
                        help='Run continuous real-time protection (default)')
    parser.add_argument('--scan', choices=['quick', 'full', 'memory', 'custom'],
                        help='Run a security scan')
    parser.add_argument('--scan-path', type=str,
                        help='Custom path to scan (use with --scan custom)')
    parser.add_argument('--dashboard', '-d', action='store_true',
                        help='Show security dashboard and status')

    # Protection settings
    parser.add_argument('--interval', type=float, default=5.0,
                        help='Seconds between monitoring cycles (default: 5.0)')
    parser.add_argument('--aggressive', action='store_true',
                        help='Enable aggressive protection mode')
    parser.add_argument('--quiet', '-q', action='store_true',
                        help='Minimize output (background mode)')

    # Feature toggles
    parser.add_argument('--no-realtime', action='store_true',
                        help='Disable real-time protection')
    parser.add_argument('--no-firewall', action='store_true',
                        help='Disable firewall monitoring')
    parser.add_argument('--no-ransomware', action='store_true',
                        help='Disable ransomware protection')

    # Quarantine management
    parser.add_argument('--quarantine-list', action='store_true',
                        help='List quarantined items')
    parser.add_argument('--quarantine-restore', type=str,
                        help='Restore item from quarantine by ID')
    parser.add_argument('--quarantine-delete', type=str,
                        help='Permanently delete quarantined item by ID')

    # Network security
    parser.add_argument('--block-ip', type=str,
                        help='Block an IP address')
    parser.add_argument('--unblock-ip', type=str,
                        help='Unblock an IP address')
    parser.add_argument('--network-status', action='store_true',
                        help='Show active network connections')

    # Legacy modes
    # Demo mode removed
    parser.add_argument('--interactive', '-i', action='store_true',
                        help='Run interactive console mode')
    parser.add_argument('--legacy', action='store_true',
                        help='Run legacy S.E.R.E. implementation')
    parser.add_argument('--force', action='store_true',
                        help='Force legacy mode execution')

    # Startup management  
    parser.add_argument('--install-startup', action='store_true',
                        help='Install S.E.R.E. to run on Windows startup')
    parser.add_argument('--uninstall-startup', action='store_true',
                        help='Remove S.E.R.E. from Windows startup')
    parser.add_argument('--startup-status', action='store_true',
                        help='Check if S.E.R.E. is configured for startup')

    # Other
    parser.add_argument('--version', '-v', action='store_true',
                        help='Show version information')
    parser.add_argument('--no-gui', action='store_true',
                        help='Use ASCII splash instead of graphical window')
    parser.add_argument('--no-splash', action='store_true',
                        help='Skip splash screen entirely')
    parser.add_argument('--stream', action='store_true', help='Legacy: streaming mode')
    parser.add_argument('--cycle-modes', choices=SUPPORTED_MODES, nargs='+', help='Cycle through modes')
    parser.add_argument('--interdependent', action='store_true', help='Legacy: interdependent mode')

    try:
        args = parser.parse_args(argv)
    except Exception as e:
        print("[ERROR] An exception occurred in SERE_Security:", e)
        import traceback
        traceback.print_exc()
        with open("sere_error.log", "w") as logf:
            logf.write(traceback.format_exc())
        return 1

    engine = None
    try:
        from sere_security_engine import SERESecurityEngine, ProtectionStatus
        engine = SERESecurityEngine()
        if args.no_realtime:
            engine.disable_real_time_protection()
        if args.no_firewall and engine:
            engine.firewall_enabled = False
        if args.no_ransomware and engine:
            engine.ransomware_protection = False
        if args.aggressive and engine:
            engine.protection_status = ProtectionStatus.AGGRESSIVE
    except ImportError as e:
        logger.error(f"Security engine not available: {e}")
        print("[ERROR] S.E.R.E. Security Engine not found. Falling back to legacy mode.")
        engine = None

    # Show splash unless --no-splash is set
    if not getattr(args, 'no_splash', False):
        use_gui = not getattr(args, 'no_gui', False)
        telemetry_provider = (lambda: engine.get_dashboard_summary()) if engine else None
        print_splash(use_gui=use_gui, telemetry_provider=telemetry_provider)

    # Handle startup management commands first
    if args.install_startup:
        return 0 if install_startup() else 1
    if args.uninstall_startup:
        return 0 if uninstall_startup() else 1
    if args.startup_status:
        check_startup_status()
        return 0

    # After splash and keypress, always show interactive menu if not in a special mode
    if not (args.scan or args.dashboard or args.install_startup or args.uninstall_startup or args.startup_status or args.quarantine_list or args.quarantine_restore or args.quarantine_delete or args.block_ip or args.unblock_ip or args.network_status or args.interactive or args.legacy or args.force):
        return interactive_dashboard_menu(engine)

# --- INTERACTIVE MENU WITH ARROW KEYS ---
def interactive_dashboard_menu(engine):
    import sys
    import os
    import platform
    import time
    
    # Cross-platform keyboard input handling
    def getch():
        """Cross-platform single character input."""
        if os.name == 'nt':
            try:
                import msvcrt
                return msvcrt.getch()
            except ImportError:
                # Fallback to input on Windows if msvcrt not available
                return input("Press Enter to continue...").encode()
        else:
            # Unix/Linux - use termios for single character input
            try:
                import tty
                import termios
                fd = sys.stdin.fileno()
                old_settings = termios.tcgetattr(fd)
                try:
                    tty.setraw(sys.stdin.fileno())
                    ch = sys.stdin.read(1).encode()
                finally:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                return ch
            except (ImportError, AttributeError):
                # Fallback to input if termios not available
                return input("Press Enter to continue...").encode()

    def is_admin():
        if os.name == 'nt':
            import ctypes
            try:
                return ctypes.windll.shell32.IsUserAnAdmin() != 0
            except Exception:
                return False
        return os.geteuid() == 0

    # Use persona for menu responses
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--persona', choices=['default', 'gunny'], default='default')
    args, _ = parser.parse_known_args()
    persona = get_persona(args)
    menu = [
        ("Start Real-Time Protection", lambda: print(persona.line('greet')) or run_continuous_protection(engine, 5.0, False)),
        ("Run Quick Scan", lambda: print(persona.line('scan_complete')) or run_scan(engine, 'quick', None, False)),
        ("Show Dashboard", lambda: print(persona.line('clear')) or show_dashboard(engine)),
        ("Quarantine Management", "admin_quarantine"),
        ("Threat Analysis", "admin_threats"),
        ("Exit", lambda: 0)
    ]
    selected = 0
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("\n  ╔════════════════════════════════════════════════════════════════╗")
        print("  ║                  S.E.R.E. SECURITY DASHBOARD                ║")
        print("  ╚════════════════════════════════════════════════════════════════╝\n")
        for i, (label, action) in enumerate(menu):
            prefix = "=>" if i == selected else "  "
            print(f"  {prefix} {label}")
        print("\n  Use ↑/↓ arrows to move, Enter to select.")
        # Read key (cross-platform)
        key = getch()
        if key in (b'\x00', b'\xe0'):
            key2 = getch()
            if key2 == b'H':  # Up
                selected = (selected - 1) % len(menu)
            elif key2 == b'P':  # Down
                selected = (selected + 1) % len(menu)
        elif key == b'\r' or key == b'\n':  # Enter (Windows and Unix)
            label, action = menu[selected]
            if action == "admin_quarantine":
                # Quarantine menu (list, restore, delete)
                print("\n  [Quarantine Management]")
                try:
                    items = engine.get_quarantine_list()
                    if not items:
                        print("  [QUARANTINE] No items in quarantine.")
                    else:
                        print("  [QUARANTINE] Items:")
                        for i, item in enumerate(items, 1):
                            print(f"    {i}. {item}")
                except Exception as e:
                    print(f"  [ERROR] Could not retrieve quarantine list: {e}")
                input("  Press Enter to return to menu...")
                continue
            elif action == "admin_threats":
                print("\n  [Threat Analysis]")
                try:
                    threats = getattr(engine, 'get_detected_threats', lambda: [])()
                    if not threats:
                        print("  [THREATS] No threats detected.")
                    else:
                        print("  [THREATS] Detected:")
                        for i, threat in enumerate(threats, 1):
                            print(f"    {i}. {threat}")
                except Exception as e:
                    print(f"  [ERROR] Could not retrieve threats: {e}")
                input("  Press Enter to return to menu...")
                continue
            else:
                result = action()
                print("\n  Press any key to return to menu...")
                getch()
                if label == "Exit":
                    return result

    # ═══════════════════════════════════════════════════════════════════════════
    # QUARANTINE MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    if args.quarantine_list:
        if engine:
            items = engine.get_quarantine_list()
            if not items:
                print("[QUARANTINE] No items in quarantine.")
            else:
                print(f"\n[QUARANTINE] {len(items)} item(s):\n")
                for item in items:
                    print(f"  ID: {item.item_id}")
                    print(f"  Original: {item.original_path}")
                    print(f"  Threat: {item.threat.category.value}")
                    print(f"  Quarantined: {item.quarantine_time}")
                    print()
        return 0
    
    if args.quarantine_restore:
        if engine:
            if engine.restore_from_quarantine(args.quarantine_restore):
                print(f"[OK] Restored item {args.quarantine_restore}")
            else:
                print(f"[ERROR] Failed to restore {args.quarantine_restore}")
        return 0
    
    if args.quarantine_delete:
        if engine:
            if engine.delete_quarantined(args.quarantine_delete):
                print(f"[OK] Deleted item {args.quarantine_delete}")
            else:
                print(f"[ERROR] Failed to delete {args.quarantine_delete}")
        return 0

    # ═══════════════════════════════════════════════════════════════════════════
    # NETWORK SECURITY
    # ═══════════════════════════════════════════════════════════════════════════
    
    if args.block_ip:
        if engine:
            engine.block_ip(args.block_ip, reason="Manual block via CLI")
            print(f"[FIREWALL] Blocked IP: {args.block_ip}")
        return 0
    
    if args.unblock_ip:
        if engine:
            engine.unblock_ip(args.unblock_ip)
            print(f"[FIREWALL] Unblocked IP: {args.unblock_ip}")
        return 0
    
    if args.network_status:
        if engine:
            print("\n[NETWORK] Active Connections:\n")
            connections = engine.get_network_connections()
            for conn in connections[:20]:  # Limit output
                risk_icon = "⚠️" if conn.risk_level.value >= 2 else "✓"
                print(f"  {risk_icon} {conn.process_name:20} {conn.remote_addr}:{conn.remote_port} [{conn.status}]")
            print(f"\n  Total: {len(connections)} connections")
        return 0

    # ═══════════════════════════════════════════════════════════════════════════
    # DASHBOARD
    # ═══════════════════════════════════════════════════════════════════════════
    
    if args.dashboard:
        if engine:
            return show_dashboard(engine)
        return 0

    # ═══════════════════════════════════════════════════════════════════════════
    # SCANNING
    # ═══════════════════════════════════════════════════════════════════════════
    
    if args.scan:
        if engine:
            return run_scan(engine, args.scan, args.scan_path, args.quiet)
        return 0       
    # ═══════════════════════════════════════════════════════════════════════════
    # LEGACY MODES (for backwards compatibility)
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Demo mode removed
    
    if args.interactive:
        return run_interactive_mode(engine)
    
    if args.legacy or args.force:
        return run_legacy_mode()

    # ═══════════════════════════════════════════════════════════════════════════
    # DEFAULT: CONTINUOUS REAL-TIME PROTECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    return run_continuous_protection(engine, args.interval, args.quiet)


# ═══════════════════════════════════════════════════════════════════════════════
# ENTERPRISE SECURITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def show_dashboard(engine) -> int:
    """Display the security dashboard."""
    dashboard = engine.get_dashboard_summary()
    
    print()
    print("  ╔════════════════════════════════════════════════════════════════╗")
    print("  ║               S.E.R.E. SECURITY DASHBOARD                      ║")
    print("  ╚════════════════════════════════════════════════════════════════╝")
    print()
    
    # Status & Score
    status_color = "🟢" if dashboard['score'] >= 80 else "🟡" if dashboard['score'] >= 50 else "🔴"
    print(f"  {status_color} PROTECTION STATUS: {dashboard['status']}")
    print(f"  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print()
    
    # Security Score Bar
    score = dashboard['score']
    bar_filled = int(score / 5)
    bar_empty = 20 - bar_filled
    bar = "█" * bar_filled + "░" * bar_empty
    print(f"  Security Score: [{bar}] {score}/100")
    print()
    
    # Protection Features
    print("  ┌─────────────────────────────────────────────────────────────────┐")
    print("  │ PROTECTION FEATURES                                            │")
    print("  ├─────────────────────────────────────────────────────────────────┤")
    p = dashboard['protection']
    print(f"  │  {'✓' if p['real_time'] else '✗'} Real-Time Protection    {'✓' if p['firewall'] else '✗'} Firewall Monitoring        │")
    print(f"  │  {'✓' if p['web_protection'] else '✗'} Web Protection         {'✓' if p['ransomware'] else '✗'} Ransomware Shield          │")
    print("  └─────────────────────────────────────────────────────────────────┘")
    print()
    
    # Threat Summary
    t = dashboard['threats']
    print("  ┌─────────────────────────────────────────────────────────────────┐")
    print("  │ THREAT SUMMARY                                                  │")
    print("  ├─────────────────────────────────────────────────────────────────┤")
    print(f"  │  Active Threats: {t['active']:3}     Quarantined: {t['quarantined']:3}     Blocked: {t['total_blocked']:5}  │")
    print("  └─────────────────────────────────────────────────────────────────┘")
    print()
    
    # System Resources
    s = dashboard['system']
    print("  ┌─────────────────────────────────────────────────────────────────┐")
    print("  │ SYSTEM RESOURCES                                                │")
    print("  ├─────────────────────────────────────────────────────────────────┤")
    cpu_bar = "█" * int(s['cpu'] / 10) + "░" * (10 - int(s['cpu'] / 10))
    mem_bar = "█" * int(s['memory'] / 10) + "░" * (10 - int(s['memory'] / 10))
    disk_bar = "█" * int(s['disk'] / 10) + "░" * (10 - int(s['disk'] / 10))
    print(f"  │  CPU:    [{cpu_bar}] {s['cpu']:5.1f}%                              │")
    print(f"  │  Memory: [{mem_bar}] {s['memory']:5.1f}%                              │")
    print(f"  │  Disk:   [{disk_bar}] {s['disk']:5.1f}%                              │")
    print("  └─────────────────────────────────────────────────────────────────┘")
    print()
    
    # Definitions
    d = dashboard['definitions']
    print(f"  Definitions: {d['version']} ({d['date'][:10]})")
    if dashboard['last_scan']:
        print(f"  Last Scan: {dashboard['last_scan'][:19]}")
    else:
        print("  Last Scan: Never - Run a scan now!")
    print()
    
    return 0


def run_scan(engine, scan_type: str, scan_path: Optional[str], quiet: bool) -> int:
    """Run a security scan."""
    from sere_security_engine import ScanType
    
    type_map = {
        'quick': ScanType.QUICK,
        'full': ScanType.FULL,
        'memory': ScanType.MEMORY,
        'custom': ScanType.CUSTOM
    }
    
    st = type_map.get(scan_type, ScanType.QUICK)
    paths = [scan_path] if scan_path else None
    
    print()
    print(f"  ╔════════════════════════════════════════════════════════════════╗")
    print(f"  ║  S.E.R.E. {st.value.upper():^50} ║")
    print(f"  ╚════════════════════════════════════════════════════════════════╝")
    print()
    
    result = engine.start_scan(st, paths)
    
    print(f"  Scan ID: {result.scan_id}")
    print(f"  Started: {result.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    print("  Scanning", end="", flush=True)
    
    # Wait for scan to complete with progress indicator
    while result.status == "running":
        time.sleep(0.5)
        if not quiet:
            print(".", end="", flush=True)
    
    print(" Done!")
    print()
    
    # Results
    print("  ┌─────────────────────────────────────────────────────────────────┐")
    print("  │ SCAN RESULTS                                                    │")
    print("  ├─────────────────────────────────────────────────────────────────┤")
    print(f"  │  Files Scanned:    {result.files_scanned:>10,}                              │")
    print(f"  │  Threats Found:    {result.threats_found:>10}                              │")
    print(f"  │  Threats Cleaned:  {result.threats_cleaned:>10}                              │")
    print(f"  │  Items Quarantined:{result.threats_quarantined:>10}                              │")
    print(f"  │  Scan Status:      {result.status:>10}                              │")
    print("  └─────────────────────────────────────────────────────────────────┘")
    print()
    
    # Show detected threats
    if result.detected_threats:
        print("  ⚠️  THREATS DETECTED:")
        for threat in result.detected_threats[:10]:
            print(f"      • {threat.category.value} | {threat.severity.name} | {threat.location}")
        if len(result.detected_threats) > 10:
            print(f"      ... and {len(result.detected_threats) - 10} more")
    else:
        print("  ✓ No threats detected. Your system is clean!")
    
    print()
    return 0


def run_continuous_protection(engine, interval: float, quiet: bool) -> int:
    """
    Run S.E.R.E. in continuous real-time protection mode.
    Enterprise-grade monitoring that competes with McAfee/Norton.
    """
    global _shutdown_requested
    _shutdown_requested = False
    
    print_banner()
    print("  ╔════════════════════════════════════════════════════════════════╗")
    print("  ║       REAL-TIME PROTECTION ACTIVE - ENTERPRISE MODE           ║")
    print("  ╚════════════════════════════════════════════════════════════════╝")
    print()
    print(f"  [CONFIG] Scan Interval: {interval}s | Mode: CONTINUOUS")
    print(f"  [CONFIG] Real-Time: ON | Firewall: ON | Ransomware Shield: ON")
    print(f"  [CONFIG] Press Ctrl+C to stop protection (not recommended)")
    print()
    print("  " + "─" * 64)
    
    cycle_count = 0
    total_threats = 0
    session_start = datetime.datetime.now()
    
    try:
        while not _shutdown_requested:
            cycle_count += 1
            timestamp = datetime.datetime.now().strftime("%H:%M:%S")
            if not quiet:
                print(f"\n  [{timestamp}] ══════ PROTECTION CYCLE {cycle_count} ══════")
            findings = engine.run_monitoring_cycle()
            process_alerts = findings.get('process_alerts', [])
            network_alerts = findings.get('network_alerts', [])
            health = findings.get('system_health', {})
            if process_alerts or network_alerts:
                threat_count = len(process_alerts) + len(network_alerts)
                total_threats += threat_count
                if not quiet:
                    print(f"  ⚠️  {threat_count} ALERT(S) DETECTED!")
                    for alert in process_alerts:
                        print(f"      [PROCESS] {alert['category']} | {alert['severity']}")
                    for alert in network_alerts:
                        print(f"      [NETWORK] {alert['remote']}:{alert['port']} via {alert['process']}")
            else:
                if not quiet:
                    print(f"  ✓ System secure. Score: {health.get('score', 100)}/100")
            if not quiet:
                active = health.get('active_threats', 0)
                status = health.get('status', 'Protected')
                print(f"  [STATUS] {status} | Active Threats: {active} | Session Threats: {total_threats}")
            if not _shutdown_requested:
                sleep_remaining = interval
                while sleep_remaining > 0 and not _shutdown_requested:
                    sleep_chunk = min(0.5, sleep_remaining)
                    time.sleep(sleep_chunk)
                    sleep_remaining -= sleep_chunk
    except KeyboardInterrupt:
        print("\n  [INFO] Ctrl+C detected. Halting protection and returning to menu...")
        time.sleep(1)
        # Return to interactive menu
        from sys import modules
        if 'interactive_dashboard_menu' in modules[__name__].__dict__:
            return modules[__name__].__dict__['interactive_dashboard_menu'](engine)
        else:
            # fallback: just return 0
            return 0
    session_duration = datetime.datetime.now() - session_start
    hours, remainder = divmod(int(session_duration.total_seconds()), 3600)
    minutes, seconds = divmod(remainder, 60)
    print()
    print("  ╔════════════════════════════════════════════════════════════════╗")
    print("  ║              PROTECTION SESSION ENDED                          ║")
    print("  ╚════════════════════════════════════════════════════════════════╝")
    print()
    print(f"  Session Duration:  {hours:02d}:{minutes:02d}:{seconds:02d}")
    print(f"  Protection Cycles: {cycle_count:,}")
    print(f"  Threats Detected:  {total_threats:,}")
    print(f"  Session Ended:     {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    print("  ⚠️  WARNING: Real-time protection is now DISABLED")
    print("     Restart S.E.R.E. to resume protection")
    print()
    return 0


    # Demo mode function removed


def run_interactive_mode(engine) -> int:
    """Run S.E.R.E. in interactive console mode."""
    print_banner()
    print("  S.E.R.E. INTERACTIVE SECURITY CONSOLE")
    print("  Type 'help' for available commands")
    print()
    
    def show_help():
        print("""
  Available Commands:
  ─────────────────────────────────────────────────────────────────
  dashboard, status    - Show security dashboard
  scan quick           - Run quick scan
  scan full            - Run full system scan
  threats              - List active threats
  quarantine           - Show quarantined items
  network              - Show network connections
  processes            - Show running processes
  block <ip>           - Block an IP address
  unblock <ip>         - Unblock an IP address
  health               - Show system health
  events               - Show recent security events
  help                 - Show this help
  exit, quit           - Exit interactive mode
  ─────────────────────────────────────────────────────────────────
        """)
    
    while True:
        try:
            cmd = input('  S.E.R.E.> ').strip().lower()
        except (EOFError, KeyboardInterrupt):
            print('\n  Exiting interactive mode.')
            return 0
        
        if not cmd or cmd in ['help', '?']:
            show_help()
            continue
        
        if cmd in ['exit', 'quit', 'q']:
            print('  Exiting interactive mode.')
            return 0
        
        if cmd in ['dashboard', 'status', 'd', 's']:
            show_dashboard(engine)
            continue
        
        if cmd.startswith('scan'):
            parts = cmd.split()
            scan_type = parts[1] if len(parts) > 1 else 'quick'
            run_scan(engine, scan_type, None, False)
            continue
        
        if cmd in ['threats', 't']:
            threats = engine.detected_threats
            if not threats:
                print("  No active threats.")
            else:
                print(f"\n  Active Threats ({len(threats)}):")
                for t in threats[-10:]:
                    print(f"    • {t.threat_id} | {t.category.value} | {t.severity.name}")
            print()
            continue
        
        if cmd in ['quarantine', 'q']:
            items = engine.get_quarantine_list()
            if not items:
                print("  Quarantine is empty.")
            else:
                print(f"\n  Quarantined Items ({len(items)}):")
                for item in items:
                    print(f"    • {item.item_id} | {item.original_path}")
            print()
            continue
        
        if cmd in ['network', 'net', 'n']:
            connections = engine.get_network_connections()
            print(f"\n  Active Connections ({len(connections)}):")
            for conn in connections[:15]:
                risk = "⚠️" if conn.risk_level.value >= 2 else "✓"
                print(f"    {risk} {conn.process_name:15} → {conn.remote_addr}:{conn.remote_port}")
            print()
            continue
        
        if cmd in ['processes', 'proc', 'ps']:
            procs = engine.get_process_list()
            print(f"\n  Running Processes ({len(procs)}):")
            for p in sorted(procs, key=lambda x: x['cpu'], reverse=True)[:15]:
                trust = "⚠️" if p['trust_level'] == 'suspicious' else "✓"
                print(f"    {trust} {p['name']:20} CPU: {p['cpu']:5.1f}%  MEM: {p['memory']:5.1f}%")
            print()
            continue
        
        if cmd.startswith('block '):
            ip = cmd.split()[1]
            engine.block_ip(ip, "Manual block via console")
            print(f"  ✓ Blocked IP: {ip}")
            continue
        
        if cmd.startswith('unblock '):
            ip = cmd.split()[1]
            engine.unblock_ip(ip)
            print(f"  ✓ Unblocked IP: {ip}")
            continue
        
        if cmd in ['health', 'h']:
            health = engine.get_system_health()
            print(f"\n  System Health Score: {health.overall_score}/100")
            print(f"  CPU: {health.cpu_usage:.1f}% | Memory: {health.memory_usage:.1f}% | Disk: {health.disk_usage:.1f}%")
            print(f"  Protection: {health.protection_status.value}")
            print()
            continue
        
        if cmd in ['events', 'log', 'e']:
            events = engine.get_event_log(20)
            print(f"\n  Recent Security Events:")
            for e in events:
                print(f"    [{e['time'][:19]}] {e['type']}: {e['details']}")
            print()
            continue
        
        print(f"  Unknown command: {cmd}. Type 'help' for options.")


def run_legacy_mode() -> int:
    """Run legacy S.E.R.E. implementation."""
    legacy_path = Path(__file__).with_name('sere_bot_broken.py')
    if not legacy_path.exists():
        print(f"[ERROR] Legacy file not found: {legacy_path}")
        return 1
    
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("sere_bot_legacy", legacy_path)
        mod = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(mod)
        
        if hasattr(mod, "main"):
            return mod.main() or 0
    except Exception as e:
        logger.error(f"Failed to run legacy mode: {e}")
    
    # Fallback to subprocess
    try:
        return subprocess.call([sys.executable, str(legacy_path)])
    except Exception as e:
        logger.error(f"Legacy subprocess failed: {e}")
        return 1


import sys
import traceback

def excepthook(type, value, tb):
    traceback.print_exception(type, value, tb)
    sys.exit(1)

sys.excepthook = excepthook


if __name__ == '__main__':
    import datetime
    import sys
    import os

    # Ensure mythara/core and mythara/bots are importable regardless of how
    # this script was launched (direct python call or via SERE.bat wrapper).
    _repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for _p in (
        os.path.join(_repo_root, 'mythara', 'core'),
        os.path.join(_repo_root, 'mythara', 'bots'),
        _repo_root,
    ):
        if _p not in sys.path:
            sys.path.insert(0, _p)

    def log_status(msg):
        try:
            with open("sere_status.log", "a") as f:
                f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n")
        except Exception:
            pass

    # ── Dependency preflight ──────────────────────────────────────────────────
    # Probe optional modules and collect degraded-feature warnings so the user
    # sees a clear per-feature notice instead of a silent full fallback.
    _dep_warnings: list = []

    def _probe(module_name: str, feature_label: str) -> bool:
        try:
            __import__(module_name)
            return True
        except ImportError:
            _dep_warnings.append(f"  • {feature_label}  ← {module_name} not installed")
            return False

    _probe('speech_recognition', 'Voice recognition input')
    _probe('pyttsx3',            'Text-to-speech (Gunny voice TTS)')

    def _show_dep_warning_dialog(warnings: list) -> None:
        """Display a non-blocking Tkinter dialog listing disabled features."""
        try:
            import tkinter as tk
            from tkinter import ttk
            root = tk.Tk()
            root.withdraw()
            win = tk.Toplevel(root)
            win.title("S.E.R.E. — Optional Features Unavailable")
            win.configure(bg='#0b1214')
            win.resizable(False, False)
            try:
                win.iconbitmap('')
            except Exception:
                pass
            tk.Label(
                win, text="S.E.R.E. PREFLIGHT CHECK",
                font=('Consolas', 14, 'bold'), fg='#4ef5c5', bg='#0b1214'
            ).pack(padx=24, pady=(18, 6), anchor='w')
            tk.Label(
                win,
                text="Some optional packages are missing.\n"
                     "The features below are disabled — core protection is unaffected.",
                font=('Consolas', 10), fg='#c0d8d4', bg='#0b1214', justify='left'
            ).pack(padx=24, pady=(0, 10), anchor='w')
            for w in warnings:
                tk.Label(
                    win, text=w,
                    font=('Consolas', 10), fg='#f4e285', bg='#0b1214', justify='left'
                ).pack(padx=32, anchor='w')
            tk.Label(
                win,
                text="\nRun:  pip install pyttsx3 SpeechRecognition\nto restore full functionality.",
                font=('Consolas', 9), fg='#46b7aa', bg='#0b1214', justify='left'
            ).pack(padx=24, pady=(10, 0), anchor='w')
            ttk.Button(win, text="Continue", command=lambda: (win.destroy(), root.destroy())).pack(pady=16)
            win.update_idletasks()
            # Center on screen
            w_px = win.winfo_reqwidth(); h_px = win.winfo_reqheight()
            sw = win.winfo_screenwidth(); sh = win.winfo_screenheight()
            win.geometry(f"+{(sw - w_px) // 2}+{(sh - h_px) // 2}")
            win.grab_set()
            win.focus_force()
            root.wait_window(win)
        except Exception:
            # Tkinter not available — fall back to console output
            print("[PREFLIGHT] Optional features disabled:")
            for w in warnings:
                print(w)

    def _show_gui_error_dialog(err_msg: str) -> None:
        """Display a Tkinter error dialog when the GUI fails to load."""
        try:
            import tkinter as tk
            from tkinter import messagebox
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(
                "S.E.R.E. — GUI Load Failure",
                f"The tactical GUI could not start:\n\n{err_msg}\n\n"
                "S.E.R.E. will fall back to terminal mode.\n"
                "Run the app from a terminal window for full interactivity.",
                parent=root
            )
            root.destroy()
        except Exception:
            print(f"[ERROR] GUI failed: {err_msg}")

    # Show preflight dialog only if there are warnings and GUI mode is active
    if _dep_warnings and '--terminal' not in sys.argv and '--cli' not in sys.argv:
        _show_dep_warning_dialog(_dep_warnings)

    # ── GUI launch ────────────────────────────────────────────────────────────
    # ALWAYS launch JARVIS-style GUI by default (no flag needed).
    # Only use terminal mode if --terminal or --cli flag is explicitly provided.
    if '--terminal' not in sys.argv and '--cli' not in sys.argv:
        try:
            from sere_desktop_gui import SEREDesktopGUI
            log_status("Launching JARVIS-style GUI interface...")
            app = SEREDesktopGUI()
            app.run()
            sys.exit(0)
        except ImportError as e:
            err = str(e)
            log_status(f"GUI import failed: {err}, using terminal mode")
            _show_gui_error_dialog(err)
        except Exception as e:
            err = str(e)
            log_status(f"GUI crashed: {err}, using terminal mode")
            _show_gui_error_dialog(err)

    # ── Terminal mode ─────────────────────────────────────────────────────────
    # Only reached when --terminal/--cli is passed, or GUI failed.
    try:
        log_status("SERE_Security starting terminal mode...")
        exit_code = main()
        log_status(f"SERE_Security exited with code {exit_code}.")
    except Exception as e:
        import traceback
        print("[FATAL ERROR] SERE_Security crashed:", e)
        traceback.print_exc()
        with open("sere_error.log", "w") as logf:
            logf.write(traceback.format_exc())
        log_status(f"[FATAL ERROR] {e}\n" + traceback.format_exc())
        exit_code = 1
    raise SystemExit(exit_code)
