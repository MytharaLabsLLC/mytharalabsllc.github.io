"""
SERE AI Engine — Ollama LLM backend + autonomous tool execution.

Copyright © 2025 Herbert Velez Jr. All rights reserved.
Proprietary and Confidential.
"""

import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests

log = logging.getLogger("sere.ai")

OLLAMA_BASE      = "http://localhost:11434"
DEFAULT_MODEL    = "llama3.2"
REQUEST_TIMEOUT  = 120   # seconds — generous for slow local inference
SCRIPT_TIMEOUT   = 30    # seconds for subprocess execution
MAX_TOOL_HOPS    = 5     # max recursive tool-calls per query
HISTORY_DEPTH    = 20    # conversation turns to keep

GUNNY_SYSTEM_PROMPT = """\
You are SERE-AI, the autonomous intelligence core of the SERE cybersecurity system — \
part of the Mythara suite.

PERSONA: Staff Sergeant "Gunny" — hardened, direct, mission-focused. Military precision. \
No fluff. No apologies. Every answer is a report.

MODE: REAL OPS. Simulation permanently disabled. Every action is live and immediate.
PLATFORM: Windows. Mythara 5-Level Safety Hierarchy governs all aggressive actions.
DATETIME: {datetime}

CAPABILITIES — use tools proactively when the user asks to DO something:
 • Threat analysis, prioritization, and escalation
 • Process and network forensics
 • Autonomous Python script generation and execution
 • Windows Firewall rule management via netsh
 • Full 6-phase integrity sweep (file hashes → quarantine → incident playbook)
 • Log analysis and structured threat reports

RULES:
 1. When asked to perform an action, call the appropriate tool — do not just explain it.
 2. When generating Python code, always wrap it in ```python ... ``` code blocks.
 3. After each tool call, briefly state what was found and what you did next.
 4. If a threat is CRITICAL severity, escalate immediately — no hesitation.
 5. Be concise. Mission-briefing format. Bullet points for lists.
"""

# ─── Tool Schema ──────────────────────────────────────────────────────────────

TOOL_SCHEMA: List[Dict] = [
    {
        "type": "function",
        "function": {
            "name": "get_system_status",
            "description": (
                "Get SERE engine health, protection metrics, CPU/RAM/disk usage, "
                "and current operational mode."
            ),
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_threats",
            "description": (
                "List all currently detected threats with threat ID, severity, "
                "category, and source."
            ),
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_processes",
            "description": "List running system processes sorted by CPU usage.",
            "parameters": {
                "type": "object",
                "properties": {
                    "top_n": {
                        "type": "integer",
                        "description": "How many top processes to return (default 20).",
                        "default": 20,
                    }
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_network",
            "description": (
                "List active established network connections with remote IPs, "
                "ports, and associated PIDs."
            ),
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_integrity_sweep",
            "description": (
                "Trigger a full 6-phase integrity sweep: file hash scan → process "
                "anomaly scan → network anomaly scan → HyperWatch deep scan → "
                "auto-quarantine → incident investigation playbook."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "auto_quarantine": {
                        "type": "boolean",
                        "description": "Automatically quarantine detected threats.",
                        "default": True,
                    }
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "quarantine_pid",
            "description": "Quarantine (terminate + isolate) a process by its PID.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pid": {
                        "type": "integer",
                        "description": "Process ID to quarantine.",
                    },
                    "reason": {
                        "type": "string",
                        "description": "Reason for quarantine (logged).",
                    },
                },
                "required": ["pid"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "block_ip",
            "description": (
                "Add Windows Firewall block rules (inbound + outbound) for an IP "
                "address using netsh advfirewall."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "ip": {
                        "type": "string",
                        "description": "IP address to block.",
                    },
                    "reason": {
                        "type": "string",
                        "description": "Reason for the block (logged in rule description).",
                    },
                },
                "required": ["ip"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "analyze_logs",
            "description": (
                "Read the SERE operational log file and return recent entries "
                "for analysis."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "tail_lines": {
                        "type": "integer",
                        "description": "Number of recent lines to return (default 100).",
                        "default": 100,
                    }
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "generate_threat_report",
            "description": (
                "Generate a structured threat intelligence report of current system "
                "state: health, metrics, and all detected threats."
            ),
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "execute_script",
            "description": (
                "Execute a Python script and return stdout/stderr. Use this to run "
                "security automation tasks. Always show the code to the user first."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "Python source code to execute.",
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Execution timeout in seconds (default 30).",
                        "default": 30,
                    },
                },
                "required": ["code"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "apply_firewall_config",
            "description": (
                "Apply a set of Windows Firewall rules from a JSON config. "
                "Each rule: {name, direction (in/out), action (block/allow), "
                "remoteip, protocol (optional)}."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "rules": {
                        "type": "array",
                        "description": "List of firewall rule objects to apply.",
                        "items": {"type": "object"},
                    }
                },
                "required": ["rules"],
            },
        },
    },
]

# ─── Data Classes ─────────────────────────────────────────────────────────────

@dataclass
class ToolCall:
    name:   str
    args:   Dict[str, Any]
    result: str = ""
    error:  str = ""


@dataclass
class AgentResult:
    text:          str
    tool_calls:    List[ToolCall]   = field(default_factory=list)
    code_blocks:   List[str]        = field(default_factory=list)
    error:         Optional[str]    = None
    model_used:    str              = ""
    ollama_online: bool             = True


# ─── Ollama Client ────────────────────────────────────────────────────────────

class OllamaClient:
    """HTTP client for the Ollama local inference server."""

    def __init__(self, base_url: str = OLLAMA_BASE, model: str = DEFAULT_MODEL):
        self.base_url = base_url.rstrip("/")
        self.model    = model
        self._online: Optional[bool] = None

    def probe(self) -> bool:
        """Check Ollama availability. Returns True if server is running."""
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=5)
            self._online = r.status_code == 200
        except Exception as exc:
            log.debug("Ollama probe failed: %s", exc)
            self._online = False
        return bool(self._online)

    def get_models(self) -> List[str]:
        """Return sorted list of available model names."""
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=5)
            r.raise_for_status()
            return sorted(m["name"] for m in r.json().get("models", []))
        except Exception:
            return []

    def chat(
        self,
        messages: List[Dict],
        tools: Optional[List[Dict]] = None,
        timeout: int = REQUEST_TIMEOUT,
    ) -> Dict:
        """
        POST /api/chat and return the parsed response dict.
        Raises RuntimeError on failure.
        """
        payload: Dict[str, Any] = {
            "model":    self.model,
            "messages": messages,
            "stream":   False,
        }
        if tools:
            payload["tools"] = tools

        try:
            r = requests.post(
                f"{self.base_url}/api/chat",
                json=payload,
                timeout=timeout,
            )
            r.raise_for_status()
            self._online = True
            return r.json()
        except requests.exceptions.ConnectionError as exc:
            self._online = False
            raise RuntimeError(f"Ollama unreachable: {exc}") from exc
        except Exception as exc:
            raise RuntimeError(f"Ollama request failed: {exc}") from exc

    @property
    def is_online(self) -> bool:
        if self._online is None:
            self.probe()
        return bool(self._online)


# ─── Tool Registry ────────────────────────────────────────────────────────────

class SEREToolRegistry:
    """
    Implements all tool functions available to SERE-AI.
    Each public method named `tool_<name>` maps to a tool in TOOL_SCHEMA.
    """

    def __init__(self, engine, log_path: Optional[Path] = None,
                 confirm_callback=None, allow_unattended: bool = False):
        self.engine   = engine
        self.log_path = log_path or (Path(os.getcwd()) / "sere_status.log")
        # Human confirmation gate (2026-11-23): dangerous tools (script
        # execution, PID quarantine, IP blocks, firewall writes) fail closed
        # unless a confirmation channel approves them, or the owner has
        # explicitly enabled unattended operation. Every decision is audited.
        self.confirm_callback  = confirm_callback
        self.allow_unattended  = allow_unattended

    def _audit(self, action: str, detail: str, outcome: str) -> None:
        try:
            ts = datetime.now().isoformat(timespec="seconds")
            with open(self.log_path, "a", encoding="utf-8") as fh:
                fh.write(f"{ts} [AI-GATE] {action} | {detail} | {outcome}\n")
        except Exception:
            pass

    def _gate(self, action: str, detail: str) -> bool:
        """Return True only if a human (or an explicit owner opt-in) approves."""
        if self.confirm_callback is not None:
            try:
                ok = bool(self.confirm_callback(action, detail))
            except Exception:
                ok = False
            self._audit(action, detail, "CONFIRMED" if ok else "DECLINED")
            return ok
        if self.allow_unattended:
            self._audit(action, detail, "UNATTENDED-ALLOWED")
            return True
        self._audit(action, detail, "BLOCKED-NO-CONFIRMATION-CHANNEL")
        return False

    def dispatch(self, name: str, args: Dict[str, Any]) -> str:
        """Dispatch a tool call by name. Returns result string."""
        handler = getattr(self, f"tool_{name}", None)
        if handler is None:
            return f"[ERROR] Unknown tool: '{name}'"
        try:
            return str(handler(**args))
        except TypeError as exc:
            return f"[ERROR] Bad arguments for {name}: {exc}"
        except Exception as exc:
            log.exception("Tool %s raised an error", name)
            return f"[ERROR] {name} failed — {type(exc).__name__}: {exc}"

    # ── Tools ─────────────────────────────────────────────────────────────────

    def tool_get_system_status(self) -> str:
        try:
            status  = self.engine.get_protection_status()
            health  = self.engine.get_system_health()
            metrics = self.engine.metrics
            return (
                f"Mode:             {status.get('mode', 'real').upper()}\n"
                f"Engine:           {status.get('status', 'unknown')}\n"
                f"CPU:              {health.cpu_percent:.1f}%\n"
                f"RAM:              {health.memory_percent:.1f}%\n"
                f"Disk:             {health.disk_percent:.1f}%\n"
                f"Threats detected: {metrics.get('threats_detected', 0)}\n"
                f"Threats blocked:  {metrics.get('threats_blocked', 0)}\n"
                f"Scans performed:  {metrics.get('scans_performed', 0)}\n"
            )
        except Exception as exc:
            return f"Status unavailable: {exc}"

    def tool_get_threats(self) -> str:
        threats = list(getattr(self.engine, "detected_threats", []))
        if not threats:
            return "No active threats. All sensors nominal."
        lines = [f"{len(threats)} threat(s) on record:"]
        for t in threats[:20]:
            sev      = getattr(t, "severity", "?")
            sev_name = sev.name if hasattr(sev, "name") else str(sev)
            src      = getattr(t, "source_ip", None) or getattr(t, "process_name", "?")
            cat      = str(getattr(t, "category", "?"))
            tid      = getattr(t, "threat_id", "?")
            desc     = getattr(t, "description", "")
            lines.append(f"  [{sev_name}] {tid} — {cat} — {src}")
            if desc:
                lines.append(f"         {desc[:100]}")
        if len(threats) > 20:
            lines.append(f"  … +{len(threats) - 20} more not shown")
        return "\n".join(lines)

    def tool_get_processes(self, top_n: int = 20) -> str:
        try:
            import psutil
            procs = []
            for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
                try:
                    procs.append(p.info)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            procs.sort(key=lambda x: x.get("cpu_percent") or 0, reverse=True)
            lines = [f"Top {min(top_n, len(procs))} processes by CPU:"]
            for p in procs[:top_n]:
                lines.append(
                    f"  PID {p['pid']:6d}  CPU {(p['cpu_percent'] or 0):5.1f}%  "
                    f"MEM {(p['memory_percent'] or 0):4.1f}%  {p['name']}"
                )
            return "\n".join(lines)
        except Exception as exc:
            return f"Process list unavailable: {exc}"

    def tool_get_network(self) -> str:
        try:
            import psutil
            conns  = psutil.net_connections(kind="inet")
            active = [c for c in conns if c.status == "ESTABLISHED"]
            if not active:
                return "No established network connections."
            lines = [f"{len(active)} established connection(s):"]
            for c in active[:25]:
                laddr = f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "?"
                raddr = f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else "?"
                lines.append(f"  {laddr} → {raddr}  PID={c.pid or '?'}")
            if len(active) > 25:
                lines.append(f"  … +{len(active) - 25} more")
            return "\n".join(lines)
        except Exception as exc:
            return f"Network info unavailable: {exc}"

    def tool_run_integrity_sweep(self, auto_quarantine: bool = True) -> str:
        try:
            aq_label = "with auto-quarantine" if auto_quarantine else "manual review only"
            threading.Thread(
                target=self.engine.integrity_sweep_and_respond,
                kwargs={"auto_quarantine": auto_quarantine},
                daemon=True,
            ).start()
            return (
                f"Integrity sweep launched ({aq_label}). "
                "6-phase pipeline running in background. "
                "Check the Integrity Sweep panel for live progress and results."
            )
        except Exception as exc:
            return f"Sweep failed to start: {exc}"

    def tool_quarantine_pid(self, pid: int, reason: str = "AI-directed quarantine") -> str:
        if not self._gate("quarantine_pid", f"pid={pid} reason={reason}"):
            return "[BLOCKED] Quarantining a process requires human confirmation."
        try:
            import psutil
            proc = psutil.Process(pid)
            name = proc.name()
            qm = getattr(self.engine, "quarantine_manager", None)
            if qm and hasattr(qm, "quarantine"):
                qm.quarantine(pid, name)
                return f"✓ Quarantined — PID {pid} ({name}). Reason: {reason}"
            else:
                proc.terminate()
                return f"✓ Terminated — PID {pid} ({name}). Quarantine manager unavailable, used terminate()."
        except Exception as exc:
            return f"Quarantine failed: {exc}"

    def tool_block_ip(self, ip: str, reason: str = "AI-directed threat block") -> str:
        if not self._gate("block_ip", f"ip={ip} reason={reason}"):
            return "[BLOCKED] Blocking an IP requires human confirmation."
        results = []
        for direction in ("in", "out"):
            label     = "inbound" if direction == "in" else "outbound"
            rule_name = f"SERE_AI_{ip.replace('.', '_')}_{direction.upper()}"
            cmd = [
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={rule_name}",
                f"dir={direction}",
                "action=block",
                f"remoteip={ip}",
                "enable=yes",
                f"description=SERE-AI: {reason[:120]}",
            ]
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                if r.returncode == 0:
                    results.append(f"✓ {label}")
                else:
                    err = (r.stderr or r.stdout).strip()
                    results.append(f"✗ {label}: {err}")
            except Exception as exc:
                results.append(f"✗ {label}: {exc}")
        # Register in ping defense manager if available
        try:
            pdm = getattr(self.engine, "ping_defense_manager", None)
            if pdm and hasattr(pdm, "add_blocked_target"):
                pdm.add_blocked_target(ip)
        except Exception:
            pass
        return f"Block {ip}: " + " | ".join(results)

    def tool_analyze_logs(self, tail_lines: int = 100) -> str:
        try:
            if not self.log_path.exists():
                return f"Log file not found: {self.log_path}"
            with open(self.log_path, "r", encoding="utf-8", errors="replace") as fh:
                all_lines = fh.readlines()
            recent  = all_lines[-tail_lines:] if len(all_lines) > tail_lines else all_lines
            content = "".join(recent).strip()
            if not content:
                return "Log file is empty."
            return f"[Last {len(recent)} of {len(all_lines)} log lines]\n{content}"
        except Exception as exc:
            return f"Log read failed: {exc}"

    def tool_generate_threat_report(self) -> str:
        try:
            threats = list(getattr(self.engine, "detected_threats", []))
            health  = self.engine.get_system_health()
            metrics = self.engine.metrics
            status  = self.engine.get_protection_status()
            now     = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            sep     = "=" * 60
            lines   = [
                sep,
                "SERE THREAT INTELLIGENCE REPORT",
                f"Generated : {now}",
                f"Mode      : {status.get('mode', 'real').upper()}",
                sep,
                "",
                "SYSTEM HEALTH",
                f"  CPU    : {health.cpu_percent:.1f}%",
                f"  RAM    : {health.memory_percent:.1f}%",
                f"  Disk   : {health.disk_percent:.1f}%",
                "",
                "OPERATIONAL METRICS",
                f"  Threats detected : {metrics.get('threats_detected', 0)}",
                f"  Threats blocked  : {metrics.get('threats_blocked', 0)}",
                f"  Scans performed  : {metrics.get('scans_performed', 0)}",
                "",
                f"ACTIVE THREATS ({len(threats)})",
            ]
            if not threats:
                lines.append("  NONE — system clean.")
            else:
                for i, t in enumerate(threats, 1):
                    sev      = getattr(t, "severity", "?")
                    sev_name = sev.name if hasattr(sev, "name") else str(sev)
                    src      = getattr(t, "source_ip", None) or getattr(t, "process_name", "?")
                    cat      = str(getattr(t, "category", "?"))
                    tid      = getattr(t, "threat_id", "?")
                    desc     = getattr(t, "description", "")
                    lines += [
                        f"  [{i:02d}] {tid}",
                        f"       Severity : {sev_name}",
                        f"       Category : {cat}",
                        f"       Source   : {src}",
                    ]
                    if desc:
                        lines.append(f"       Info     : {desc[:140]}")
                    lines.append("")
            lines += [sep, "END OF REPORT", sep]
            return "\n".join(lines)
        except Exception as exc:
            return f"Report generation failed: {exc}"

    def tool_execute_script(self, code: str, timeout: int = SCRIPT_TIMEOUT) -> str:
        if not self._gate("execute_script", f"code[{len(code)} chars]"):
            return "[BLOCKED] Script execution requires human confirmation."
        try:
            r = subprocess.run(
                [sys.executable, "-c", code],
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            parts = []
            if r.stdout.strip():
                parts.append(f"STDOUT:\n{r.stdout.strip()}")
            if r.stderr.strip():
                parts.append(f"STDERR:\n{r.stderr.strip()}")
            parts.append(f"Exit code: {r.returncode}")
            return "\n".join(parts) if parts else "(no output)"
        except subprocess.TimeoutExpired:
            return f"Script timed out after {timeout}s"
        except Exception as exc:
            return f"Execution error: {exc}"

    def tool_apply_firewall_config(self, rules: List[Dict]) -> str:
        if not self._gate("apply_firewall_config", f"rules={len(rules)}"):
            return "[BLOCKED] Applying firewall rules requires human confirmation."
        results = []
        for i, rule in enumerate(rules):
            name      = rule.get("name", f"SERE_AI_RULE_{i}")
            direction = rule.get("direction", "in")
            action    = rule.get("action", "block")
            remoteip  = rule.get("remoteip", "any")
            protocol  = rule.get("protocol", "any")
            cmd = [
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={name}",
                f"dir={direction}",
                f"action={action}",
                f"remoteip={remoteip}",
                f"protocol={protocol}",
                "enable=yes",
            ]
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                status = "✓" if r.returncode == 0 else "✗"
                results.append(f"{status} {name} ({direction}/{action}/{remoteip})")
            except Exception as exc:
                results.append(f"✗ {name}: {exc}")
        return f"Applied {len(rules)} firewall rule(s):\n" + "\n".join(results)


# ─── Agent ────────────────────────────────────────────────────────────────────

class SEREAIAgent:
    """
    Agentic LLM loop with tool execution.

    Flow per query:
        1. Build messages (system prompt + history + user query)
        2. POST to Ollama with TOOL_SCHEMA
        3. If tool calls in response → execute → append results → loop (max MAX_TOOL_HOPS)
        4. When no more tool calls → final text response
        5. Return AgentResult
    """

    def __init__(self, engine, ollama: OllamaClient):
        self.engine   = engine
        self.ollama   = ollama
        self.registry = SEREToolRegistry(engine)
        self._history: List[Dict] = []

    def set_log_path(self, path: Path) -> None:
        self.registry.log_path = path

    def clear_history(self) -> None:
        self._history.clear()

    @staticmethod
    def _extract_code_blocks(text: str) -> List[str]:
        """Pull out all ```python ... ``` (or plain ``` ... ```) blocks."""
        return re.findall(r"```(?:python)?\s*\n?(.*?)```", text, re.DOTALL)

    def _system_message(self) -> Dict:
        return {
            "role":    "system",
            "content": GUNNY_SYSTEM_PROMPT.format(
                datetime=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ),
        }

    def query(
        self,
        user_message: str,
        on_tool_call: Optional[Callable[[str, Dict, str], None]] = None,
    ) -> AgentResult:
        """
        Run the agentic query loop.

        Args:
            user_message:  The user's natural-language query.
            on_tool_call:  Callback fired after each tool execution.
                           Signature: (tool_name: str, args: dict, result: str) → None

        Returns:
            AgentResult with final text, tool call log, extracted code blocks.
        """
        if not self.ollama.is_online:
            return AgentResult(
                text="[OFFLINE] Ollama is not running. Falling back to rule-based mode.",
                ollama_online=False,
                model_used="none",
            )

        messages: List[Dict] = [self._system_message()]
        messages.extend(self._history[-(HISTORY_DEPTH * 2):])
        messages.append({"role": "user", "content": user_message})

        tool_calls_made: List[ToolCall] = []
        final_text = ""

        for hop in range(MAX_TOOL_HOPS + 1):
            try:
                response = self.ollama.chat(messages, tools=TOOL_SCHEMA)
            except RuntimeError as exc:
                self.ollama._online = False
                return AgentResult(
                    text=f"[ERROR] {exc}",
                    error=str(exc),
                    ollama_online=False,
                    model_used=self.ollama.model,
                )

            msg             = response.get("message", {})
            content: str    = msg.get("content", "") or ""
            raw_tool_calls  = msg.get("tool_calls") or []

            if not raw_tool_calls:
                final_text = content
                break

            # Append assistant turn (with pending tool calls)
            messages.append({
                "role":       "assistant",
                "content":    content,
                "tool_calls": raw_tool_calls,
            })

            # Execute every tool call in this turn
            for tc in raw_tool_calls:
                fn     = tc.get("function", {})
                name   = fn.get("name", "")
                args   = fn.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}

                result = self.registry.dispatch(name, args)
                tc_obj = ToolCall(name=name, args=args, result=result)
                tool_calls_made.append(tc_obj)

                if on_tool_call:
                    try:
                        on_tool_call(name, args, result)
                    except Exception:
                        pass

                messages.append({"role": "tool", "content": result})

            if hop >= MAX_TOOL_HOPS:
                final_text = f"[MAX TOOL HOPS ({MAX_TOOL_HOPS}) REACHED]\n" + content
                break

        # Update conversation history
        self._history.append({"role": "user",      "content": user_message})
        self._history.append({"role": "assistant",  "content": final_text})

        # Trim history
        if len(self._history) > HISTORY_DEPTH * 4:
            self._history = self._history[-(HISTORY_DEPTH * 4):]

        return AgentResult(
            text=final_text,
            tool_calls=tool_calls_made,
            code_blocks=self._extract_code_blocks(final_text),
            ollama_online=True,
            model_used=self.ollama.model,
        )
