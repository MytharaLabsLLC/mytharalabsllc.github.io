#!/usr/bin/env python3
"""
S.E.R.E. Security Suite - Enterprise Cybersecurity Protection
Survive | Evade | Resist | Escape

Part of the Mythara Engine - Core Architect
Copyright © 2025 Herbert Velez Jr. All rights reserved.
Proprietary and Confidential.

ENTERPRISE-GRADE CONTINUOUS PROTECTION SYSTEM
Competing with McAfee, Norton, and enterprise security solutions.
"""

import sys
import os
import csv
import logging
import subprocess
import signal
import time
import platform
import hashlib
import json
import threading
import random
import socket
import ipaddress
import struct
import re
import psutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Set, Tuple, Any, Callable
from dataclasses import dataclass, field

# Console encoding fix (2026-11-23): Windows consoles default to cp1252, which
# cannot print this suite's banners, check marks, or box drawing, and crashed
# the dashboard menu (see sere_error.log). Force UTF-8 with safe replacement.
try:
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
from enum import Enum, auto
from collections import deque
import concurrent.futures
from urllib.parse import quote_plus

try:
    import io as _io, sys as _sys
    _old_stdout = _sys.stdout
    _sys.stdout = _io.StringIO()   # swallow big_meanie's ⚠️ print()s at import time
    try:
        from tests.big_meanie import run_big_meanie_silent
        BIG_MEANIE_AVAILABLE = True
    finally:
        _sys.stdout = _old_stdout  # always restore
except ImportError:  # pragma: no cover - optional dependency
    run_big_meanie_silent = None
    BIG_MEANIE_AVAILABLE = False

from sere_hyper_defense import (
    HYPER_CONFIG,
    AttackType as HyperAttackType,
    ThreatLevel as HyperThreatLevel,
    ThreatDetection as HyperThreatDetection,
    RealThreatDetector,
    WindowsFirewallController,
    QuarantineManager,
    PingDefenseManager,
    SystemRepairManager,
    lookup_geolocation,
)
from sere_incident_playbook import IncidentResponsePlaybook, AlertInput
from sere_persona_catalog import persona_line

# ============================================================================
# CONFIGURATION & CONSTANTS
# ============================================================================

VERSION = "2.0.0"
BUILD = "Enterprise"
APP_NAME = "SERE_Security"
APP_DESCRIPTION = "S.E.R.E. Enterprise Security Suite"
IP_ESCALATION_THRESHOLD = 5

# Threat severity levels
class ThreatSeverity(Enum):
    INFO = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

# Threat categories (McAfee/Norton competitive)
class ThreatCategory(Enum):
    MALWARE = "Malware"
    RANSOMWARE = "Ransomware"
    TROJAN = "Trojan"
    VIRUS = "Virus"
    WORM = "Worm"
    SPYWARE = "Spyware"
    ADWARE = "Adware"
    ROOTKIT = "Rootkit"
    KEYLOGGER = "Keylogger"
    PHISHING = "Phishing"
    NETWORK_INTRUSION = "Network Intrusion"
    PORT_SCAN = "Port Scan"
    BRUTE_FORCE = "Brute Force Attack"
    DDoS = "DDoS Attack"
    MAN_IN_MIDDLE = "Man-in-the-Middle"
    DNS_HIJACK = "DNS Hijacking"
    SUSPICIOUS_PROCESS = "Suspicious Process"
    UNAUTHORIZED_ACCESS = "Unauthorized Access"
    DATA_EXFILTRATION = "Data Exfiltration"
    CRYPTO_MINER = "Cryptocurrency Miner"
    PUP = "Potentially Unwanted Program"
    EXPLOIT = "Exploit Attempt"
    ZERO_DAY = "Zero-Day Threat"

# Protection modules
class ProtectionModule(Enum):
    REAL_TIME = "Real-Time Protection"
    FIREWALL = "Firewall Monitor"
    NETWORK = "Network Security"
    WEB = "Web Protection"
    EMAIL = "Email Security"
    RANSOMWARE = "Ransomware Shield"
    EXPLOIT = "Exploit Prevention"
    BEHAVIOR = "Behavior Analysis"
    CLOUD = "Cloud Intelligence"
    IDENTITY = "Identity Protection"

# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class ThreatSignature:
    """Known threat signature for pattern matching."""
    id: str
    name: str
    category: ThreatCategory
    severity: ThreatSeverity
    pattern: str  # Regex or hash pattern
    description: str
    mitigation: str
    first_seen: datetime = field(default_factory=datetime.now)

@dataclass
class DetectedThreat:
    """A detected threat instance."""
    threat_id: str
    signature_id: Optional[str]
    category: ThreatCategory
    severity: ThreatSeverity
    source: str
    target: str
    description: str
    timestamp: datetime
    process_id: Optional[int] = None
    process_name: Optional[str] = None
    file_path: Optional[str] = None
    network_info: Optional[Dict] = None
    quarantined: bool = False
    resolved: bool = False
    action_taken: Optional[str] = None
    geolocation: Optional[Dict[str, str]] = None
    intel_sources: List[str] = field(default_factory=list)
    intel_score: float = 0.0
    intel_summary: str = "Awaiting external verdict"
    intel_link: Optional[str] = None

@dataclass
class SystemHealth:
    """System health metrics."""
    cpu_percent: float
    memory_percent: float
    disk_percent: float
    network_connections: int
    running_processes: int
    suspicious_processes: int
    open_ports: List[int]
    firewall_status: str
    last_scan: datetime
    threats_blocked_today: int
    protection_score: int  # 0-100

@dataclass
class ScanResult:
    """Result of a security scan."""
    scan_id: str
    scan_type: str
    start_time: datetime
    end_time: Optional[datetime]
    items_scanned: int
    threats_found: int
    threats_quarantined: int
    threats_removed: int
    status: str

# ============================================================================
# THREAT INTELLIGENCE DATABASE
# ============================================================================

class ThreatIntelligence:
    """Local threat intelligence database with known signatures."""
    IP_PATTERN = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
    
    def __init__(self):
        self.signatures: Dict[str, ThreatSignature] = {}
        self.malicious_hashes: Set[str] = set()
        self.malicious_ips: Set[str] = set()
        self.malicious_domains: Set[str] = set()
        self.suspicious_ports: Set[int] = {4444, 5555, 6666, 31337, 12345, 27374, 1234}
        self.suspicious_processes: Set[str] = set()
        self._load_signatures()
    
    def _load_signatures(self):
        """Load built-in threat signatures."""
        # Known malicious process names
        self.suspicious_processes = {
            "cryptominer", "xmrig", "minerd", "cgminer", "bfgminer",
            "coinhive", "cryptonight", "stratum", "nicehash",
            "mimikatz", "lazagne", "procdump", "pwdump",
            "netcat", "nc.exe", "ncat", "socat",
            "psexec", "wmic", "certutil",  # Legitimate but often abused
            "powershell_ise",  # Can be abused
        }
        
        # Known malicious IPs (example - in production these would be updated from feeds)
        self.malicious_ips = {
            "185.220.101.0", "45.33.32.156", "198.51.100.0",
            "203.0.113.0", "192.0.2.0",  # Example bad IPs
        }
        
        # Known malicious domains
        self.malicious_domains = {
            "malware-domain.com", "phishing-site.net", "evil-download.org",
            "crypto-scam.io", "fake-bank.com",
        }
        
        # Add signature patterns
        signatures = [
            ThreatSignature("SIG001", "Generic.Trojan.A", ThreatCategory.TROJAN, ThreatSeverity.HIGH,
                           r"(?i)(trojan|backdoor)", "Generic trojan detection", "Quarantine and remove"),
            ThreatSignature("SIG002", "Ransom.Generic", ThreatCategory.RANSOMWARE, ThreatSeverity.CRITICAL,
                           r"(?i)(ransom|encrypt.*files|\.locked$)", "Ransomware behavior detected", "Isolate immediately"),
            ThreatSignature("SIG003", "Miner.CryptoJack", ThreatCategory.CRYPTO_MINER, ThreatSeverity.MEDIUM,
                           r"(?i)(xmrig|coinhive|cryptonight|stratum)", "Cryptocurrency miner detected", "Terminate process"),
            ThreatSignature("SIG004", "Spyware.Keylog", ThreatCategory.KEYLOGGER, ThreatSeverity.HIGH,
                           r"(?i)(keylog|keyboard.*hook|getasynckeystate)", "Keylogger activity", "Remove immediately"),
            ThreatSignature("SIG005", "Network.PortScan", ThreatCategory.PORT_SCAN, ThreatSeverity.MEDIUM,
                           r"(?i)(nmap|masscan|zmap)", "Port scanning detected", "Block source IP"),
            ThreatSignature("SIG006", "Exploit.Attempt", ThreatCategory.EXPLOIT, ThreatSeverity.HIGH,
                           r"(?i)(exploit|shellcode|overflow)", "Exploit attempt detected", "Block and alert"),
        ]
        
        for sig in signatures:
            self.signatures[sig.id] = sig

    def enrich_threat(self, threat: Optional[DetectedThreat]) -> None:
        """Attach external intelligence context to a detected threat."""
        if not threat:
            return
        sources: List[str] = []
        notes: List[str] = []
        score = 0.3

        if threat.signature_id and threat.signature_id in self.signatures:
            sig = self.signatures[threat.signature_id]
            sources.append("Signature DB")
            notes.append(f"Matches {sig.name}")
            score = max(score, 0.85)

        proc_name = (threat.process_name or "").lower()
        if proc_name and proc_name in self.suspicious_processes:
            sources.append("Process Reputation")
            notes.append(f"{threat.process_name} flagged in intel feed")
            score = max(score, 0.7)

        remote_ip = self._extract_remote_ip(threat)
        indicator = remote_ip
        if remote_ip and remote_ip in self.malicious_ips:
            sources.append("IP Reputation")
            notes.append(f"{remote_ip} listed on malicious IP feed")
            score = max(score, 0.8)

        if threat.network_info and threat.network_info.get('vector'):
            sources.append("Network Telemetry")
            notes.append(f"Vector {threat.network_info['vector']}")
            score = max(score, 0.55)

        if threat.category in {ThreatCategory.RANSOMWARE, ThreatCategory.NETWORK_INTRUSION, ThreatCategory.DATA_EXFILTRATION}:
            sources.append("Category Intelligence")
            notes.append(f"High-risk {threat.category.value}")
            score = max(score, 0.6)

        indicator = indicator or threat.file_path or threat.source or threat.target
        if indicator:
            try:
                threat.intel_link = f"https://www.virustotal.com/gui/search/{quote_plus(str(indicator))}"
            except Exception:
                threat.intel_link = None

        severity_boost = threat.severity.value / max(ThreatSeverity.CRITICAL.value, 1)
        score = min(0.99, round(max(score, 0.35 + severity_boost * 0.2), 2))

        if not sources:
            sources.append("Local heuristics")
        if not notes:
            notes.append("Awaiting external verdict")

        threat.intel_sources = sources
        threat.intel_score = score
        threat.intel_summary = " | ".join(notes)

    @classmethod
    def _extract_remote_ip(cls, threat: DetectedThreat) -> Optional[str]:
        fields: List[str] = []
        if threat.network_info:
            for key in ("remote_ip", "ip"):
                value = threat.network_info.get(key)
                if value:
                    fields.append(str(value))
        fields.extend(filter(None, [threat.source, threat.target, threat.description]))
        for entry in fields:
            match = cls.IP_PATTERN.search(str(entry))
            if match:
                return match.group(0)
        return None
    
    def check_hash(self, file_hash: str) -> Optional[ThreatSignature]:
        """Check if a file hash is known malicious."""
        if file_hash.lower() in self.malicious_hashes:
            return ThreatSignature("HASH_MATCH", "Known Malware Hash", ThreatCategory.MALWARE,
                                  ThreatSeverity.CRITICAL, file_hash, "Known malicious file", "Delete immediately")
        return None
    
    def check_ip(self, ip: str) -> Optional[ThreatSignature]:
        """Check if an IP is known malicious."""
        if ip in self.malicious_ips:
            return ThreatSignature("IP_MATCH", "Malicious IP", ThreatCategory.NETWORK_INTRUSION,
                                  ThreatSeverity.HIGH, ip, "Communication with known bad IP", "Block connection")
        return None
    
    def check_domain(self, domain: str) -> Optional[ThreatSignature]:
        """Check if a domain is known malicious."""
        domain_lower = domain.lower()
        for bad_domain in self.malicious_domains:
            if bad_domain in domain_lower:
                return ThreatSignature("DOMAIN_MATCH", "Malicious Domain", ThreatCategory.PHISHING,
                                      ThreatSeverity.HIGH, domain, "Known malicious domain", "Block access")
        return None
    
    def check_process(self, process_name: str) -> Optional[ThreatSignature]:
        """Check if a process name is suspicious."""
        name_lower = process_name.lower()
        for suspicious in self.suspicious_processes:
            if suspicious in name_lower:
                return ThreatSignature("PROC_MATCH", f"Suspicious Process: {suspicious}", 
                                      ThreatCategory.SUSPICIOUS_PROCESS, ThreatSeverity.MEDIUM,
                                      suspicious, "Potentially malicious process", "Investigate and terminate if unauthorized")
        return None

# ============================================================================
# PROTECTION ENGINE
# ============================================================================

class SEREProtectionEngine:
    """Enterprise-grade protection engine."""
    
    def __init__(self):
        self.intel = ThreatIntelligence()
        self.detected_threats: List[DetectedThreat] = []
        self.quarantine_path = Path.home() / ".sere_quarantine"
        self.quarantine_path.mkdir(exist_ok=True)
        self.runtime_path = Path.home() / ".sere_enterprise"
        self.runtime_path.mkdir(parents=True, exist_ok=True)
        self.scan_history: List[ScanResult] = []
        self.blocked_ips: Set[str] = set()
        self.blocked_processes: Set[int] = set()
        self.protection_modules: Dict[ProtectionModule, bool] = {
            module: True for module in ProtectionModule
        }
        self.threat_count_today = 0
        self.last_full_scan: Optional[datetime] = None
        self._running = False
        self._lock = threading.Lock()
        
        # Event log
        self.event_log: deque = deque(maxlen=1000)
        self.log_listeners: List[Callable[[Dict[str, Any]], None]] = []
        self.suppress_console_output = False
        
        # Performance metrics
        self.metrics = {
            "scans_completed": 0,
            "threats_detected": 0,
            "threats_blocked": 0,
            "threats_quarantined": 0,
            "threats_resolved": 0,
            "files_scanned": 0,
            "network_packets_inspected": 0,
        }
        self.metrics.update(
            {
                "hyper_events": 0,
                "hyper_quarantines": 0,
                "hyper_ping_targets": 0,
                "big_meanie_runs": 0,
            }
        )

        self.ip_detection_counts: Dict[str, int] = {}
        self.ip_escalation_threshold = IP_ESCALATION_THRESHOLD

        self.big_meanie_available = BIG_MEANIE_AVAILABLE
        self.big_meanie_last_summary: Optional[Dict[str, Any]] = None

        # Simulation mode permanently disabled per spec (ENABLE_SIMULATION_FALLBACK: False)
        self.simulation_mode = False  # read-only sentinel — never set True

        # Hyper defense subsystems
        self.hyper_watch_enabled = True
        self.hyper_config = dict(HYPER_CONFIG)
        if platform.system().lower() != "windows":
            self.hyper_config["ENABLE_EVENT_LOG_DETECTION"] = False
            self.hyper_config["ENABLE_WMI_DETECTION"] = False
        self.real_threat_detector = RealThreatDetector(self.hyper_config)
        self.firewall_controller = WindowsFirewallController()
        self.quarantine_manager = QuarantineManager(self.firewall_controller, self.hyper_config)
        self.ping_defense_manager = PingDefenseManager(self.hyper_config)
        self.repair_manager = SystemRepairManager()
        self._hyper_seen_ids: Set[str] = set()
        self.hyper_last_detection: Optional[Dict[str, Any]] = None
        self.relentless_mode = False
        self.obtuse_defense_engaged = False
    
    def register_log_listener(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        if callback and callback not in self.log_listeners:
            self.log_listeners.append(callback)

    def remove_log_listener(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        if callback in self.log_listeners:
            self.log_listeners.remove(callback)

    def set_hyper_watch(self, enabled: bool) -> None:
        self.hyper_watch_enabled = bool(enabled)
        state = "enabled" if self.hyper_watch_enabled else "disabled"
        self.log_event("INFO", f"Hyper-sensitivity {state}")

    def set_simulation_mode(self, enabled: bool) -> None:
        """Simulation mode is permanently disabled per Mythara spec.
        Calls to enable simulation are rejected and logged."""
        if enabled:
            self.log_event("WARNING",
                "Simulation mode request REJECTED — S.E.R.E. operates on REAL threats only.")
        # simulation_mode stays False unconditionally

    # ── Mythara Safety Hierarchy ──────────────────────────────────────────────
    # Per spec: every aggressive action must pass this hierarchy before executing.
    # 1. Preservation of Life   2. Preservation of Safety
    # 3. Preservation of Autonomy & Dignity   4. Preservation of Lawful Presence
    # 5. Preservation of Continuity
    _HIERARCHY_LABELS = [
        "Preservation of Life",
        "Preservation of Safety",
        "Preservation of Autonomy & Dignity",
        "Preservation of Lawful Presence",
        "Preservation of Continuity",
    ]

    # Actions that direct traffic or force against a remote target. Per the
    # owner's rule (2026-11-23), these may run ONLY inside a sandbox
    # (simulation mode). Defense on the owner's own machine is not offensive.
    OFFENSIVE_ACTIONS = frozenset({
        "ping_flood_defense", "ping_flood", "counter_flood", "flood",
        "counter_attack", "counterattack",
    })

    def mythara_safety_check(self, action: str, target: str) -> bool:
        """
        Run the Mythara Safety Hierarchy before any aggressive action.
        Returns True only if the action is cleared to proceed.

        Real rules (2026-11-23, replacing the former log-and-always-clear):
        1. Offensive actions are sandbox-only. If simulation mode is off,
           the action is BLOCKED. (In this engine simulation mode is
           permanently disabled per spec, so offensive actions can never
           clear here until that spec lock is deliberately reversed.)
        2. Offensive actions may never target private, loopback, link-local,
           multicast, reserved, or unspecified addresses, sandbox or not.
        3. Defensive actions (block, quarantine, scan on the owner's own
           machine) clear after logging.
        Every decision is logged with its reason.
        """
        self.log_event("INFO",
            f"[HIERARCHY] Evaluating '{action}' on target '{target}'")
        if action in self.OFFENSIVE_ACTIONS:
            try:
                ip = ipaddress.ip_address(str(target).strip())
            except ValueError:
                ip = None
            if ip is not None and (ip.is_private or ip.is_loopback or
                                   ip.is_link_local or ip.is_multicast or
                                   ip.is_reserved or ip.is_unspecified):
                self.log_event("WARNING",
                    f"[HIERARCHY] '{action}' on '{target}' — BLOCKED. "
                    "Never-target range (private/loopback/link-local/"
                    "multicast/reserved).")
                return False
            if not self.is_simulation_mode():
                self.log_event("WARNING",
                    f"[HIERARCHY] '{action}' on '{target}' — BLOCKED. "
                    "Offensive actions are sandbox-only (owner rule, "
                    "2026-11-23); simulation mode is off.")
                return False
            self.log_event("INFO",
                f"[HIERARCHY] '{action}' on '{target}' — CLEARED inside "
                "sandbox (simulation mode on).")
            return True
        for level, label in enumerate(self._HIERARCHY_LABELS, start=1):
            self.log_event("INFO", f"  [{level}] {label} — OK")
        self.log_event("INFO",
            f"[HIERARCHY] '{action}' on '{target}' — CLEARED. Defensive "
            "action, all 5 levels passed.")
        return True

    # ── Ping Flood Defense ────────────────────────────────────────────────────
    def ping_flood_defense(self, target_ips: List[str],
                           duration: int = 15, intensity: str = 'medium') -> Dict[str, Any]:
        """
        Launch a high-intensity ping defense against confirmed threat IPs.
        Routed through the Mythara Safety Hierarchy before execution.

        Args:
            target_ips: List of confirmed threat IP addresses.
            duration:   Seconds to sustain the defense (default 15).
            intensity:  'low' | 'medium' | 'high' — controls concurrency.

        Returns dict with results per IP (sent, success, avg_ms).
        """
        results: Dict[str, Any] = {}
        threads_map = {'low': 2, 'medium': 4, 'high': 8}
        thread_count = threads_map.get(intensity, 4)

        for ip in target_ips:
            if not self.mythara_safety_check("ping_flood_defense", ip):
                results[ip] = {"status": "blocked_by_hierarchy"}
                continue

            self.log_event("WARNING",
                f"[PING FLOOD] Deploying {intensity.upper()} ping flood on {ip} "
                f"for {duration}s ({thread_count} threads)")

            stop_event = threading.Event()
            sent: list = [0]
            success: list = [0]
            latencies: list = []
            lock = threading.Lock()

            def _flood_worker(target: str) -> None:
                import subprocess as _sp
                import platform as _pl
                end_time = time.time() + duration
                while time.time() < end_time and not stop_event.is_set():
                    try:
                        flag = '-n' if _pl.system().lower() == 'windows' else '-c'
                        t0 = time.time()
                        r = _sp.run(
                            ['ping', flag, '1', '-w', '500', target],
                            capture_output=True, timeout=2
                        )
                        elapsed = (time.time() - t0) * 1000
                        with lock:
                            sent[0] += 1
                            if r.returncode == 0:
                                success[0] += 1
                                latencies.append(elapsed)
                    except Exception:
                        with lock:
                            sent[0] += 1

            workers = [threading.Thread(target=_flood_worker, args=(ip,), daemon=True)
                       for _ in range(thread_count)]
            for w in workers:
                w.start()
            for w in workers:
                w.join(timeout=duration + 2)
            stop_event.set()

            avg_ms = round(sum(latencies) / len(latencies), 1) if latencies else 0.0
            results[ip] = {
                "status": "completed",
                "sent": sent[0],
                "success": success[0],
                "avg_latency_ms": avg_ms,
                "intensity": intensity,
                "duration_s": duration,
            }
            self.log_event("INFO",
                f"[PING FLOOD] {ip} — {sent[0]} pings sent, "
                f"{success[0]} returned, avg {avg_ms}ms")
            # Track the IP in ping defense manager for continued monitoring
            if hasattr(self, 'ping_defense_manager'):
                try:
                    self.ping_defense_manager.track(ip)
                except Exception:
                    pass

        return results

    def enable_relentless_mode(self, reason: Optional[str] = None) -> bool:
        """Escalate Hyper defenses to a relentless fortress posture."""
        with self._lock:
            if self.relentless_mode:
                return False
            self.relentless_mode = True
            adjustments = {
                "ENABLE_REAL_DETECTION": True,
                "ENABLE_REAL_BLOCKING": True,
                "PING_INTERVAL": max(5, int(self.hyper_config.get("PING_INTERVAL", 30) / 3) or 5),
                "PING_TIMEOUT": max(3, int(self.hyper_config.get("PING_TIMEOUT", 5))),
                "FAILED_LOGIN_THRESHOLD": 1,
            }
            self.hyper_config.update(adjustments)
            if hasattr(self.real_threat_detector, "config"):
                self.real_threat_detector.config.update(adjustments)
            if hasattr(self.quarantine_manager, "config"):
                self.quarantine_manager.config.update(adjustments)
            if hasattr(self.ping_defense_manager, "config"):
                self.ping_defense_manager.config.update(adjustments)
            self.ip_escalation_threshold = 1
        if not self.hyper_watch_enabled:
            self.set_hyper_watch(True)
        message = "Relentless Hyper Defense engaged"
        if reason:
            message = f"{message}: {reason}"
        persona = persona_line('gunny')
        self.log_event("CRITICAL", f"{message}. Hyper configuration hardened. {persona}")
        return True

    def set_obtuse_defense(self, engaged: bool, reason: Optional[str] = None) -> None:
        """Toggle the obtuse defense field ( latency + telemetry noise ) across subsystems."""
        with self._lock:
            current = bool(self.obtuse_defense_engaged)
            if current == bool(engaged):
                return
            self.obtuse_defense_engaged = bool(engaged)
            self.hyper_config["OBTUSE_DEFENSE_ENABLED"] = bool(engaged)
            for subsystem in (self.real_threat_detector, self.quarantine_manager, self.ping_defense_manager):
                if subsystem and hasattr(subsystem, "config"):
                    subsystem.config["OBTUSE_DEFENSE_ENABLED"] = bool(engaged)
        status = "engaged" if engaged else "returned to standby"
        message = f"Obtuse defense field {status}"
        if reason:
            message = f"{message}: {reason}"
        level = "WARNING" if engaged else "INFO"
        persona_bucket = 'cease' if engaged else 'consigliere'
        persona = persona_line(persona_bucket)
        self.log_event(level, f"{message}. {persona}")

    def has_active_intruder(self) -> bool:
        """Return True if unresolved high-severity threats remain inside the system."""
        with self._lock:
            for threat in self.detected_threats:
                severity = getattr(threat, "severity", ThreatSeverity.MEDIUM)
                if severity.value < ThreatSeverity.HIGH.value:
                    continue
                if getattr(threat, "resolved", False) or getattr(threat, "quarantined", False):
                    continue
                return True
        return False

    def is_simulation_mode(self) -> bool:
        return False  # Always REAL — simulation permanently disabled

    def log_event(self, level: str, message: str, details: Optional[Dict] = None):
        """Log a security event."""
        event = {
            "timestamp": datetime.now().isoformat(),
            "level": level,
            "message": message,
            "details": details or {}
        }
        self.event_log.append(event)
        
        # Also print to console with color coding
        colors = {
            "INFO": "\033[94m",
            "WARNING": "\033[93m", 
            "ALERT": "\033[91m",
            "SUCCESS": "\033[92m",
            "CRITICAL": "\033[95m"
        }
        reset = "\033[0m"
        color = colors.get(level, "")
        if not self.suppress_console_output:
            print(f"{color}[{level}]{reset} {message}")

        if self.log_listeners:
            for listener in list(self.log_listeners):
                try:
                    listener(event)
                except Exception:
                    logging.getLogger(__name__).exception("Log listener failed")
    
    def get_system_health(self) -> SystemHealth:
        """Get current system health metrics."""
        try:
            # CPU & Memory
            cpu = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory().percent
            disk = psutil.disk_usage('/').percent if platform.system() != "Windows" else psutil.disk_usage('C:\\').percent
            
            # Network connections
            connections = len(psutil.net_connections(kind='inet'))
            
            # Processes
            processes = list(psutil.process_iter(['pid', 'name']))
            running = len(processes)
            
            # Check for suspicious processes
            suspicious = 0
            for proc in processes:
                try:
                    name = proc.info['name'].lower() if proc.info['name'] else ''
                    if self.intel.check_process(name):
                        suspicious += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            
            # Open ports
            open_ports = []
            for conn in psutil.net_connections(kind='inet'):
                if conn.status == 'LISTEN' and conn.laddr:
                    open_ports.append(conn.laddr.port)
            open_ports = list(set(open_ports))[:20]  # Limit to 20
            
            # Firewall status (Windows)
            firewall = "Unknown"
            if platform.system() == "Windows":
                try:
                    result = subprocess.run(
                        ["netsh", "advfirewall", "show", "allprofiles", "state"],
                        capture_output=True, text=True, timeout=5
                    )
                    if "ON" in result.stdout.upper():
                        firewall = "Active"
                    else:
                        firewall = "Disabled"
                except:
                    firewall = "Unknown"
            
            # Calculate protection score
            score = 100
            if firewall != "Active":
                score -= 20
            if suspicious > 0:
                score -= min(suspicious * 10, 30)
            if memory > 90:
                score -= 10
            if cpu > 90:
                score -= 10
            score = max(0, score)
            
            return SystemHealth(
                cpu_percent=cpu,
                memory_percent=memory,
                disk_percent=disk,
                network_connections=connections,
                running_processes=running,
                suspicious_processes=suspicious,
                open_ports=open_ports,
                firewall_status=firewall,
                last_scan=self.last_full_scan or datetime.now(),
                threats_blocked_today=self.threat_count_today,
                protection_score=score
            )
        except Exception as e:
            self.log_event("WARNING", f"Error getting system health: {e}")
            return SystemHealth(0, 0, 0, 0, 0, 0, [], "Unknown", datetime.now(), 0, 50)
    
    def scan_processes(self) -> List[DetectedThreat]:
        """Scan running processes for threats."""
        threats = []
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
                try:
                    info = proc.info
                    name = info['name'] or ''
                    exe = info['exe'] or ''
                    pid = info['pid']
                    
                    # Check against threat intelligence
                    sig = self.intel.check_process(name)
                    if sig:
                        threat = DetectedThreat(
                            threat_id=f"PROC-{pid}-{int(time.time())}",
                            signature_id=sig.id,
                            category=sig.category,
                            severity=sig.severity,
                            source=f"Process: {name}",
                            target=f"PID: {pid}",
                            description=sig.description,
                            timestamp=datetime.now(),
                            process_id=pid,
                            process_name=name,
                            file_path=exe
                        )
                        threats.append(threat)
                        self.detected_threats.append(threat)
                        self.metrics["threats_detected"] += 1
                    
                    # Check network connections for this process
                    try:
                        # psutil 6+ renamed proc.connections() → proc.net_connections()
                        try:
                            conns = proc.net_connections(kind='inet')
                        except AttributeError:
                            conns = proc.connections(kind='inet')
                        for conn in conns:
                            if conn.raddr:
                                ip = conn.raddr.ip
                                ip_sig = self.intel.check_ip(ip)
                                if ip_sig:
                                    threat = DetectedThreat(
                                        threat_id=f"NET-{pid}-{int(time.time())}",
                                        signature_id=ip_sig.id,
                                        category=ip_sig.category,
                                        severity=ip_sig.severity,
                                        source=f"Process: {name}",
                                        target=f"IP: {ip}:{conn.raddr.port}",
                                        description=f"{name} communicating with malicious IP",
                                        timestamp=datetime.now(),
                                        process_id=pid,
                                        process_name=name,
                                        network_info={"remote_ip": ip, "remote_port": conn.raddr.port}
                                    )
                                    count = self._register_ip_detection(ip)
                                    if count:
                                        threat.network_info["detection_count"] = count
                                    threats.append(threat)
                                    self.detected_threats.append(threat)
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                        
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
                    
        except Exception as e:
            self.log_event("WARNING", f"Error scanning processes: {e}")
        
        return threats
    
    def scan_network(self) -> List[DetectedThreat]:
        """Scan network connections for threats."""
        threats = []
        
        try:
            connections = psutil.net_connections(kind='inet')
            
            for conn in connections:
                # Check for suspicious ports
                if conn.laddr and conn.laddr.port in self.intel.suspicious_ports:
                    if conn.status == 'LISTEN':
                        threat = DetectedThreat(
                            threat_id=f"PORT-{conn.laddr.port}-{int(time.time())}",
                            signature_id="SUSP_PORT",
                            category=ThreatCategory.NETWORK_INTRUSION,
                            severity=ThreatSeverity.MEDIUM,
                            source=f"Local port {conn.laddr.port}",
                            target="System",
                            description=f"Suspicious port {conn.laddr.port} is listening",
                            timestamp=datetime.now(),
                            network_info={"local_port": conn.laddr.port, "status": conn.status}
                        )
                        threats.append(threat)
                        self.detected_threats.append(threat)
                
                # Check remote IPs
                if conn.raddr:
                    ip_sig = self.intel.check_ip(conn.raddr.ip)
                    if ip_sig:
                        threat = DetectedThreat(
                            threat_id=f"CONN-{int(time.time())}",
                            signature_id=ip_sig.id,
                            category=ip_sig.category,
                            severity=ip_sig.severity,
                            source=f"Connection to {conn.raddr.ip}",
                            target="System",
                            description=ip_sig.description,
                            timestamp=datetime.now(),
                            network_info={"remote_ip": conn.raddr.ip, "remote_port": conn.raddr.port}
                        )
                        count = self._register_ip_detection(conn.raddr.ip)
                        if count:
                            threat.network_info["detection_count"] = count
                        threats.append(threat)
                        self.detected_threats.append(threat)
            
            self.metrics["network_packets_inspected"] += len(connections)
            
        except Exception as e:
            self.log_event("WARNING", f"Error scanning network: {e}")
        
        return threats

    @staticmethod
    def _hyper_severity(level: HyperThreatLevel) -> ThreatSeverity:
        mapping = {
            HyperThreatLevel.NONE: ThreatSeverity.INFO,
            HyperThreatLevel.MINIMAL: ThreatSeverity.LOW,
            HyperThreatLevel.MODERATE: ThreatSeverity.MEDIUM,
            HyperThreatLevel.SUBSTANTIAL: ThreatSeverity.HIGH,
            HyperThreatLevel.SEVERE: ThreatSeverity.HIGH,
            HyperThreatLevel.CRITICAL: ThreatSeverity.CRITICAL,
        }
        return mapping.get(level, ThreatSeverity.MEDIUM)

    @staticmethod
    def _hyper_category(attack: HyperAttackType) -> ThreatCategory:
        mapping = {
            HyperAttackType.DDOS: ThreatCategory.DDoS,
            HyperAttackType.SQL_INJECTION: ThreatCategory.EXPLOIT,
            HyperAttackType.XSS: ThreatCategory.EXPLOIT,
            HyperAttackType.BRUTE_FORCE: ThreatCategory.BRUTE_FORCE,
            HyperAttackType.MALWARE: ThreatCategory.MALWARE,
            HyperAttackType.PHISHING: ThreatCategory.PHISHING,
            HyperAttackType.MITM: ThreatCategory.MAN_IN_MIDDLE,
            HyperAttackType.ZERO_DAY: ThreatCategory.ZERO_DAY,
            HyperAttackType.RANSOMWARE: ThreatCategory.RANSOMWARE,
            HyperAttackType.DATA_BREACH: ThreatCategory.DATA_EXFILTRATION,
            HyperAttackType.SUSPICIOUS_OUTBOUND: ThreatCategory.NETWORK_INTRUSION,
            HyperAttackType.TOR_USAGE: ThreatCategory.NETWORK_INTRUSION,
            HyperAttackType.DATA_EXFILTRATION: ThreatCategory.DATA_EXFILTRATION,
            HyperAttackType.CALLBACK_THREAT: ThreatCategory.NETWORK_INTRUSION,
        }
        return mapping.get(attack, ThreatCategory.NETWORK_INTRUSION)

    def _generate_simulated_threats(self) -> List[DetectedThreat]:
        scenarios = [
            {
                "category": ThreatCategory.RANSOMWARE,
                "severity": ThreatSeverity.CRITICAL,
                "description": "Simulated ransomware beacon encrypting finance share",
                "source": "SimNode-FIN",
                "target": "\\\\FIN-FS01\\LEDGER",
                "vector": "SMB/445",
            },
            {
                "category": ThreatCategory.NETWORK_INTRUSION,
                "severity": ThreatSeverity.HIGH,
                "description": "Red-team port sweep on perimeter sensor",
                "source": "GhostNet",
                "target": "Edge Gateway",
                "vector": "TCP/8080",
            },
            {
                "category": ThreatCategory.MALWARE,
                "severity": ThreatSeverity.MEDIUM,
                "description": "Heuristic flagged obfuscated loader in staging temp",
                "source": "Process: sim_loader.exe",
                "target": "C:/Staging/tmp.dll",
                "vector": "Process injection",
            },
            {
                "category": ThreatCategory.DATA_EXFILTRATION,
                "severity": ThreatSeverity.HIGH,
                "description": "Telemetry suggests exfil stream toward offshore relay",
                "source": "AppServer-03",
                "target": "Unknown relay",
                "vector": "HTTPS/443",
            },
        ]
        count = random.randint(0, 3)
        threats: List[DetectedThreat] = []
        if count == 0:
            return threats
        for _ in range(count):
            scenario = random.choice(scenarios)
            self._simulated_counter += 1
            network_payload = {
                "vector": scenario["vector"],
                "remote_ip": self._random_ip(),
                "confidence": round(random.uniform(0.62, 0.98), 2),
            }
            detection_count = self._register_ip_detection(network_payload["remote_ip"])
            if detection_count:
                network_payload["detection_count"] = detection_count
            threat = DetectedThreat(
                threat_id=f"SIM-{self._simulated_counter:05d}",
                signature_id=None,
                category=scenario["category"],
                severity=scenario["severity"],
                source=scenario["source"],
                target=scenario["target"],
                description=scenario["description"],
                timestamp=datetime.now(),
                network_info=network_payload,
            )
            threats.append(threat)
            self.detected_threats.append(threat)
        if len(self.detected_threats) > 250:
            self.detected_threats = self.detected_threats[-250:]
        if threats:
            self.metrics["threats_detected"] += len(threats)
        return threats

    @staticmethod
    def _random_ip() -> str:
        octets = [str(random.randint(11, 223)) for _ in range(4)]
        return ".".join(octets)

    def prioritize_threat_resolution(self) -> Dict[str, int]:
        """Aggressively resolve outstanding threats by severity."""
        stats = {"quarantined": 0, "blocked_ips": 0}
        pending = [t for t in self.detected_threats if not t.quarantined and not t.resolved]
        if not pending:
            return stats

        pending.sort(key=lambda threat: getattr(threat, 'severity', ThreatSeverity.MEDIUM).value, reverse=True)
        for threat in pending:
            severity = getattr(threat, 'severity', ThreatSeverity.MEDIUM)
            remote_ip = ThreatIntelligence._extract_remote_ip(threat)
            ip_ready = True
            if remote_ip:
                ip_ready = self._ip_ready_for_escalation(remote_ip)
            if severity.value >= ThreatSeverity.HIGH.value:
                if remote_ip and not ip_ready:
                    continue
                if self.quarantine_threat(threat.threat_id):
                    threat.resolved = True
                    if not threat.action_taken:
                        threat.action_taken = "Auto-quarantined"
                    stats["quarantined"] += 1
                    continue

            if severity.value >= ThreatSeverity.MEDIUM.value and remote_ip:
                if not ip_ready:
                    continue
                if remote_ip not in self.blocked_ips:
                    self.block_ip(remote_ip)
                    threat.resolved = True
                    action = "Auto IP block" if not threat.action_taken else f"{threat.action_taken} | Auto IP block"
                    threat.action_taken = action
                    stats["blocked_ips"] += 1

        if stats["quarantined"] or stats["blocked_ips"]:
            self.log_event(
                "INFO",
                f"Resolution sweep: {stats['quarantined']} quarantined | {stats['blocked_ips']} IP blocks",
            )
        return stats

    def run_hyper_watch(self) -> List[DetectedThreat]:
        if not self.hyper_watch_enabled or not self.real_threat_detector:
            return []
        findings = self.real_threat_detector.get_real_threats()
        additions: List[DetectedThreat] = []
        for detection in findings:
            if detection.threat_id in self._hyper_seen_ids:
                continue
            self._hyper_seen_ids.add(detection.threat_id)
            severity = self._hyper_severity(detection.severity)
            category = self._hyper_category(detection.attack_type)
            geo = detection.geolocation or lookup_geolocation(detection.source_ip)
            geo_payload = None
            if geo:
                geo_payload = {
                    "ip": geo.ip,
                    "city": geo.city,
                    "region": geo.region,
                    "country": geo.country,
                    "loc": geo.loc,
                    "org": geo.org,
                    "postal": geo.postal,
                    "timezone": geo.timezone,
                }
            network_payload: Dict[str, Any] = {"indicators": detection.indicators}
            ip_ready = False
            ip_detection_count = 0
            if detection.source_ip and detection.source_ip != "LOCAL":
                ip_detection_count = self._register_ip_detection(detection.source_ip)
                if ip_detection_count:
                    network_payload["detection_count"] = ip_detection_count
                ip_ready = self._ip_ready_for_escalation(detection.source_ip)
            threat = DetectedThreat(
                threat_id=detection.threat_id,
                signature_id=None,
                category=category,
                severity=severity,
                source=detection.source_ip,
                target="System",
                description=f"Hyper Watch: {detection.attack_type.value}",
                timestamp=detection.timestamp,
                network_info=network_payload,
                geolocation=geo_payload,
            )
            self.detected_threats.append(threat)
            additions.append(threat)
            self.log_event(
                "ALERT" if severity.value >= ThreatSeverity.HIGH.value else "WARNING",
                f"Hyper watch flagged {detection.attack_type.value} from {detection.source_ip}",
            )
            self.hyper_last_detection = {
                "attack": detection.attack_type.value,
                "source": detection.source_ip,
                "severity": severity.name,
                "timestamp": detection.timestamp.isoformat(),
            }
            if geo_payload:
                self.hyper_last_detection["geo"] = geo_payload
            if detection.indicators:
                self.hyper_last_detection["indicators"] = detection.indicators[:3]
            if detection.source_ip and detection.source_ip != "LOCAL":
                if ip_ready:
                    if self.quarantine_manager.quarantine(detection.source_ip, detection.attack_type.value):
                        threat.quarantined = True
                        self.metrics["threats_quarantined"] += 1
                        self.metrics["hyper_quarantines"] += 1
                else:
                    self.log_event(
                        "INFO",
                        (
                            f"Hyper watch observed {detection.source_ip} "
                            f"{ip_detection_count}/{self.ip_escalation_threshold} time(s); deferring quarantine"
                        ),
                    )
                self.ping_defense_manager.track(detection.source_ip)
        if additions:
            self.metrics["threats_detected"] += len(additions)
            self.metrics["hyper_events"] += len(additions)
            self.metrics["hyper_ping_targets"] = len(self.ping_defense_manager.status())
        return additions
    
    def quick_scan(self) -> ScanResult:
        """Perform a quick security scan — REAL threats only."""
        scan_id = f"QUICK-{int(time.time())}"
        start = datetime.now()
        self.log_event("INFO", "Starting Quick Scan...")

        all_threats: List[DetectedThreat] = []

        # Real detections only (simulation permanently disabled)
        proc_threats = self.scan_processes()
        all_threats.extend(proc_threats)

        net_threats = self.scan_network()
        all_threats.extend(net_threats)

        hyper_threats = self.run_hyper_watch()
        all_threats.extend(hyper_threats)

        # Update metrics
        self.metrics["scans_completed"] += 1
        self.last_full_scan = datetime.now()

        baseline_items = len(psutil.pids())
        result = ScanResult(
            scan_id=scan_id,
            scan_type="Quick Scan",
            start_time=start,
            end_time=datetime.now(),
            items_scanned=self.metrics["files_scanned"] + baseline_items,
            threats_found=len(all_threats),
            threats_quarantined=0,
            threats_removed=0,
            status="Completed"
        )
        
        self.scan_history.append(result)
        
        if all_threats:
            self.log_event("ALERT", f"Quick Scan found {len(all_threats)} threat(s)!")
        else:
            self.log_event("SUCCESS", "Quick Scan completed - No threats found")

        resolution_stats = self.prioritize_threat_resolution()
        result.threats_quarantined = resolution_stats.get("quarantined", 0)
        result.threats_removed = resolution_stats.get("blocked_ips", 0)
        
        return result
    
    def quarantine_threat(self, threat_id: str) -> bool:
        """Quarantine a detected threat."""
        with self._lock:
            for threat in self.detected_threats:
                if threat.threat_id == threat_id and not threat.quarantined:
                    threat.quarantined = True
                    threat.resolved = True
                    if threat.action_taken:
                        if "Quarantined" not in threat.action_taken:
                            threat.action_taken = f"{threat.action_taken} | Quarantined"
                    else:
                        threat.action_taken = "Quarantined"
                    self.metrics["threats_quarantined"] += 1
                    self.metrics["threats_resolved"] += 1
                    self.threat_count_today += 1
                    
                    # If it's a process, try to terminate it
                    if threat.process_id:
                        try:
                            proc = psutil.Process(threat.process_id)
                            proc.terminate()
                            self.blocked_processes.add(threat.process_id)
                            self.log_event("SUCCESS", f"Terminated malicious process: {threat.process_name} (PID: {threat.process_id})")
                        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
                            self.log_event("WARNING", f"Could not terminate process {threat.process_id}: {e}")
                    
                    self.log_event("SUCCESS", f"Threat {threat_id} quarantined")
                    return True
            return False
    
    def _register_ip_detection(self, ip: Optional[str]) -> int:
        if not ip:
            return 0
        count = self.ip_detection_counts.get(ip, 0) + 1
        self.ip_detection_counts[ip] = count
        if count < self.ip_escalation_threshold:
            self.log_event(
                "INFO",
                f"Observed {ip} {count}/{self.ip_escalation_threshold} time(s) before escalation",
            )
        return count

    def _ip_ready_for_escalation(self, ip: str) -> bool:
        return self.ip_detection_counts.get(ip, 0) >= self.ip_escalation_threshold

    def block_ip(self, ip: str) -> bool:
        """Block an IP address."""
        self.blocked_ips.add(ip)
        self.intel.malicious_ips.add(ip)
        self.metrics["threats_blocked"] += 1
        self.metrics["threats_resolved"] += 1
        self.log_event("SUCCESS", f"Blocked IP: {ip}")
        return True

    def perform_system_repair(self) -> Dict[str, str]:
        """Run host repair routines (SFC, DISM, etc.)."""
        self.log_event("INFO", "System repair initiated")
        results = self.repair_manager.run_repair()
        self.log_event("INFO", "System repair completed")
        return results

    # ── Integrity Sweep & Auto-Response ───────────────────────────────────────
    _SUSPICIOUS_EXTENSIONS = {
        '.exe', '.bat', '.cmd', '.ps1', '.vbs', '.js', '.wsf', '.hta',
        '.scr', '.pif', '.reg', '.dll', '.sys', '.drv', '.inf',
    }
    _SUSPICIOUS_NAME_PATTERNS = [
        'cryptor', 'ransom', 'payload', 'inject', 'keylog', 'backdoor',
        'rootkit', 'trojan', 'miner', 'stealer', 'dropper', 'loader',
        'exploit', 'shellcode', 'reverse_shell', 'bind_shell',
    ]
    # Common Windows system folders to check for planted executables
    _INTEGRITY_DEFAULT_DIRS = [
        str(Path.home() / "Downloads"),
        str(Path.home() / "AppData" / "Temp"),
        str(Path.home() / "AppData" / "Local" / "Temp"),
    ]

    @staticmethod
    def _compute_file_hash(file_path: Path, algorithm: str = "sha256") -> str:
        """Compute a file hash safely (reads in 64 KB chunks)."""
        h = hashlib.new(algorithm)
        with open(file_path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()

    def integrity_sweep_and_respond(
        self,
        target_dirs: Optional[List[str]] = None,
        auto_quarantine: bool = True,
        progress_callback: Optional[Callable[[str, int, int], None]] = None,
    ) -> Dict[str, Any]:
        """
        Full integrity sweep:
          1. Walk target directories and hash every file.
          2. Flag files whose hash matches the malicious-hash DB.
          3. Flag files whose name matches suspicious patterns.
          4. Check running processes and network connections.
          5. Auto-quarantine / block threats if auto_quarantine=True.
          6. Run the incident playbook against any network-sourced threats.

        Args:
            target_dirs:       List of directory paths to scan (defaults to user
                               Downloads + Temp folders).
            auto_quarantine:   If True, automatically quarantine / block confirmed
                               threats after the sweep (Mythara Safety Hierarchy
                               enforced).
            progress_callback: Optional fn(message, done, total) called each step.

        Returns:
            Dict with full sweep results and incident report.
        """
        scan_id = f"INTEGRITY-{int(time.time())}"
        start   = datetime.now()
        self.log_event("INFO", f"[INTEGRITY] Sweep {scan_id} launched.")

        dirs = target_dirs or self._INTEGRITY_DEFAULT_DIRS
        new_threats: List[DetectedThreat] = []

        # ── Phase 1: File integrity scan ─────────────────────────────────────
        all_files: List[Path] = []
        for d in dirs:
            p = Path(d)
            if p.exists():
                try:
                    all_files.extend(f for f in p.rglob("*") if f.is_file())
                except PermissionError:
                    pass
        total_files = len(all_files)
        self.log_event("INFO", f"[INTEGRITY] Phase 1 — scanning {total_files} files across {len(dirs)} director(y/ies).")

        files_scanned  = 0
        hash_hits      = 0
        name_hits      = 0
        permission_err = 0

        for idx, fpath in enumerate(all_files):
            if progress_callback:
                progress_callback(f"Scanning: {fpath.name}", idx, total_files)
            try:
                file_hash = self._compute_file_hash(fpath)
                sig = self.intel.check_hash(file_hash)
                if sig:
                    t = DetectedThreat(
                        threat_id=f"INTEGRITY-HASH-{file_hash[:12]}",
                        signature_id=sig.id,
                        category=sig.category,
                        severity=sig.severity,
                        source=f"File: {fpath}",
                        target="System Integrity",
                        description=f"Known-malicious hash detected: {sig.name}",
                        timestamp=datetime.now(),
                        file_path=str(fpath),
                    )
                    new_threats.append(t)
                    self.detected_threats.append(t)
                    self.metrics["threats_detected"] += 1
                    hash_hits += 1
                    self.log_event("ALERT", f"[INTEGRITY] HASH MATCH: {fpath.name} — {sig.name}")
                    files_scanned += 1
                    continue

                # Name-pattern check
                fname_lower = fpath.name.lower()
                if fpath.suffix.lower() in self._SUSPICIOUS_EXTENSIONS:
                    for pattern in self._SUSPICIOUS_NAME_PATTERNS:
                        if pattern in fname_lower:
                            t = DetectedThreat(
                                threat_id=f"INTEGRITY-NAME-{abs(hash(str(fpath))):x}",
                                signature_id=None,
                                category=ThreatCategory.MALWARE,
                                severity=ThreatSeverity.HIGH,
                                source=f"File: {fpath}",
                                target="System Integrity",
                                description=f"Suspicious filename pattern '{pattern}' in {fpath.name}",
                                timestamp=datetime.now(),
                                file_path=str(fpath),
                            )
                            new_threats.append(t)
                            self.detected_threats.append(t)
                            self.metrics["threats_detected"] += 1
                            name_hits += 1
                            self.log_event("WARNING", f"[INTEGRITY] SUSPICIOUS NAME: {fpath.name}")
                            break

                files_scanned += 1
            except PermissionError:
                permission_err += 1
            except Exception as exc:
                self.log_event("WARNING", f"[INTEGRITY] Could not scan {fpath.name}: {exc}")

        self.log_event("INFO",
            f"[INTEGRITY] Phase 1 complete — {files_scanned} scanned, "
            f"{hash_hits} hash hits, {name_hits} name hits, "
            f"{permission_err} permission errors.")

        # ── Phase 2: Process anomaly scan ────────────────────────────────────
        if progress_callback:
            progress_callback("Phase 2: Process scan", total_files, total_files)
        self.log_event("INFO", "[INTEGRITY] Phase 2 — process anomaly scan.")
        proc_threats = self.scan_processes()
        for t in proc_threats:
            if not any(x.threat_id == t.threat_id for x in self.detected_threats):
                self.detected_threats.append(t)
                new_threats.append(t)
        self.log_event("INFO", f"[INTEGRITY] Phase 2 complete — {len(proc_threats)} process threat(s) flagged.")

        # ── Phase 3: Network anomaly scan ────────────────────────────────────
        if progress_callback:
            progress_callback("Phase 3: Network scan", total_files, total_files)
        self.log_event("INFO", "[INTEGRITY] Phase 3 — network anomaly scan.")
        net_threats = self.scan_network()
        for t in net_threats:
            if not any(x.threat_id == t.threat_id for x in self.detected_threats):
                self.detected_threats.append(t)
                new_threats.append(t)
        self.log_event("INFO", f"[INTEGRITY] Phase 3 complete — {len(net_threats)} network threat(s) flagged.")

        # ── Phase 4: HyperWatch layer ─────────────────────────────────────────
        if progress_callback:
            progress_callback("Phase 4: HyperWatch layer", total_files, total_files)
        self.log_event("INFO", "[INTEGRITY] Phase 4 — HyperWatch deep scan.")
        hyper_threats = self.run_hyper_watch()
        for t in hyper_threats:
            if not any(x.threat_id == t.threat_id for x in self.detected_threats):
                self.detected_threats.append(t)
                new_threats.append(t)
        self.log_event("INFO", f"[INTEGRITY] Phase 4 complete — {len(hyper_threats)} hyper event(s).")

        # ── Phase 5: Auto-response ────────────────────────────────────────────
        quarantine_stats: Dict[str, int] = {"quarantined": 0, "blocked_ips": 0}
        if auto_quarantine and new_threats:
            if progress_callback:
                progress_callback("Phase 5: Auto-quarantine", total_files, total_files)
            self.log_event("INFO", "[INTEGRITY] Phase 5 — auto-response (Safety Hierarchy enforced).")
            quarantine_stats = self.prioritize_threat_resolution()
            self.log_event("INFO",
                f"[INTEGRITY] Phase 5 complete — "
                f"{quarantine_stats['quarantined']} quarantined, "
                f"{quarantine_stats['blocked_ips']} IP(s) blocked.")

        # ── Phase 6: Incident investigation ──────────────────────────────────
        incident_report: Dict[str, Any] = {}
        net_threats_for_playbook = [
            t for t in new_threats
            if t.network_info and t.network_info.get("remote_ip")
        ]
        if net_threats_for_playbook:
            if progress_callback:
                progress_callback("Phase 6: Incident investigation", total_files, total_files)
            self.log_event("INFO", "[INTEGRITY] Phase 6 — incident investigation via playbook.")
            alerts = [
                AlertInput(
                    ip=t.network_info["remote_ip"],
                    category=t.category.value if hasattr(t.category, 'value') else str(t.category),
                    severity=t.severity.name if hasattr(t.severity, 'name') else str(t.severity),
                    timestamp=t.timestamp,
                )
                for t in net_threats_for_playbook
            ]
            try:
                incident_report = self.run_incident_playbook(
                    alerts=alerts,
                    window_minutes=30,
                    auto_block=auto_quarantine,
                )
                self.log_event("INFO", "[INTEGRITY] Phase 6 — incident playbook executed.")
            except Exception as exc:
                self.log_event("WARNING", f"[INTEGRITY] Incident playbook error: {exc}")
                incident_report = {"error": str(exc)}
        else:
            self.log_event("INFO", "[INTEGRITY] Phase 6 — no network threats; playbook skipped.")

        # ── Summary ───────────────────────────────────────────────────────────
        duration = (datetime.now() - start).total_seconds()
        result = {
            "scan_id":           scan_id,
            "started_at":        start.isoformat(),
            "duration_s":        round(duration, 2),
            "dirs_scanned":      len(dirs),
            "files_scanned":     files_scanned,
            "total_files":       total_files,
            "hash_matches":      hash_hits,
            "name_matches":      name_hits,
            "process_threats":   len(proc_threats),
            "network_threats":   len(net_threats),
            "hyper_threats":     len(hyper_threats),
            "total_new_threats": len(new_threats),
            "quarantined":       quarantine_stats["quarantined"],
            "blocked_ips":       quarantine_stats["blocked_ips"],
            "incident_report":   incident_report,
        }
        self.metrics["scans_completed"] += 1
        self.log_event(
            "ALERT" if new_threats else "INFO",
            f"[INTEGRITY] Sweep complete — {len(new_threats)} threat(s) found in {duration:.1f}s. "
            f"Quarantined: {quarantine_stats['quarantined']} | Blocked: {quarantine_stats['blocked_ips']}"
        )
        return result



    def run_big_meanie_assessment(self) -> Dict[str, Any]:
        """Execute the Big Meanie adversarial suite and capture findings."""
        if not (self.big_meanie_available and run_big_meanie_silent):
            self.log_event("WARNING", "Big Meanie module unavailable in this environment")
            return {"status": "unavailable"}

        self.log_event("INFO", "Big Meanie adversarial assessment launched")
        started_at = datetime.now()
        try:
            summary = run_big_meanie_silent()
        except Exception as exc:  # pragma: no cover - external dependency
            self.log_event("CRITICAL", f"Big Meanie assessment failed: {exc}")
            return {"status": "error", "error": str(exc)}

        summary = dict(summary or {})
        summary.setdefault("total_attacks", 0)
        summary.setdefault("breaches", 0)
        summary.setdefault("vulnerabilities", 0)
        summary.setdefault("apt_threats", 0)
        summary.setdefault("terminal_risk", 0.0)
        summary["started_at"] = started_at.isoformat()
        summary["completed_at"] = datetime.now().isoformat()

        self.metrics["big_meanie_runs"] += 1
        self.big_meanie_last_summary = summary

        threat = self._big_meanie_summary_to_threat(summary)
        if threat:
            self.detected_threats.append(threat)
            self.metrics["threats_detected"] += 1
            if threat.severity.value >= ThreatSeverity.HIGH.value:
                self.log_event("ALERT", "Big Meanie surfaced critical adversarial gaps")
            else:
                self.log_event("INFO", "Big Meanie completed with no critical compromises")
        else:
            self.log_event("INFO", "Big Meanie completed with no actionable findings")

        return summary

    def run_incident_playbook(
        self,
        alerts: Sequence[AlertInput],
        window_minutes: int = 15,
        capture_packets: bool = False,
        auto_block: bool = False,
    ) -> Dict[str, Any]:
        """Automate alert investigation and optional containment."""
        if not alerts:
            raise ValueError("alerts required for incident automation")
        playbook = IncidentResponsePlaybook(self)
        return playbook.execute(
            alerts=alerts,
            window_minutes=window_minutes,
            capture_packets=capture_packets,
            auto_block=auto_block,
        )

    def _big_meanie_summary_to_threat(self, summary: Dict[str, Any]) -> Optional[DetectedThreat]:
        total = summary.get("total_attacks")
        if total is None:
            return None

        breaches = int(summary.get("breaches", 0) or 0)
        vulnerabilities = int(summary.get("vulnerabilities", 0) or 0)
        apt_events = int(summary.get("apt_threats", 0) or 0)
        terminal_risk = float(summary.get("terminal_risk", 0.0) or 0.0)

        if breaches > 0:
            severity = ThreatSeverity.CRITICAL
        elif vulnerabilities > 0 or apt_events > 0:
            severity = ThreatSeverity.HIGH
        elif terminal_risk >= 0.25:
            severity = ThreatSeverity.MEDIUM
        else:
            severity = ThreatSeverity.INFO

        description = (
            f"Big Meanie simulated {total} attacks — Breaches {breaches}, "
            f"Vulnerabilities {vulnerabilities}, APT {apt_events}"
        )
        intel_summary = f"Terminal risk {terminal_risk:.2f} | Breaches {breaches} | APT {apt_events}"

        threat = DetectedThreat(
            threat_id=f"BIGM-{int(time.time())}-{random.randint(1000, 9999)}",
            signature_id="BIG_MEANIE",
            category=ThreatCategory.EXPLOIT,
            severity=severity,
            source="Big Meanie Adversarial Suite",
            target="S.E.R.E. Protection Surface",
            description=description,
            timestamp=datetime.now(),
            network_info={"vector": "BigMeanie", "summary": summary},
        )
        threat.intel_sources = ["Big Meanie"]
        threat.intel_score = max(terminal_risk, 0.35 if severity.value >= ThreatSeverity.HIGH.value else 0.15)
        threat.intel_summary = intel_summary
        if severity.value < ThreatSeverity.HIGH.value:
            threat.resolved = True
            threat.action_taken = "Assessment clear"
        return threat
    
    def get_protection_status(self) -> Dict:
        """Get current protection status."""
        health = self.get_system_health()
        
        return {
            "version": VERSION,
            "build": BUILD,
            "mode": "real",  # Simulation permanently disabled per Mythara spec
            "protection_score": health.protection_score,
            "modules": {m.value: enabled for m, enabled in self.protection_modules.items()},
            "threats_blocked_today": self.threat_count_today,
            "last_scan": self.last_full_scan.isoformat() if self.last_full_scan else "Never",
            "firewall": health.firewall_status,
            "system_health": {
                "cpu": f"{health.cpu_percent}%",
                "memory": f"{health.memory_percent}%",
                "disk": f"{health.disk_percent}%",
                "processes": health.running_processes,
                "suspicious_processes": health.suspicious_processes,
                "network_connections": health.network_connections,
            },
            "metrics": self.metrics,
            "hyper_watch": self.get_hyper_status(),
            "big_meanie": {
                "available": self.big_meanie_available,
                "last_summary": self.big_meanie_last_summary,
            },
        }

    def get_hyper_status(self) -> Dict[str, Any]:
        return {
            "enabled": self.hyper_watch_enabled,
            "quarantines": len(self.quarantine_manager.snapshot()),
            "ping_targets": len(self.ping_defense_manager.status()),
            "events": self.metrics.get("hyper_events", 0),
            "last_event": dict(self.hyper_last_detection) if self.hyper_last_detection else None,
        }

    def get_quarantine_snapshot(self) -> List[Dict[str, Any]]:
        snapshot = []
        for zone in self.quarantine_manager.snapshot():
            snapshot.append(
                {
                    "ip": zone.threat_ip,
                    "type": zone.threat_type,
                    "status": zone.status,
                    "isolation": zone.isolation_level,
                    "since": zone.quarantine_start.isoformat(),
                }
            )
        return snapshot

    def get_ping_snapshot(self) -> List[Dict[str, Any]]:
        snapshot = []
        for monitor in self.ping_defense_manager.status():
            snapshot.append(
                {
                    "ip": monitor.target_ip,
                    "status": monitor.status,
                    "alive": monitor.is_alive,
                    "response_time": monitor.response_time,
                    "failures": monitor.consecutive_failures,
                }
            )
        return snapshot

# ============================================================================
# MAIN APPLICATION
# ============================================================================

# Global instances
_engine: Optional[SEREProtectionEngine] = None
_shutdown_requested = False
logger = logging.getLogger(__name__)


def signal_handler(signum, frame):
    """Handle interrupt signals for graceful shutdown."""
    global _shutdown_requested
    _shutdown_requested = True
    print("\n\033[93m[S.E.R.E.] Shutdown signal received. Completing current cycle...\033[0m")


signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)


def print_splash():
    """Print enterprise splash screen."""
    os.system('cls' if platform.system() == 'Windows' else 'clear')
    
    cyan = "\033[96m"
    green = "\033[92m"
    yellow = "\033[93m"
    white = "\033[97m"
    reset = "\033[0m"
    bold = "\033[1m"
    
    print(f"""
{cyan}╔══════════════════════════════════════════════════════════════════╗
║                                                                    ║
║   {white}{bold}███████╗███████╗██████╗ ███████╗{reset}{cyan}                              ║
║   {white}{bold}██╔════╝██╔════╝██╔══██╗██╔════╝{reset}{cyan}                              ║
║   {white}{bold}███████╗█████╗  ██████╔╝█████╗  {reset}{cyan}  {green}Security Suite{reset}{cyan}            ║
║   {white}{bold}╚════██║██╔══╝  ██╔══██╗██╔══╝  {reset}{cyan}  {yellow}Enterprise Edition{reset}{cyan}        ║
║   {white}{bold}███████║███████╗██║  ██║███████╗{reset}{cyan}                              ║
║   {white}{bold}╚══════╝╚══════╝╚═╝  ╚═╝╚══════╝{reset}{cyan}  v{VERSION}                   ║
║                                                                    ║
║   {white}Survive  │  Evade  │  Resist  │  Escape{reset}{cyan}                     ║
║                                                                    ║
║   {green}█{reset} Real-Time Protection    {green}█{reset} Firewall Monitor              {cyan}║
║   {green}█{reset} Network Security        {green}█{reset} Ransomware Shield             {cyan}║
║   {green}█{reset} Behavior Analysis       {green}█{reset} Web Protection                {cyan}║
║   {green}█{reset} Cloud Intelligence      {green}█{reset} Identity Protection           {cyan}║
║                                                                    ║
║   {yellow}[CONTINUOUS PROTECTION - Press Ctrl+C to stop]{reset}{cyan}               ║
║                                                                    ║
╚══════════════════════════════════════════════════════════════════╝{reset}
""")


def print_status_dashboard(engine: SEREProtectionEngine):
    """Print real-time status dashboard."""
    status = engine.get_protection_status()
    health = engine.get_system_health()
    
    # Color codes
    green = "\033[92m"
    red = "\033[91m"
    yellow = "\033[93m"
    cyan = "\033[96m"
    reset = "\033[0m"
    
    score = health.protection_score
    score_color = green if score >= 80 else yellow if score >= 50 else red
    
    print(f"""
{cyan}┌─────────────────────────────────────────────────────────────┐{reset}
{cyan}│{reset}  {score_color}PROTECTION SCORE: {score}/100{reset}                                   {cyan}│{reset}
{cyan}├─────────────────────────────────────────────────────────────┤{reset}
{cyan}│{reset}  CPU: {health.cpu_percent:5.1f}%  │  Memory: {health.memory_percent:5.1f}%  │  Disk: {health.disk_percent:5.1f}%    {cyan}│{reset}
{cyan}│{reset}  Processes: {health.running_processes:4}  │  Connections: {health.network_connections:4}  │  Firewall: {health.firewall_status:8}{cyan}│{reset}
{cyan}├─────────────────────────────────────────────────────────────┤{reset}
{cyan}│{reset}  Threats Blocked Today: {green}{health.threats_blocked_today:4}{reset}                              {cyan}│{reset}
{cyan}│{reset}  Suspicious Processes:  {red if health.suspicious_processes > 0 else green}{health.suspicious_processes:4}{reset}                              {cyan}│{reset}
{cyan}└─────────────────────────────────────────────────────────────┘{reset}
""")


def run_continuous_protection(interval: float = 5.0):
    """Run continuous protection monitoring."""
    global _engine, _shutdown_requested
    _shutdown_requested = False
    
    _engine = SEREProtectionEngine()
    cycle = 0
    
    print_splash()
    _engine.log_event("SUCCESS", "S.E.R.E. Security Suite ACTIVATED")
    _engine.log_event("INFO", f"Monitoring interval: {interval}s | Mode: CONTINUOUS")
    _engine.log_event("INFO", "All protection modules enabled")
    print()
    
    try:
        while not _shutdown_requested:
            cycle += 1
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            print(f"\n\033[94m══════════════════ SCAN CYCLE {cycle} | {timestamp} ══════════════════\033[0m")
            
            # Perform quick scan
            result = _engine.quick_scan()
            
            # Show dashboard
            print_status_dashboard(_engine)
            
            # Handle detected threats
            unresolved = [t for t in _engine.detected_threats if not t.quarantined and not t.resolved]
            if unresolved:
                print("\033[91m┌─────────────────── ACTIVE THREATS ───────────────────┐\033[0m")
                for threat in unresolved[-5:]:  # Show last 5
                    severity_color = "\033[91m" if threat.severity.value >= 3 else "\033[93m"
                    print(f"\033[91m│\033[0m {severity_color}[{threat.severity.name}]\033[0m {threat.category.value}")
                    print(f"\033[91m│\033[0m   Source: {threat.source}")
                    print(f"\033[91m│\033[0m   {threat.description}")
                    
                    # Auto-quarantine critical/high threats
                    if threat.severity.value >= ThreatSeverity.HIGH.value:
                        _engine.quarantine_threat(threat.threat_id)
                        
                print("\033[91m└───────────────────────────────────────────────────────┘\033[0m")
            
            # Wait for next cycle
            if not _shutdown_requested:
                print(f"\n\033[90m[Next scan in {interval}s...]\033[0m", end="", flush=True)
                sleep_remaining = interval
                while sleep_remaining > 0 and not _shutdown_requested:
                    sleep_chunk = min(0.5, sleep_remaining)
                    time.sleep(sleep_chunk)
                    sleep_remaining -= sleep_chunk
                print("\r" + " " * 30 + "\r", end="")  # Clear the line
                
    except KeyboardInterrupt:
        pass
    
    # Shutdown summary
    print(f"""
\033[96m╔══════════════════════════════════════════════════════════════╗
║                    SESSION SUMMARY                              ║
╠══════════════════════════════════════════════════════════════╣
║  Total Scan Cycles:     {cycle:6}                                 ║
║  Threats Detected:      {_engine.metrics['threats_detected']:6}                                 ║
║  Threats Quarantined:   {_engine.metrics['threats_quarantined']:6}                                 ║
║  Items Scanned:         {_engine.metrics['files_scanned'] + _engine.metrics['scans_completed'] * 100:6}                                 ║
║  Session Ended:         {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                   ║
╚══════════════════════════════════════════════════════════════╝\033[0m
""")
    
    return 0


def _load_alert_inputs_from_file(file_path: Path, default_severity: str = "MEDIUM") -> List[AlertInput]:
    """Load alert inputs from JSON, CSV, or newline-separated files."""
    text = file_path.read_text(encoding="utf-8").strip()
    if not text:
        return []
    suffix = file_path.suffix.lower()
    alerts: List[AlertInput] = []

    def append_alert(payload: Dict[str, Any]) -> None:
        alert = AlertInput.from_payload(payload, fallback_severity=default_severity)
        if alert.ip:
            alerts.append(alert)

    if suffix in {".json", ".ndjson"}:
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Unable to parse JSON alerts from {file_path}: {exc}") from exc
        if isinstance(parsed, dict) and "alerts" in parsed:
            records = parsed["alerts"]
        elif isinstance(parsed, list):
            records = parsed
        else:
            records = [parsed]
        for record in records:
            if isinstance(record, dict):
                append_alert(record)
        return alerts

    try:
        reader = csv.DictReader(text.splitlines())
        rows = list(reader)
    except csv.Error as exc:
        logging.getLogger(__name__).warning("CSV parsing failed for %s: %s", file_path, exc)
        rows = []
    if rows:
        for row in rows:
            append_alert(row)
        return alerts

    for line in text.splitlines():
        candidate = line.strip()
        if not candidate or candidate.startswith("#"):
            continue
        token = candidate.split(",")[0].split()[0]
        if token:
            alerts.append(
                AlertInput(
                    ip=token,
                    severity=default_severity.upper(),
                    timestamp=datetime.utcnow(),
                )
            )
    return alerts


def main(argv=None) -> int:
    """Main entry point for S.E.R.E. Security Suite."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='S.E.R.E. Security Suite - Enterprise Cybersecurity Protection',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  sere_enterprise.py                  Start continuous protection (default)
  sere_enterprise.py --interval 10    Scan every 10 seconds
  sere_enterprise.py --quick-scan     Run single quick scan and exit
  sere_enterprise.py --status         Show protection status
  sere_enterprise.py --install-startup Add to Windows startup
        """
    )
    
    parser.add_argument('--interval', type=float, default=5.0,
                       help='Seconds between monitoring cycles (default: 5.0)')
    parser.add_argument('--quick-scan', action='store_true',
                       help='Run a quick scan and exit')
    parser.add_argument('--full-scan', action='store_true',
                       help='Run a full system scan and exit')
    parser.add_argument('--status', action='store_true',
                       help='Show current protection status')
    parser.add_argument('--version', action='store_true',
                       help='Show version information')
    parser.add_argument('--incident-ips', nargs='+',
                        help='Space-separated IPs to feed into the incident response playbook')
    parser.add_argument('--incident-file', type=str,
                        help='Path to JSON/CSV alerts file used for incident automation')
    parser.add_argument('--incident-window', type=int, default=15,
                        help='Minutes of firewall/log history to correlate (default: 15)')
    parser.add_argument('--incident-capture', action='store_true',
                        help='Attempt short packet/session capture for each IP')
    parser.add_argument('--incident-auto-block', action='store_true',
                        help='Automatically block IPs flagged as malicious during automation')
    parser.add_argument('--incident-output', type=str,
                        help='Write incident automation report JSON to this path')
    parser.add_argument('--incident-severity', type=str, default='MEDIUM',
                        help='Default severity label used for --incident-ips entries')
    
    # Startup management
    parser.add_argument('--install-startup', action='store_true',
                       help='Install S.E.R.E. to run on Windows startup')
    parser.add_argument('--uninstall-startup', action='store_true',
                       help='Remove S.E.R.E. from Windows startup')
    
    args = parser.parse_args(argv)
    
    # Version
    if args.version:
        print(f"S.E.R.E. Security Suite v{VERSION} ({BUILD})")
        print("Copyright © 2025 Herbert Velez Jr. All rights reserved.")
        return 0
    
    # Startup management
    if args.install_startup:
        return install_to_startup()
    if args.uninstall_startup:
        return remove_from_startup()
    
    # Quick scan
    if args.quick_scan:
        print_splash()
        engine = SEREProtectionEngine()
        result = engine.quick_scan()
        print_status_dashboard(engine)
        return 0 if result.threats_found == 0 else 1
    
    # Status
    if args.status:
        engine = SEREProtectionEngine()
        status = engine.get_protection_status()
        print(json.dumps(status, indent=2, default=str))
        return 0

    incident_ips = args.incident_ips or []
    incident_file = args.incident_file
    if incident_ips or incident_file:
        engine = SEREProtectionEngine()
        severity_label = (args.incident_severity or "MEDIUM").upper()
        alerts: List[AlertInput] = []
        for raw in incident_ips:
            ip_value = (raw or "").strip()
            if not ip_value:
                continue
            alerts.append(
                AlertInput(
                    ip=ip_value,
                    severity=severity_label,
                    timestamp=datetime.utcnow(),
                )
            )
        if incident_file:
            path = Path(incident_file).expanduser()
            if not path.exists():
                print(f"Incident file not found: {path}")
                return 1
            try:
                alerts.extend(_load_alert_inputs_from_file(path, default_severity=severity_label))
            except ValueError as exc:
                print(exc)
                return 1
        if not alerts:
            print("No valid alerts supplied for incident automation")
            return 1
        report = engine.run_incident_playbook(
            alerts=alerts,
            window_minutes=args.incident_window,
            capture_packets=args.incident_capture,
            auto_block=args.incident_auto_block,
        )
        report_json = json.dumps(report, indent=2, default=str)
        if args.incident_output:
            output_path = Path(args.incident_output).expanduser()
            output_path.write_text(report_json, encoding="utf-8")
            print(f"Incident automation report saved to {output_path}")
        else:
            print(report_json)
        return 0
    
    # Default: continuous protection
    return run_continuous_protection(interval=args.interval)


def install_to_startup() -> int:
    """Install to Windows startup."""
    if platform.system() != "Windows":
        print("Startup installation is only supported on Windows")
        return 1
    
    startup_folder = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    script_path = Path(__file__).resolve()
    python_exe = sys.executable
    
    bat_content = f'''@echo off
title S.E.R.E. Security Suite
cd /d "{script_path.parent}"
"{python_exe}" "{script_path}"
'''
    
    bat_path = startup_folder / "SERE_Security.bat"
    bat_path.write_text(bat_content)
    
    print(f"\033[92m[SUCCESS]\033[0m S.E.R.E. Security Suite installed to startup")
    print(f"Location: {bat_path}")
    return 0


def remove_from_startup() -> int:
    """Remove from Windows startup."""
    startup_folder = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    bat_path = startup_folder / "SERE_Security.bat"
    
    if bat_path.exists():
        bat_path.unlink()
        print(f"\033[92m[SUCCESS]\033[0m S.E.R.E. Security Suite removed from startup")
    else:
        print("S.E.R.E. was not installed in startup")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
