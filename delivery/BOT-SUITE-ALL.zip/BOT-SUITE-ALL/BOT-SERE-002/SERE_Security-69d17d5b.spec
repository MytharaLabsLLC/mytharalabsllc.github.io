# -*- mode: python ; coding: utf-8 -*-

from pathlib import Path


PROJECT_ROOT = Path(SPECPATH)
BOT_DIR = PROJECT_ROOT / 'mythara' / 'bots'
CORE_DIR = PROJECT_ROOT / 'mythara' / 'core'
ENTRY_SCRIPT = BOT_DIR / 'sere_bot.py'


a = Analysis(
    [str(ENTRY_SCRIPT)],
    pathex=[str(PROJECT_ROOT), str(BOT_DIR), str(CORE_DIR)],
    binaries=[],
    datas=[],
    hiddenimports=[
        'sere_ai_engine',
        'sere_bot_clean',
        'sere_bot_full',
        'sere_desktop_gui',
        'sere_enterprise',
        'sere_persona_catalog',
        'sere_security_engine',
        'sere_splash',
        'sqlite3',
        'tkinter',
        'tkinter.messagebox',
        'tkinter.scrolledtext',
        'tkinter.ttk',
        'unified_compliance_framework',
        'psutil',
        'pyttsx3',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='SERE_Security',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='SERE_Security',
)
