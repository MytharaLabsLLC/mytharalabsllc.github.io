MytharaConnect (BOT-CONNECT-001)
================================
Mythara Labs LLC

What this is
------------
A sales conversation and drafting engine with a governance gate in front of any send. It discovers prospect context, drafts outreach for different industries and closing scenarios, and passes every draft through the included SoulCradle witness governance layer. Drafts are prepared for operator approval; nothing transmits on its own.

How to run it
-------------
From this folder (the top folder of the package), run:

    python3 Commercial/mythara_connect.py

The demo runs three flows end to end: industry discovery, industry-specific messaging, and closing scenarios. Keep the folder layout exactly as delivered: the Commercial folder and the soul_cradle folder must stay side by side.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library. The included soul_cradle folder must stay beside the Commercial folder.

Notes
-----
By design, this bot drafts only. Sending anything is a separate, operator-approved step outside this package.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

