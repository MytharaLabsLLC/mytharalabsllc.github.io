Legal Team Suite (BOT-LEGAL-001)
================================
Mythara Labs LLC

What this is
------------
A legal research suite that works over a bundled legal index: torts analysis, contract review, compliance assessment, IP protection checks, and employment risk review. It helps you organize legal questions and find the relevant doctrine fast.

How to run it
-------------
From this folder, run:

    python3 mythara_legal_team_suite.py

The built-in demo runs end to end so you can see the bot work before you use it in your own code.

The demo runs all five research modules in turn.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library. The included core folder must stay in place; the suite loads its legal index modules from core/source_proprietary.

Notes
-----
All research data ships inside the package. Nothing is sent anywhere.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.


Important notice
----------------
This software is a legal research aid. It is not legal advice, it is not a
law firm, and it is not a substitute for a licensed attorney. Anything it
produces should be reviewed by a qualified attorney before you rely on it.
