Sales Trainer (BOT-STRAIN-001)
==============================
Mythara Labs LLC

What this is
------------
A pitch analysis and objection handling trainer for sales reps. It scores practice pitches, gives feedback, walks reps through objections, and stores the training record locally.

How to run it
-------------
From this folder, run:

    python3 mythara_sales_trainer.py

The built-in demo runs end to end so you can see the bot work before you use it in your own code.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library. If a Mythara Engine SDK is present the bot can use it; without it the bot prints a notice and runs in standalone mode, which is fully functional.

Notes
-----
Training data is stored under a .mythara_engine folder in the user home directory. This is the fixed and verified build (2026-11-22): back-to-back pitch analyses and the shipped demo complete without ID collisions.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

