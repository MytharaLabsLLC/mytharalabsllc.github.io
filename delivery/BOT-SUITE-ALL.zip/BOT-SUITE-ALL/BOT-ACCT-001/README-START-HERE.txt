Accounting VP (BOT-ACCT-001)
============================
Mythara Labs LLC

What this is
------------
A bookkeeping operations bot: chart of accounts, accounts receivable and payable, grant tracking, payroll journal entries, and financial reports, stored in a local database.

How to run it
-------------
From this folder, run:

    python3 mythara_accounting_vp.py

The built-in demo runs end to end so you can see the bot work before you use it in your own code.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library.

Notes
-----
On startup the bot tries to register with a Mythara orchestrator service if one is configured (MYTHARA_ORCHESTRATOR_URL). That service is optional and not required: with nothing configured the bot prints a warning and works fully standalone. This is the fixed and verified build (2026-11-22): the demo can be run more than once against the same database.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

