QuickFix Bot (BOT-QUICKFIX-001)
===============================
Mythara Labs LLC

What this is
------------
A code vulnerability scanner with dry-run fix previews. It scans a folder for common dangerous patterns, shows you every change it proposes, and asks before it applies anything.

How to run it
-------------
QuickFix is interactive. Copy quickfix_bot.py into the folder of code you want scanned, then from that folder run:

    python3 quickfix_bot.py

It scans, shows a dry-run preview (nothing is written in the preview), and then asks "Apply fixes for real? (y/n)". Answer n to leave every file untouched. It writes a scan report file in the folder when it finishes.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library.

Notes
-----
Always review the dry-run preview before answering y. Keep your own backup or version control of any code you let it modify.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

