Education Suite (BOT-EDU-001)
=============================
Mythara Labs LLC

What this is
------------
A school administration suite: student records, attendance tracking, at-risk student flags, and parent-teacher conference prompts, all stored in a local sqlite database on your own machine.

How to run it
-------------
From this folder, run:

    python3 mythara_education_suite.py

The built-in demo runs end to end so you can see the bot work before you use it in your own code.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library.

Notes
-----
The bot creates its database file (mythara_education.db) beside the script on first run. You can pass your own database path when you construct the suite in your own code.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

