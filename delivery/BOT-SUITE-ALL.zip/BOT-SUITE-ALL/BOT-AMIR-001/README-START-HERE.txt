A.M.I.R. Bot (BOT-AMIR-001)
===========================
Mythara Labs LLC

What this is
------------
Autonomous Mythara Intelligence and Response: a security analysis orchestrator. It runs its assessment pipeline locally, loads the QuickFix remediation bot (included) when fixes are available, scores and seals its findings through the included SoulCradle governance package, and reports what it found.

How to run it
-------------
From this folder, run:

    python3 amir_bot.py

The built-in demo runs end to end so you can see the bot work before you use it in your own code.

When the analysis finishes it asks whether you want interactive mode. Answer n to exit cleanly.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library. The included soul_cradle folder must stay beside amir_bot.py; the bot loads it from its own folder.

Notes
-----
The penetration testing component the bot looks for (M.A.X.I.M.U.S.) is not part of this package and is not part of the archive this product was built from. The bot detects that it is absent, reports it as unavailable, and completes the rest of its pipeline without it. Everything else in the pipeline runs locally.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

