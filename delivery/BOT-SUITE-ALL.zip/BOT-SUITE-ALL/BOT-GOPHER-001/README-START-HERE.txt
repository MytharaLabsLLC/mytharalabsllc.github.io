GopherBot (BOT-GOPHER-001)
==========================
Mythara Labs LLC

What this is
------------
An offline legal research bot. It looks up tort definitions and analyzes fact patterns against a bundled legal index, with no network access needed.

How to run it
-------------
From this folder, run:

    python3 mythara_gopherbot.py

The built-in demo runs end to end so you can see the bot work before you use it in your own code.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library. The included core folder must stay in place; the bot loads its legal index modules from core/source_proprietary.

Notes
-----
The bot prints its own not-legal-advice disclaimer in its output.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.


Important notice
----------------
This software is a legal research aid. It is not legal advice, it is not a
law firm, and it is not a substitute for a licensed attorney. Anything it
produces should be reviewed by a qualified attorney before you rely on it.
