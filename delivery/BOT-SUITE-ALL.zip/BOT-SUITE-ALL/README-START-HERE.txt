Mythara Bot Suite, All 15 (BOT-SUITE-ALL)
=========================================
Mythara Labs LLC

What this is
------------
Every bot in the Mythara bot catalog in one package: SERE Legacy, SERE Desktop, A.M.I.R., Legal Team Suite, Education Suite, MytharaTutor, Accounting VP, HR VP, International Sales VP, A.D.A.P.T., GopherBot, Sales Trainer, Email Bot, QuickFix, and VoIP Call Tracking. Each bot lives in its own folder named by its SKU.

How to run it
-------------
Open any bot's folder and read its README-START-HERE.txt. Each one gives the exact command to run that bot. Every bot runs locally on your own machine.

Requirements
------------
Python 3.10 or newer. Most bots use only the Python standard library. The SERE Security Suite needs Python 3.11 or newer on Windows, plus two packages: pip install psutil requests. Its README has the details.

Notes
-----
Each bot folder is self-contained, including any sibling modules that bot needs.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

