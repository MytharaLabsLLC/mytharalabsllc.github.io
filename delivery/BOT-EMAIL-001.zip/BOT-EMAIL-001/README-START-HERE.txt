Email Bot (BOT-EMAIL-001)
=========================
Mythara Labs LLC

What this is
------------
An email analysis and auto-response drafting bot. You supply email text; it analyzes it and drafts a response. It has no inbox access and it sends nothing: draft only, by design.

How to run it
-------------
From this folder, run:

    python3 mythara_email_bot.py

The built-in demo runs end to end so you can see the bot work before you use it in your own code.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library. If a Mythara Engine SDK is present the bot can use it; without it the bot prints a notice and runs in standalone mode, which is fully functional.

Notes
-----
This is the fixed and verified build (2026-11-22): the demo can be run more than once against the same database.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

