A.D.A.P.T. Bot (BOT-ADAPT-001)
==============================
Mythara Labs LLC

What this is
------------
An automated security assessment tool for a folder of code. It checks import and code-execution safety by static (AST) analysis, audits the Python dependencies of the machine it runs on, and produces a findings report.

How to run it
-------------
A.D.A.P.T. is a command line tool. From this folder, run:

    python3 adapt_bot.py <path-to-the-folder-to-assess>

Exit code 1 means findings or unknowns are present; that is the tool working as designed, not a crash. Exit code 0 means the assessment completed with nothing to report.

Requirements
------------
Python 3.10 or newer. No third-party packages are required: the bot uses only the Python standard library. One check shells out to pip (pip list --outdated) to audit dependency versions, so that check needs network access to a package index. Without network it reports UNKNOWN, and it can take up to about two minutes to time out.

Notes
-----
The assessment is read-only against the target folder.
Support
-------
Support is by email at info@mytharalabs.com. Messages are answered within
5 business days.

License
-------
One-time license from Mythara Labs LLC. This package is licensed to the
buyer for use in the buyer's own business under the Mythara Labs LLC terms
accepted at checkout. The license is non-refundable except as stated in
Sections 7.2 and 11.4 of those terms. You may not resell, sublicense, or
redistribute this package or the code in it.

